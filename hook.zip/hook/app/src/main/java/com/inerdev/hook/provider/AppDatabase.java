/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.provider;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

/**
 * The Class VaultDatabase.
 */
public class AppDatabase extends SQLiteOpenHelper {

    /** The Constant DATABASE_VERSION. */
    private static final int DATABASE_VERSION = 2;

    /** The Constant DATABASE_NAME. */
    private static final String DATABASE_NAME = "hook.db";

    /** The Constant TYPE_TEXT. */
    private static final String TYPE_TEXT = " TEXT";

    /** The Constant TYPE_INTEGER. */
    private static final String TYPE_INTEGER = " INTEGER";

    /** The Constant COMMA_SEP. */
    private static final String COMMA_SEP = ",";

    /** SQL statement to create "Messages" table. */
    static final String SQL_CREATE_MESSAGES = "CREATE TABLE " + AppContract.Messages.TABLE_NAME
            + " (" + AppContract.Messages._ID + " " + TYPE_INTEGER + " PRIMARY KEY,"
            + AppContract.Messages.COLUMN_SUBJECT + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_TEXT + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_NAME_VERSION + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_DATE_CREATION + TYPE_INTEGER + COMMA_SEP
            + AppContract.Messages.COLUMN_DATE_EXPIRATION + TYPE_INTEGER + COMMA_SEP
            + AppContract.Messages.COLUMN_ITEM_TYPE + TYPE_INTEGER + COMMA_SEP
            + AppContract.Messages.COLUMN_ITEM_CATEGORY_TYPE + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_STATUS + TYPE_INTEGER + COMMA_SEP
            + AppContract.Messages.COLUMN_SENDER_NAME + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_SENDER_ADR + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_SENDER_DEVICE_ID + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_SERVER_ID + TYPE_TEXT + COMMA_SEP
            + AppContract.Messages.COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME + TYPE_TEXT
            + ")";

    /** SQL statement to create "Devices" table. */
    static final String SQL_CREATE_DEVICES = "CREATE TABLE " + AppContract.Devices.TABLE_NAME + " ("
            + AppContract.Devices._ID + " " + TYPE_INTEGER + " PRIMARY KEY,"
            + AppContract.Devices.COLUMN_NAME + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_DATE_CREATION + TYPE_INTEGER + COMMA_SEP
            + AppContract.Devices.COLUMN_DISPLAY_NAME_NAME + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_UIID + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_ADDRESS + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_USER_ID + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_TYPE + TYPE_TEXT + COMMA_SEP
            + AppContract.Devices.COLUMN_STATUS + TYPE_INTEGER + COMMA_SEP
            + " UNIQUE ("    + AppContract.Devices.COLUMN_UIID + "));";


    /** The Constant SQL_DELETE_MESSAGES. */
    static final String SQL_DELETE_MESSAGES = "DROP TABLE IF EXISTS " + AppContract.Messages.TABLE_NAME;

    /** The Constant SQL_DELETE_DEVICES. */
    static final String SQL_DELETE_DEVICES = "DROP TABLE IF EXISTS " + AppContract.Devices.TABLE_NAME;


    /** The m in transaction. */
    private boolean mInTransaction;

    /** The m log. */
    private Log mLog;

    /** The Constant TAG. */
    private static final String TAG = "AppDatabase";


    /**
     * Instantiates a new vault database.
     * @param context the context
     */
    public AppDatabase(final Context context, final Log log) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        mLog = log;
    }

    /**
     * On create.
     * @param db the db
     */
    @Override
    public void onCreate(final SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_MESSAGES);
        db.execSQL(SQL_CREATE_DEVICES);

    }

    /**
     * On upgrade.
     * @param db the db
     * @param oldVersion the old version
     * @param newVersion the new version
     */
    @Override
    public void onUpgrade(final SQLiteDatabase db, final int oldVersion, final int newVersion) {
        mLog.d(TAG, "onUpgrade(), oldVersion: " + oldVersion + " newVersion: " + newVersion);
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over

        db.execSQL(SQL_DELETE_DEVICES);
        db.execSQL(SQL_DELETE_MESSAGES);
        onCreate(db);
    }

    /**
     * On configure.
     * @param database the database
     */
    @Override
    public void onConfigure(final SQLiteDatabase database) {
        enableWriteAheadLoggingIfAvailable(database);
    }

    /**
     * Enable write ahead logging if available.
     * @param database the database
     */
    private void enableWriteAheadLoggingIfAvailable(final SQLiteDatabase database) {
        database.enableWriteAheadLogging();
    }

    /**
     * In transaction.
     * @return true, if successful
     */
    boolean inTransaction() {
        return mInTransaction;
    }

    /**
     * Sets the in transaction.
     * @param inTransaction the new in transaction
     */
    public void setInTransaction(final boolean inTransaction) {
        mInTransaction = inTransaction;
    }

    /**
     * Clear data.
     */
    public void clearData() {
        SQLiteDatabase db = null;
        final long time = System.currentTimeMillis();
        try {
            mLog.d(TAG, "clearData(), started");
            db = getWritableDatabase();
            try {
                db.beginTransaction();
                db.execSQL(String.format("DELETE FROM %s", AppContract.Devices.TABLE_NAME));
                db.execSQL(String.format("DELETE FROM %s", AppContract.Messages.TABLE_NAME));
                db.setTransactionSuccessful();
                mLog.d(TAG, "clearData(), succeed, t: " + (System.currentTimeMillis() - time));
            } catch (final Exception e) {
                mLog.e(TAG, "ERROR clearData(), 1,  exc: ", e);
            } finally {
                db.endTransaction();
            }
        } catch (final Exception e) {
            mLog.e(TAG, "ERROR clearData(), 2, exc: ", e);
        } finally {
            if (db != null) {
                /**
                 * Empty
                 */
                db.close();
            }
        }
    }
}

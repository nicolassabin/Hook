
package com.inerdev.hook.core;

/**
 * The Class CoreException.
 */
public class CoreException extends Exception{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7777300877086026972L;

    /** The error code. */
    protected ErrorCode mCode;

    /** The HTTP code. */
    protected int mHttpCode;

    /** The root cause exception. */
    protected Exception mException;

    /** The message. */
    protected String mMessage;


    /**
     * Instantiates an authentication exception with a root cause exception.
     * @param exception The root cause of this exception
     */
    public CoreException(final Exception exception) {
        this.mCode = ErrorCode.OTHER_EXCEPTION;
        this.mHttpCode = 0;
        this.mException = exception;
    }

    /**
     * Instantiates a new authentication exception with an error code.
     * @param code The error code
     */
    public CoreException(final ErrorCode code) {
        this.mCode = code;
        this.mHttpCode = 0;
        this.mException = null;
    }

    /**
     * Instantiates a new authentication exception with an error code and an error message.
     * @param code The error code
     * @param msg The error message
     */
    public CoreException(final ErrorCode code, final String msg) {
        this.mCode = code;
        this.mHttpCode = 0;
        this.mException = null;
        mMessage = msg;
    }

    /**
     * Instantiates a new authentication exception with an error code and an error message.
     * @param code The error code
     * @param msg The error message
     * @param httpCode The error httpCode
     */
    public CoreException(final ErrorCode code, final String msg, final int httpCode) {
        this.mCode = code;
        this.mHttpCode = httpCode;
        this.mException = null;
        mMessage = msg;
    }

    /**
     * Gets the code.
     * @return the code
     */
    public String getCode() {
        return mCode.toString();
    }

    /**
     * Gets the ErrorCode code.
     * @return the ErrorCode
     */
    public ErrorCode getErrorCode() {
        return mCode;
    }

    /**
     * Gets the HttpCode code.
     * @return the HttpCode
     */
    public int getHttpCode() {
        return mHttpCode;
    }



}

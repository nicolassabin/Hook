
package com.inerdev.hook.core.devices;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

/**
 * The Class DeviceInfo.
 */
public class DeviceInfo implements Parcelable{

    /**
     * The Constant TAG.
     */
    protected static final String TAG = "DeviceInfo";

    /** The m mId // to retrive in the database */
    private String mId;

    /** The m mAdr. */
    private String mAdr;

    /** The m name. */
    private String mName;

    /** The m mDisplayName. */
    private String mDisplayName;

    /** The m mUserId. */
    private String mUserId;

    /** The m mStatus. */
    private int mStatus;

    /**
     * Instantiates a new device info impl.
     * @param id the id
     * @param adr the adr
     * @param name the name
     * @param displayName the displayName
     * @param userId the userId
     */
    public DeviceInfo(final String id, final String adr, final String name, final String displayName, final String userId) {
        mId = id;
        mAdr = adr;
        mName = name;
        mDisplayName = displayName;
        mUserId = userId;
    }


    protected DeviceInfo(Parcel in) {
        mId = in.readString();
        mAdr = in.readString();
        mName = in.readString();
        mDisplayName = in.readString();
        mUserId = in.readString();
    }

    public static final Creator<DeviceInfo> CREATOR = new Creator<DeviceInfo>() {
        @Override
        public DeviceInfo createFromParcel(Parcel in) {
            return new DeviceInfo(in);
        }

        @Override
        public DeviceInfo[] newArray(int size) {
            return new DeviceInfo[size];
        }
    };

    /**
     * set the info a new device info impl.
     * @param id the id
     * @param adr the adr
     * @param name the name
     * @param displayName the displayName
     * @param userId the userId
     */
    public void setInfo(final String id, final String adr, final String name, final String displayName, final String userId) {
        mId = id;
        mAdr = adr;
        mName = name;
        mDisplayName = displayName;
        mUserId = userId;
    }

    /**
     * Returns the mId
     * @return The mId
     */
    public String getId() {
        return mId;
    }

    /**
     * Returns the Adr
     * @return The Adr
     */
    public String getAdr() {
        return mAdr;
    }

    /**
     * Returns the Name
     * @return The Name
     */
    public String getName() {
        return mName;
    }

    /**
     * Returns the DisplayName
     * @return The DisplayName
     */
    public String getDisplayName() {
        return mDisplayName;
    }

    /**
     * Returns the UserId
     * @return The UserId
     */
    public String getUserId() {
        return mUserId;
    }

    /**
     * Returns the mStatus
     * @return The Status
     */
    public int getStatus() {
        return mStatus;
    }

    /**
     * set the mStatus
     * @param  status
     */
    public void setStatus(int status) {
        mStatus = status;
    }

    /**
     * Describe the kinds of special objects contained in this Parcelable
     * instance's marshaled representation. For example, if the object will
     * include a file descriptor in the output of {@link #writeToParcel(Parcel, int)},
     * the return value of this method must include the
     * {@link #CONTENTS_FILE_DESCRIPTOR} bit.
     *
     * @return a bitmask indicating the set of special object types marshaled
     * by this Parcelable object instance.
     * @see #CONTENTS_FILE_DESCRIPTOR
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Flatten this object in to a Parcel.
     *
     * @param dest  The Parcel in which the object should be written.
     * @param flags Additional flags about how the object should be written.
     *              May be 0 or {@link #PARCELABLE_WRITE_RETURN_VALUE}.
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mId);
        dest.writeString(mAdr);
        dest.writeString(mName);
        dest.writeString(mDisplayName);

    }

    public String toString() {
        return "Id:" + getId() + " adr:" + getAdr() + " name : " +getName() + " diaplyName:" + getDisplayName();
    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;


import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * list of Messages
 */

public class Messages

{
    /** This contains the messages.*/
    @SerializedName("messages")
    private List<Message> mMessages = new ArrayList<Message>();

    /**
     * return the Message list
     * @return ArrayList<Message>
     */
    public List<Message> getMessages()
    {
        return mMessages;
    }

}

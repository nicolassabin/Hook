/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.widget.RemoteViews;

import com.inerdev.hook.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * A factory for creating Notification objects.
 */
public class NotificationFactory {

    /**
     * Instantiates a new notification factory.
     */
    public NotificationFactory() {
    }



    /**
     * Creates a new Notification object.
     * @param context the context
     * @param tickerText the ticker text
     * @return the notification wrapper
     */
    public NotificationWrapper createGenericNotification(final Context context, final CharSequence tickerText) {
        return createGenericNotification(context, tickerText, System.currentTimeMillis(),
                Notification.FLAG_AUTO_CANCEL);
    }

    /**
     * Creates a new Notification object.
     * @param context the context
     * @param tickerText the ticker text
     * @return the notification
     */
    public Notification createGenericNotificationNoFlag(final Context context, final CharSequence tickerText) {
        final NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
        builder.setTicker(tickerText);
        builder.setWhen(System.currentTimeMillis());
        setSmallIcon(builder);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            builder.setColor(ContextCompat.getColor(context, R.color.notification_color));

            final RemoteViews contentView = new RemoteViews(context.getPackageName(), R.layout.generic_notification);
            contentView.setTextViewText(R.id.generic_notification_big_text, tickerText);
            builder.setContent(contentView);
        }

        return builder.build();
    }

    /**
     * Creates a new Notification object.
     * @param context the context
     * @param tickerText the ticker text
     * @param when the when
     * @param flag the flag
     * @return the notification wrapper
     */
    public NotificationWrapper createGenericNotification(final Context context, final CharSequence tickerText,
            final long when, final int flag) {
        return createGenericNotification(context, tickerText, when, flag, -1);
    }

    /**
     * Creates a new Notification object.
     * @param context the context
     * @param tickerText the ticker text
     * @param when the when
     * @param flag the flag
     * @param icon the icon - if we don't want to use the default notification icons.
     * @return the notification wrapper
     */
    public NotificationWrapper createGenericNotification(final Context context, final CharSequence tickerText,
            final long when, final int flag, final int icon) {
        final NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
        if (icon < 0) {
            setSmallIcon(builder);
        } else {
            builder.setSmallIcon(icon);
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            builder.setColor(ContextCompat.getColor(context, R.color.notification_color));

            final RemoteViews contentView = new RemoteViews(context.getPackageName(), R.layout.generic_notification);
            contentView.setImageViewResource(R.id.generic_notification_image, NotificationFactory.getProgressSmallIcon());
            contentView.setTextViewText(R.id.generic_notification_big_text, tickerText);
            if (when > -1) {
                contentView.setTextViewText(R.id.generic_notification_when, convertLongTime(when, "hh:mm aa"));
            }
            builder.setContent(contentView);
        }
        if (flag == Notification.FLAG_AUTO_CANCEL)
            builder.setAutoCancel(true);
        builder.setTicker(tickerText);
        builder.setContentTitle(tickerText);
        builder.setWhen(when);
        builder.setLocalOnly(true);
        final Notification notification = builder.build();
        notification.flags |= flag;
        return new NotificationWrapper(builder, notification);
    }

    /**
     * Creates a new Notification object.
     * @param mParentActivity the m parent activity
     * @return the notification wrapper
     */
    public NotificationWrapper createCancelNotification(final Context mParentActivity) {
        final CharSequence cancelText = mParentActivity.getString(R.string.action_cancelled);
        return createGenericNotification(mParentActivity, cancelText);
    }

    /**
     * Creates a new Notification object.
     * @param mParentActivity the m parent activity
     * @return the notification wrapper
     */
    public NotificationWrapper createBackupFinishedNotification(final Context mParentActivity) {
        final CharSequence cancelText = mParentActivity.getString(R.string.action_cancelled);
        return createGenericNotification(mParentActivity, cancelText);
    }


    /**
     * Returns the progress notification icon.
     * @return the progress notification icon.
     */
    public static int getProgressSmallIcon() {
        return R.drawable.ic_notification;
    }

    /**
     * Returns the notification icon.
     * @return the notification icon.
     */
    public static int getSmallIcon() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            return R.drawable.ic_notification;
        }
        return R.drawable.ic_notification;
    }

    /**
     * Sets the notification icon on the notification builder object.
     * Will either be ic_launcher_white for new versions of android or ic_launcher for older versions.
     * @param notifyBuilder the notification builder object.
     * @return the notification builder so method calls can be chained.
     */
    public static NotificationCompat.Builder setSmallIcon(final NotificationCompat.Builder notifyBuilder) {
        notifyBuilder.setSmallIcon(getSmallIcon());
        return notifyBuilder;
    }

    /**
     * The Class NotificationWrapper.
     */
    public static class NotificationWrapper {

        /** The m notification. */
        private Notification mNotification;

        /** The m builder. */
        private final NotificationCompat.Builder mBuilder;

        /**
         * Instantiates a new notification wrapper.
         * @param builder the builder
         * @param notification the notification
         */
        public NotificationWrapper(final NotificationCompat.Builder builder, final Notification notification) {
            mBuilder = builder;
            mNotification = notification;
        }

        /**
         * Sets the latest event info.
         * @param context the context
         * @param contentTitle the content title
         * @param contentText the content text
         * @param contentIntent the content intent
         */
        public void setLatestEventInfo(final Context context, final CharSequence contentTitle, final CharSequence contentText,
                final PendingIntent contentIntent) {
            mBuilder.setContentTitle(contentTitle);
            mBuilder.setContentText(contentText);
            mBuilder.setContentIntent(contentIntent);

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                mBuilder.setColor(ContextCompat.getColor(context, R.color.notification_color));

                final RemoteViews contentView = new RemoteViews(context.getPackageName(), R.layout.generic_notification);
                contentView.setTextViewText(R.id.generic_notification_big_text, contentTitle);
                contentView.setTextViewText(R.id.generic_notification_small_text, contentText);
                mBuilder.setContent(contentView);
            }
            mNotification = mBuilder.build();
        }

        /**
         * Gets the notification.
         * @return the notification
         */
        public Notification getNotification() {
            return mNotification;
        }
    }

    @SuppressLint("SimpleDateFormat")
    public String convertLongTime(long millis, String timeFormat) {
        SimpleDateFormat formatter = new SimpleDateFormat(timeFormat);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return formatter.format(calendar.getTime());
    }

}

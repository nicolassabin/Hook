/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.ui.Constants;
import com.inerdev.hook.ui.MainActivity;
import com.inerdev.hook.ui.WarningActivity;
import com.inerdev.hook.ui.utils.GuiCallback;
import com.inerdev.hook.ui.utils.MySharePreferences;
import com.inerdev.hook.ui.utils.UserConnectToServer;


/**
 * The Class SplashConnectingActivity.
 */
public class SplashConnectingActivity extends AppCompatActivity implements Constants {



    /** The log tag. */
    private final String LOG_TAG = "SplashConnAct";

    /** The m preferences end point. */
    MySharePreferences mMySharePreferences;

    /** The m callback. */
    private GuiCallback<String> mCallback;

    /** The m receiver. */
    private BroadcastReceiver mReceiver = null;

    /** The m auth dialog event receiver. */
    //private AuthDialogEventReceiver mAuthDialogEventReceiver = null;

    /** The Constant CONNECTION_TIMEOUT. */
    private static final int CONNECTION_TIMEOUT = 7000;

    /** The m telephony manager. */
    private TelephonyManager mTelephonyManager;

    /** The m handler. */
    private final Handler mHandler = new Handler();

    /** The m splash logo activity. */
    @Deprecated
    private Activity mSplashLogoActivity = null;

    /** The progress splash. */
    private ProgressBar progressSplash;

    /** The m UserConnectToServer. */
    private UserConnectToServer mUserConnectToServer;

    /** The m auth dialog pending. */
    private boolean mAuthDialogPending = false;

    /** The Constant AUTH_CHECKING_DELAY_ON_RESTART. */
    private static final int AUTH_CHECKING_DELAY_ON_RESTART = 1500;

    /** The m log. */
    private Log mLog;


    /** The callback. */
    private final Runnable callback = new Runnable() {

        @Override
        public void run() {
            authenticateUser();
        }
    };


    /** The m authentication manager. */
    private AuthenticationManager mAuthenticationManager;

    /** The m restart runnable. */
    private final Runnable mRestartRunnable = new Runnable() {
        @Override
        public void run() {

            mLog.d(LOG_TAG, "resume, mRestartRunnable, ");
            if (mAuthDialogPending)// Need to skip new auth attempt if atp dialog already on the screen
            {
                // Happens when user clicks on the T&C or service link and we showed Welcome Screen to user
                mAuthDialogPending = false;
                return;
            }
            mUserConnectToServer.connectServer(mCallback);

        }
    };

    /**
     *
     */
    @SuppressLint("MissingSuperCall")
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLog.d(LOG_TAG, "> onCreate(), action: " + getIntent().getAction());
        mAuthenticationManager = ((HookApplication)this.getApplication()).getAuthenticationManagerHelper();
        mUserConnectToServer = new UserConnectToServer(this, (HookApplication)this.getApplication());

        setContentView(R.layout.splashscreen_connecting);

        //Permissions check every time inorder to disable data classes to back up.
        //mPermissionManager.evaluatePermissions();
        mTelephonyManager = (TelephonyManager) (SplashConnectingActivity.this
                .getSystemService(Context.TELEPHONY_SERVICE));
        mSplashLogoActivity = getParent();
        if (!(mSplashLogoActivity instanceof SplashLogoActivity)) {
            mSplashLogoActivity = null;
        }


        mCallback = initCallback();

        if (((HookApplication)this.getApplication()).getWifiBtStatusProvider().isWifiConnected()) {
            mLog.d(LOG_TAG, "post to auth!");
            mHandler.post(callback);
        } else {
            if (mTelephonyManager.getDataState() != TelephonyManager.DATA_CONNECTED) {
                if (mReceiver != null) {
                    unregisterReceiverSafely(mReceiver);
                    mReceiver = null;
                }
                mReceiver = new TelephonyStateListener();
                registerReceiver(mReceiver, new IntentFilter(TelephonyStateListener.ACTION));
            }
            // After few seconds terminate waiting for Data connection
            final ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = null;
            if (cm != null) {
                ni = cm.getActiveNetworkInfo();
            }
            if (ni != null) {
                if (!ni.isConnected()) {
                    mHandler.postDelayed(callback, CONNECTION_TIMEOUT);
                } else {
                    mHandler.post(callback);
                }
            } else {
                mHandler.postDelayed(callback, CONNECTION_TIMEOUT);
            }
        }

        //registerAuthDialogEventsReceiver();
        mLog.d(LOG_TAG, "< onCreate()");

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
    }

    /**
     * Inits the callback.
     * @return the gui callback
     */
    private GuiCallback<String> initCallback() {
        mLog.d(LOG_TAG, "initCallback()");
        return new GuiCallback<String>() {

            private static final String LOG_TAG = "callback";

            @Override
            public boolean onError(final Exception e) {
                mLog.d(LOG_TAG, "onError()");
                if (e == null && mAuthenticationManager.isAuthenticated()) {
                    onSuccess(new String());
                    return true;
                } else {
                    return handleGuiException(e);
                }
            }

            /**
             * Checks if is cancelled.
             *
             * @return true, if is cancelled
             */
            @Override
            public boolean isCancelled() {
                return false;
            }

            /**
             * Cancel.
             */
            @Override
            public void cancel() {

            }

            /**
             * Task cancel.
             *
             * @param task the task
             */
            @Override
            public void taskCancel(AsyncTask task) {

            }

            public void onSuccess(final String response) {
                mLog.d(LOG_TAG, "onSuccess()");
                continueAfterAuth();
            }

            /**
             * On progress.
             *
             * @param state the state
             */
            @Override
            public void onProgress(Object state) {

            }
        };
    }


    /**
     *
     */
    @Override
    public void onConfigurationChanged(final Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setContentView(R.layout.splashscreen_connecting);
    }

    /**
     *
     */
    @Override
    protected void onRestart() {
        super.onRestart();

        if (mAuthenticationManager.isAuthenticated()) {
            mLog.d(LOG_TAG, "resume, onRestart, ");
            mHandler.postDelayed(mRestartRunnable, AUTH_CHECKING_DELAY_ON_RESTART);
        }
    }

    /**
     * On search requested.
     * @return true, if successful
     */
    @Override
    public boolean onSearchRequested() {
        // ignore search button
        return false;
    }

    /* Handles close of activity. */

    /**
     *
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        //unregisterAuthDialogEventsReceiver();

        unregisterReceiverSafely(mReceiver);
        mReceiver = null;

        if (progressSplash != null) {
            progressSplash.setVisibility(View.GONE);
        }
    }

    /**
     * Authenticate user.
     */
    private synchronized void authenticateUser() {
        mLog.d(LOG_TAG, "authenticateUser start");
        unregisterReceiverSafely(mReceiver);
        mReceiver = null;

        mUserConnectToServer.connectServer(mCallback);

    }

    /**
     * Continue after auth.
     */
    private void continueAfterAuth() {
        continueStartupFlow();
    }

    /**
     * Continue startup flow.
     */
    private void continueStartupFlow() {
        mLog.d(LOG_TAG, "continueStartupFlow(), check if first launch");
        Intent intent = null;
        intent = getActionMainIntent();
        if (intent != null) {
            startActivity(intent);
        }

        // We need to finish this activity when starting the main menu
        // otherwise it gets restarted after a logout operation
        // (when the app is launched with valid tokens: e.g. no interactive auth => logout)
        finish();

        if (mSplashLogoActivity != null) {
            mSplashLogoActivity.finish();
            mSplashLogoActivity = null;
        }
    }

    /**
     * The listener interface for receiving telephonyState events. The class that is interested in processing a
     * telephonyState event implements this interface, and the object created with that class is registered with a
     * component using the component's <code>addTelephonyStateListener</code> method. When
     * the telephonyState event occurs, that object's appropriate
     * method is invoked.
     */
    class TelephonyStateListener extends BroadcastReceiver {

        /** The Constant ACTION. */
        static final String ACTION = "android.intent.action.SERVICE_STATE";

        /**
         * On receive.
         * @param context the context
         * @param intent the intent
         */
        @Override
        public void onReceive(final Context context, final Intent intent) {
            if (mTelephonyManager.getDataState() == TelephonyManager.DATA_CONNECTED) {
                authenticateUser();
            }
        }
    }

    /**
     *
     */
    @Override
    public void onResume() {
        super.onResume();

        mAuthDialogPending = false;

        //continueAfterAuth();

        if (progressSplash == null) {
            progressSplash = (ProgressBar) findViewById(R.id.progressSplash);
        }

        progressSplash.setVisibility(View.VISIBLE);


    }

    /**
     *
     */
    @Override
    protected void onPause() {
        super.onPause();
        // Fix SDCANDTACT-3145
    }

    /**
     * Handle gui exception.
     * @param e the e
     * @return true, if successful
     */
    public boolean handleGuiException(final Exception e) {
        if (e != null) {
            final Bundle b = new Bundle();
            Intent intent;
            intent = new Intent(SplashConnectingActivity.this, WarningActivity.class);
            intent.putExtras(b);
            startActivity(intent);

        }
        finish();
        return true;
    }

    /**
     * Register auth dialog events receiver.
     */
//    private void registerAuthDialogEventsReceiver() {
//        synchronized (this) {
//            mAuthDialogEventReceiver = new AuthDialogEventReceiver();
//        }
//    }

    /**
     * Unregister auth dialog events receiver.
     */
//    private void unregisterAuthDialogEventsReceiver() {
//        synchronized (this) {
//            if (mAuthDialogEventReceiver != null) {
//                unregisterReceiverSafely(mAuthDialogEventReceiver);
//                mAuthDialogEventReceiver = null;
//            }
//        }
//    }


    /**
     * The Class AuthDialogEventReceiver.
     */
//    private class AuthDialogEventReceiver extends BroadcastReceiver {
//
//        /**
//         * Instantiates a new auth dialog event receiver.
//         */
//        public AuthDialogEventReceiver() {
//            super();
//            final IntentFilter filter = new IntentFilter(AtpAuthActivity.ACTION_AUTH_DIALOG_RESUMED);
//            registerReceiver(this, filter);
//        }
//
//
//
//        /**
//         * On receive.
//         * @param arg0 the arg0
//         * @param arg1 the arg1
//         */
//        @Override
//        public void onReceive(final Context arg0, final Intent arg1) {
//            boolean appInReg = false, appForceClosed = false;
//            if (arg1 != null) {
//                appInReg = arg1.getBooleanExtra(Constants.APP_IN_REGISRATION_PROCESS, false);
//                appForceClosed = arg1.getBooleanExtra(Constants.ACTIVITY_FORCE_CLOSED, false);
//                mLog.d(LOG_TAG, "appInReg: " +appInReg);
//            }
//
//            if (arg1 == null || (!appInReg && !appForceClosed)) {
//                mLog.d(LOG_TAG, "resume, AuthDialogEventReceiver.onReceive: Finishing the retry dialog.");
//
//            } else {
//                mAuthDialogPending = appInReg;
//            }
//        }
//    }


    /**
     * Gets the action main intent.
     * @return the action main intent
     */
    public Intent getActionMainIntent() {
        Intent newIntent = new Intent(this, MainActivity.class);

        return newIntent;
    }

    /**
     * Unregister activity BroadcastReceiver
     * @param receiver
     */
    protected void unregisterReceiverSafely(BroadcastReceiver receiver) {
        if (receiver != null) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception e) {
                mLog.e(LOG_TAG, "Unable to unregisterReceiver()", e);
            }
        }
    }

}

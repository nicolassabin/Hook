/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */

package com.inerdev.hook.provider;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.BaseColumns;



/**
 * The Class AppContract.
 */
public class AppContract {

    /** The m context. */
    private final Context mContext;

    /** The Constant AUTHORITHY_SUFFIX. */
    public static final String AUTHORITHY_SUFFIX = ".hook.data";

    /**
     * Instantiates a new vault contract.
     * @param context the context
     */
    public AppContract(final Context context) {
        mContext = context;
    }

    /**
     * Gets the content authority.
     * @return the content authority
     */
    public String getContentAuthority() {
        return mContext.getPackageName() + AUTHORITHY_SUFFIX;
    }

    /**
     * Gets the base content uri.
     * @return the base content uri
     */
    public Uri getBaseContentUri() {
        return Uri.parse("content://" + getContentAuthority());
    }

    /** The Constant PATH_MESSAGES. */
    public static final String PATH_MESSAGES = "messages";

    /**
     * The Class Message.
     */
    public static class Messages implements BaseColumns {

        /** The m app contract. */
        private final AppContract mAppContract;

        /**
         * Instantiates a new messages.
         * @param appContract the app contract
         */
        public Messages(final AppContract appContract) {
            mAppContract = appContract;
        }

        /** The Constant CONTENT_TYPE. */
        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE
                + "/vnd.hookadapter.messages";

        /** The Constant CONTENT_ITEM_TYPE. */
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE
                + "/vnd.hookadapter.messages";

        /**
         * Gets the content uri.
         * @return the content uri
         */
        public Uri getContentUri() {
            return mAppContract.getBaseContentUri().buildUpon().appendPath(PATH_MESSAGES).build();
        }


        /** The Constant PENDING. */
        public static final int STATUS_PENDING = 0;

        /** The Constant SENDING. */
        public static final int STATUS_SENDING = 1;

        /** The Constant SENT. */
        public static final int STATUS_COMPLETE = 2;

        /** The Constant DELETING. */
        public static final int STATUS_DELETING = 3;

        /** The Constant DELETED. */
        public static final int STATUS_DELETED = 4;

        /** The Constant MSG_RECEIVED. */
        public static final int MSG_RECEIVED = 1;

        /** The Constant MSG_POSTED. */
        public static final int MSG_POSTED = 2;

        /** The Constant TABLE_NAME. */
        public static final String TABLE_NAME = "messages";

        /** The Constant COLUMN_SUBJECT. */
        public static final String COLUMN_SUBJECT = "subject";

        /** The Constant COLUMN_TEXT. */
        public static final String COLUMN_TEXT = "text";

        /** The Constant COLUMN_NAME_VERSION. */
        public static final String COLUMN_NAME_VERSION = "version";

        /** The Constant COLUMN_DATE_CREATION. */
        public static final String COLUMN_DATE_CREATION = "dateCreation";

        /** The Constant COLUMN_DATE. */
        public static final String COLUMN_DATE_EXPIRATION = "dateExpiration";

        /** The Constant COLUMN_ITEM_TYPE. */
        public static final String COLUMN_ITEM_TYPE = "type";

        /** The Constant COLUMN_ITEM_CATEGORY_TYPE. */
        public static final String COLUMN_ITEM_CATEGORY_TYPE = "categorytype";

        /** The Constant COLUMN_STATUS. */
        public static final String COLUMN_STATUS = "status";

        /** The Constant COLUMN_SENDER_NAME. */
        public static final String COLUMN_SENDER_NAME = "senderName";

        /** The Constant COLUMN_SENDER_ADR. */
        public static final String COLUMN_SENDER_ADR = "senderAdr";

        /** The Constant COLUMN_SENDER_DEVICE_ID. */
        public static final String COLUMN_SENDER_DEVICE_ID = "senderDeviceId";

        /** The Constant COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME. */
        public static final String COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME = "senderdeviceDisplayName";

        /** The Constant COLUMN_SERVER_ID. */
        public static final String COLUMN_SERVER_ID = "serverId";


    }

    /** The Constant PATH_DEVICES. */
    public static final String PATH_DEVICES = "devices";

    /**
     * The Class Devices.
     */
    public static class Devices implements BaseColumns {

        /** The m app contract. */
        private final AppContract mAppContract;

        /**
         * Instantiates a new messages.
         * @param appContract the app contract
         */
        public Devices(final AppContract appContract) {
            mAppContract = appContract;
        }

        /** The Constant CONTENT_TYPE. */
        public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/vnd.hookadapter.devices";

        /** The Constant CONTENT_ITEM_TYPE. */
        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE
                + "/vnd.hookadapter.devices";

        /**
         * Gets the content uri.
         * @return the content uri
         */
        public Uri getContentUri() {
            return mAppContract.getBaseContentUri().buildUpon().appendPath(PATH_DEVICES).build();
        }

        /** The Constant PENDING. */
        public static final int DEVICE_PENDING = 0;

        /** The Constant DEVICE_ACCEPTED. */
        public static final int DEVICE_ACCEPTED = 1;

        /** The Constant DEVICE_DELETING. */
        public static final int DEVICE_DELETING = 3;

        /** The Constant DEVICE_DELETED. */
        public static final int DEVICE_DELETED = 4;

        /** The Constant TABLE_NAME. */
        public static final String TABLE_NAME = "devices";

        /** The Constant COLUMN_NAME_FILE. */
        public static final String COLUMN_NAME = "name";

        /** The Constant COLUMN_DISPLAY_NAME_NAME. */
        public static final String COLUMN_DISPLAY_NAME_NAME = "displayName";

        /** The Constant COLUMN_UIID. */
        public static final String COLUMN_UIID = "uiid";

        /** The Constant COLUMN_ADDRESS. */
        public static final String COLUMN_ADDRESS = "address";

        /** The Constant COLUMN_USER_ID. */
        public static final String COLUMN_USER_ID = "userid";

        /** The Constant COLUMN_TYPE. */
        public static final String COLUMN_TYPE = "type";

        /** The Constant COLUMN_TYPE. */
        public static final String COLUMN_STATUS = "status";

        /** The Constant COLUMN_DATE_CREATION. */
        public static final String COLUMN_DATE_CREATION = "dateCreation";


    }

}

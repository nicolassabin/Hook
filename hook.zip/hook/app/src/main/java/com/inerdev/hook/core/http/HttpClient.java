package com.inerdev.hook.core.http;


import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Created by oliva on 12/05/2017.
 * refactored by Nicolas SABIN on 05/06/2017
 */

public class HttpClient {

    private static final String LOG_TAG = "HttpClient";
    private static final int TIMEOUT = 30000;
    private static final String POST_REQUEST = "POST";
    private static final String UTF8 = "UTF-8";


    private String mResult;
    private CallBackHttpRequest mCallBack;
    private int mEvent;
    private ArrayList<String> mKeys;
    private ArrayList<String> mValues;
    private Log mLog;

    public HttpClient(CallBackHttpRequest callBackHttpRequest, int event, ArrayList<String> keys, ArrayList<String> values)
    {
        this.mCallBack = callBackHttpRequest;
        this.mEvent = event;
        this.mKeys = keys;
        this.mValues = values;
    }

    public String execute(String params) {

        mLog.d(LOG_TAG, "execute params " + params.toString());
        URL url;
        HttpURLConnection urlConnection = null;
        mResult = "";
        OutputStreamWriter writer = null;
        BufferedReader reader=null;

        try {
            url = new URL(params);
            urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.setDoOutput(false);
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod(POST_REQUEST);

            urlConnection.setConnectTimeout(TIMEOUT);
            urlConnection.setReadTimeout(TIMEOUT);

            urlConnection.connect();

            String data="";
            for(int i=0;i < mKeys.size();i++)
            {
                if (i!=0)
                {
                    data += "&";
                }
                data += URLEncoder.encode(mKeys.get(i), UTF8)+"="+ URLEncoder.encode(mValues.get(i), UTF8);
            }
            mLog.d(LOG_TAG, "execute data " + data);

            //envoi de la requête
            writer = new OutputStreamWriter(urlConnection.getOutputStream());
            writer.write(data);
            writer.flush();

            reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null)
            {
                mResult+=line;
            }

            mLog.d(LOG_TAG, "execute" + mResult);

        } catch (MalformedURLException e) {
            mLog.e(LOG_TAG, "execute MalformedURLException", e);
        } catch (IOException e) {
            mLog.e(LOG_TAG, "execute IOException", e);
        }
        finally
        {
            urlConnection.disconnect();
            try{
                if (writer != null){
                    writer.close();
                }
            }
            catch(Exception e){
                mLog.e(LOG_TAG, "doInBackground writer.close Exception", e);
            }
            try{
                if (reader != null){
                    reader.close();
                }
            }catch(Exception e){
                mLog.e(LOG_TAG, "doInBackground reader.close Exception", e);
            }
        }

        if (mCallBack != null){
            mLog.d(LOG_TAG, "onRequestResult mEvent " + mEvent);
            mCallBack.onRequestResult(mResult, mEvent);
        }

        return mResult;
    }

}

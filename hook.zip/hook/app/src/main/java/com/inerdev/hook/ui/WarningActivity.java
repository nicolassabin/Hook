/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.ui.utils.LogOutTask;

/**
 * The Class WarningActivity.
 */
public class WarningActivity extends AppCompatActivity implements OnClickListener {

    /** The Constant TITLE. */
    public static final String TITLE = "TITLE";

    /** The Constant HEAD. */
    public static final String HEAD = "HEAD";

    /** The Constant BODY. */
    public static final String BODY = "BODY";

    /** The Constant BUTTON_TEXT_1. */
    public static final String BUTTON_TEXT_1 = "BUTTON";

    /** The Constant TITLE_FULL. */
    public static final String TITLE_FULL = "TITLE_FULL";

    /** The Constant HEAD_FULL. */
    public static final String HEAD_FULL = "HEAD_FULL";

    /** The Constant BODY_FULL. */
    public static final String BODY_FULL = "BODY_FULL";

    /** The Constant BACK_TO_MAIN. */
    public static final String BACK_TO_MAIN = "BACK_TO_MAIN";

    /** The Constant DO_EXIT. */
    public static final String DO_EXIT = "DO_EXIT";

    /** The Constant DO_LOGOUT. */
    public static final String DO_LOGOUT = "DO_LOGOUT";

    /** The Constant DO_INTENT_ACTIVITY_MANAGER_EXIT. */
    public static final String DO_INTENT_ACTIVITY_MANAGER_EXIT = "do_intent_activity_manager_exit";

    /** The m back to main. */
    protected boolean mBackToMain = false;

    /** The m do exit. */
    protected boolean mDoExit = false;

    /** The m do log out. */
    protected boolean mDoLogOut = false;

    /** The m do intent activity manager exit. */
    protected boolean mDoIntentActivityManagerExit = false;

    /** The m is for result. */
    protected boolean mIsForResult = false;

    /**
     */
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alert_dialog);
        mBackToMain = false;
        mDoExit = false;
        initFields();
    }

    /**
     * Inits the fields.
     */
    private void initFields() {
        setTitle(TITLE, TITLE_FULL);
        setText(R.id.dialog_message, HEAD, HEAD_FULL);
        setText(R.id.dialog_message1, BODY, BODY_FULL);

        final Bundle extras = getIntent().getExtras();
        if (extras != null) {
            mBackToMain = extras.getBoolean(BACK_TO_MAIN);
            mDoExit = extras.getBoolean(DO_EXIT);
            mDoLogOut = extras.getBoolean(DO_LOGOUT);
            mDoIntentActivityManagerExit = extras.getBoolean(DO_INTENT_ACTIVITY_MANAGER_EXIT);
        } else {
            mBackToMain = false;
            mDoExit = false;
            mDoLogOut = false;
            mDoIntentActivityManagerExit = false;
        }
        mIsForResult = isForResult();
        if (mIsForResult) {
            setResult(RESULT_CANCELED);
        }

        final Button buttonLeft = (Button) findViewById(R.id.dialog_button_left);
        final Button buttonRight = (Button) findViewById(R.id.dialog_button_right);
        String buttonString = getString(R.string.ok);
        final int stringMessageId = extras != null ? extras.getInt(BUTTON_TEXT_1) : 0;
        if (stringMessageId != 0) {
            buttonString = getString(stringMessageId);
        }
        buttonRight.setText(buttonString);
        if (extras != null && extras.getBoolean(getString(R.string.cancel))) {
            buttonLeft.setText(getString(R.string.cancel));
        }
    }

    /**
     * Checks if is for result.
     * @return true, if is for result
     */
    protected boolean isForResult() {
        return false;
    }

    /**
     * On new intent.
     * @param intent the intent
     */
    @Override
    protected void onNewIntent(final Intent intent) {
        super.onNewIntent(intent);
        initFields();
    }

    /**
     * Sets the text.
     * @param destinationId the destination id
     * @param name the name
     * @param fullName the full name
     */
    private void setText(final int destinationId, final String name, final String fullName) {
        final TextView view = (TextView) findViewById(destinationId);
        final Bundle extras = getIntent().getExtras();
        final int stringMessageId = extras != null ? extras.getInt(name) : 0;
        final String stringMessage = extras != null ? extras.getString(fullName) : null;
        // if id specified
        if (stringMessageId != 0) {
            view.setText(stringMessageId);
            view.setVisibility(View.VISIBLE);
        } else if (stringMessage != null) {
            // if id not specified but string specified
            view.setText(stringMessage);
            view.setVisibility(View.VISIBLE);
        } else {
            view.setVisibility(View.GONE);
        }
    }

    /**
     * Sets the title.
     * @param name the name
     * @param fullName the full name
     */
    private void setTitle(final String name, final String fullName) {
        final Bundle extras = getIntent().getExtras();
        final TextView dialogTitle = (TextView) findViewById(R.id.title);
        final int stringMessageId = extras != null ? extras.getInt(name) : 0;
        final String stringMessage = extras != null ? extras.getString(fullName) : null;
        // if id specified
        if (stringMessageId != 0) {
            dialogTitle.setText(stringMessageId);
            // For Accessibility TalkBack service, for more info see SDCANDTACT-6773
            setTitle(stringMessageId);
        } else if (stringMessage != null) {
            // if id not specified but string specified
            dialogTitle.setText(stringMessage);
            // For Accessibility TalkBack service, for more info see SDCANDTACT-6773
            setTitle(stringMessage);
        }
    }

    /**
     * Exit on intent activity manager launch.
     */
    private void exitOnIntentActivityManagerLaunch() {
        finish();
    }

    /**
     * Do close.
     * @param returnFlag the return flag
     * @return true, if successful
     */
    protected boolean doClose(boolean returnFlag) {
        if (mDoIntentActivityManagerExit) {
            exitOnIntentActivityManagerLaunch();
            return false;
        }

        if (mBackToMain) {
            finish();
            final Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            returnFlag = true;
        } else if (mDoLogOut) {
            final LogOutTask logout = new LogOutTask(this,
                    ((HookApplication)this.getApplication()).getAuthenticationManagerHelper(),
                    this);
            logout.execute();
        }
        return returnFlag;
    }

    /**
     *
     */
    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {
        boolean res = super.onKeyDown(keyCode, event);
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            res = doClose(res);
        }
        return res;
    }

    /**
     * On click.
     * @param view the view
     */
    @Override
    public void onClick(final View view) {
        if (mIsForResult) {
            setResult(RESULT_OK);
        }

        if (!doClose(false)) {
            finish();
        }
    }

    /**
     *
     */
    @Override
    protected void onPause() {
        super.onPause();
        if (mDoIntentActivityManagerExit) {
            exitOnIntentActivityManagerLaunch();
        }
    }

}

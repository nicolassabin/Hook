package com.inerdev.hook.core.retrofit;


import com.inerdev.hook.core.auth.AuthenticationStorage;
import com.inerdev.hook.core.retrofit.model.Device;
import com.inerdev.hook.core.retrofit.model.Devices;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by nicolas on 02/12/2016.
 */

public interface DevicesApi {

    /** The header accept atp json. */
    String APPLICATION_JSON = "application/json";

    /** The header accept devices json. */
    String HEADER_ACCEPT_DEVICES_JSON = "Accept: " + APPLICATION_JSON;

    /**
     * The header content type devices xml.
     */
    String HEADER_CONTENT_TYPE_DEVICES_JSON = "Content-Type: application/x-www-form-urlencoded";

    /**
     * create/update Device.
     *
     * @return - Device
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @GET("{userId}/device")
    Devices getDeviceInfo(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                          @Path("userId") String userId);

    /**
     * create/update Device.
     *
     * @return - Device
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @POST("{userId}/device")
    Device updateDevice(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                        @Path("userId") String userId,
                        @Field("name") String name,
                        @Field("displayName") String displayName,
                        @Field("address") String address,
                        @Field("type") String type,
                        @Field("key") String key);

    /**
     * create/update Device.
     *
     * @return - Device
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @POST("{userId}/device")
    Device updateDevice(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                        @Path("userId") String userId,
                        @Body Device device);

    /**
     * delete Device.
     *
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @DELETE("{userId}/device")
    Call<ResponseBody> sessionsDelete(@Path("userUid") String userId, @Path("Id") String deviceId);

}

package com.inerdev.hook.ui.widgets;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.TextView;

import com.inerdev.hook.R;


/**
 * Created by viacheslav.vdovenko on 22/10/2015.
 */
public class CustomTextView extends AppCompatTextView {

    public CustomTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        final TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsCustomTextView);
        final String fontFile = a.getString(R.styleable.UIWidgetsCustomTextView_fontFile);
        if(!TextUtils.isEmpty(fontFile)) {
            setFontTypeface(context.getAssets(), fontFile);
        }
        a.recycle();
    }

    /**
     * Set the font type face from assets ttf file
     * @param mgr - AssetManager
     * @param fontFile - ttf file name from assets folder
     */
    public void setFontTypeface(AssetManager mgr, String fontFile) {
        final Typeface font = Typeface.createFromAsset(mgr, fontFile);
        if(font != null) {
            setTypeface(font);
        }
    }
}

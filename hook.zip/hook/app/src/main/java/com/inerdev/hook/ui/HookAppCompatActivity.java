package com.inerdev.hook.ui;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.ui.utils.PermissionManager;


public abstract class HookAppCompatActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final String TAG = "HookAppCompatActivity";

    // UI references.
    protected HookApplication mHookApplication;

    /** The m log. */
    protected Log mLog;

    /**
     * the m PermissionManager
     */
    private PermissionManager mPermissionManager = new PermissionManager();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHookApplication = (HookApplication) getApplication();

    }


    @Override
    protected void onResume() {
        super.onResume();
        mPermissionManager.checkAllPermission(this);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case PermissionManager.MY_ALL_PERMISSIONS_REQUEST: {
                if (permissions.length>0){
                    // If request is cancelled, the result arrays are empty.
                    if (grantResults.length > 0
                            && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                        // permission was granted, yay! Do the
                        // contacts-related task you need to do.
                        mLog.i(TAG, "onRequestPermissionsResult permission granted, let's go!");

                    } else {

                        // permission denied, boo! Disable the
                        // functionality that depends on this permission.
                        mLog.e(TAG, "onRequestPermissionsResult permission not granted");
                        finish();
                        return;
                    }
                }

            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

    }


}


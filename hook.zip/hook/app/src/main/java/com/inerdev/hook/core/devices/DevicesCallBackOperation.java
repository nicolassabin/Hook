
package com.inerdev.hook.core.devices;


import java.util.List;

/**
 * The Interface DevicesCallBackOperation.
 */
public interface DevicesCallBackOperation {

    /**
     * on starting
     */
    public void onStarting();

    /**
     * on onProgress
     * @param deviceInfo
     */
    public void onProgress(DeviceInfo deviceInfo);

    /**
     * on End
     */
    public void onEnd();

    /**
     * on onError
     * @param error
     */
    public void onError(int error);



}
package com.inerdev.hook.core.auth;

/**
 * Created by nsab0001 on 12/05/2007.
 */

/**
 * The listener interface for receiving IAuthenticationManager events. The class that is interested in processing a
 * IAuthenticationManager event implements this interface, and the object created with that class is registered with
 * a component using the component's <code>addIAuthenticationManagerListener<code> method. When
 * the IAuthenticationManager event occurs, that object's appropriate
 * method is invoked.
 */
public interface AuthenticationManagerListener {

    /**
     * On authentication success.
     */
    public void onAuthenticationSuccess();

    /**
     * On authentication error.
     */
    public void onAuthenticationError();

    /**
     * On logout.
     */
    public void onLogout();
}
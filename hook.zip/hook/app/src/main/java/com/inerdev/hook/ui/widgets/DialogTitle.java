/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.inerdev.hook.R;


/**
 * The Class DialogTitle.
 */
public class DialogTitle extends FrameLayout {

    /** The m inflater. */
    private final LayoutInflater mInflater;

    /** The m dialog tite text view. */
    private final TextView mDialogTiteTextView;

    /**
     * Instantiates a new dialog title.
     * @param context the context
     * @param attrs the attrs
     */
    public DialogTitle(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View view = mInflater.inflate(R.layout.uiwidgets_dialog_title, null);
        mDialogTiteTextView = (TextView) view.findViewById(R.id.uiwidgets_dialog_title);
        addView(view);

        final TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsDialogTitle);
        final CharSequence value = a.getString(R.styleable.UIWidgetsDialogTitle_text);
        if (!TextUtils.isEmpty(value)) {
            setText(value);
        }
        a.recycle();
    }

    /**
     * Gets the text.
     * @return the text
     */
    public CharSequence getText() {
        return mDialogTiteTextView.getText();
    }

    /**
     * Sets the text.
     * @param title the new text
     */
    public void setText(final String title) {
        mDialogTiteTextView.setText(title);
    }

    /**
     * Sets the text.
     * @param resId the new text
     */
    public void setText(final int resId) {
        mDialogTiteTextView.setText(resId);
    }

    /**
     * Sets the text.
     * @param title the new text
     */
    public void setText(final CharSequence title) {
        mDialogTiteTextView.setText(title);
    }
}

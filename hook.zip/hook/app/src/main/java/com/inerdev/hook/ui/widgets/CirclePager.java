/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

import android.support.v4.view.ViewPager;

/**
 * The Interface CirclePager.
 */
public interface CirclePager extends ViewPager.OnPageChangeListener {

    /**
     * Bind the indicator to a ViewPager.
     * @param view the new view pager
     */
    void setViewPager(ViewPager view);

    /**
     * Bind the indicator to a ViewPager.
     * @param view the view
     * @param initialPosition the initial position
     */
    void setViewPager(ViewPager view, int initialPosition);

    /**
     * <p>
     * Set the current page of both the ViewPager and indicator.
     * </p>
     * <p/>
     * <p>
     * This <strong>must</strong> be used if you need to set the page before the views are drawn on screen (e.g.,
     * default start page).
     * </p>
     * @param item the new current item
     */
    void setCurrentItem(int item);

    /**
     * Set a page change listener which will receive forwarded events.
     * @param listener the new on page change listener
     */
    void setOnPageChangeListener(ViewPager.OnPageChangeListener listener);

    /**
     * Notify the indicator that the fragment list has changed.
     */
    void notifyDataSetChanged();
}

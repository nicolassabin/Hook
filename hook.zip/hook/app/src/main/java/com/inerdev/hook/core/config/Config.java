package com.inerdev.hook.core.config;

/**
 * Created by nsab0001 on 15/05/2017.
 */

/**
 * Interface for all config
 */
public interface Config {

    /**
     * Retrieves the global configuration from the end point.
     *
     * @param endPointUri
     * @return true to indicate retrieve is well passed
     */
    boolean retrieveConfig(final String endPointUri);

    /**
     * Retrieves the default configuration without connecting to the end point.
     *
     * @return : IConfigInfo The details of the default configuration
     */
    ConfigInfo getConfig();

}
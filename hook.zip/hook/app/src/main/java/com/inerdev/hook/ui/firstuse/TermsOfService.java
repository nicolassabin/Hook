/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;


/**
 * The Class TermsOfService.
 */
public class TermsOfService extends AppCompatActivity implements View.OnClickListener {

    /**
     * The INTENT_PARAM_ACCEPT_BUTTON.
     */
    public static final String INTENT_PARAM_ACCEPT_BUTTON = "INTENT_PARAM_ACCEPT_BUTTON";

    /**
     * The m web view.
     */
    private WebView mWebView;

    /**
     * The m mAgreeButton.
     */
    private View mAgreeButton;

    /**
     *
     */
    @Override
    @SuppressLint("SetJavaScriptEnabled")
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setLogo(R.drawable.empty);
            actionBar.setHomeAsUpIndicator(null);
            actionBar.setTitle(R.string.splash_screen_tos);
        }
        setContentView(R.layout.terms_of_service);
        setProgressBarIndeterminateVisibility(true);

        Intent intent = getIntent();
        if (intent != null) {
            if (intent.getBooleanExtra(INTENT_PARAM_ACCEPT_BUTTON, false)) {
                mAgreeButton = findViewById(R.id.agreeButton);
                mAgreeButton.setVisibility(View.VISIBLE);
                if (mAgreeButton != null) {
                    mAgreeButton.setOnClickListener(this);
                }
            }
        }
        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.setWebViewClient(new WebClient());

        mWebView.loadUrl(getString(R.string.eula_url));
    }

    /**
     * The Class WebClient.
     */
    private class WebClient extends WebViewClient {

        /**
         * Should override url loading.
         *
         * @param view the view
         * @param url  the url
         * @return true, if successful
         */
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return false;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            Toast.makeText(TermsOfService.this, "Oh no! " + description, Toast.LENGTH_SHORT).show();
        }

        /**
         * On page finished.
         *
         * @param view the view
         * @param url  the url
         */
        @Override
        public void onPageFinished(final WebView view, final String url) {
            setSupportProgressBarIndeterminateVisibility(false);
        }
    }

    /**
     * On options item selected.
     *
     * @param item the item
     * @return true, if successful
     */
    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.agreeButton) {
            launchAuth();
        }
    }

    private String getIntentAction(String actionSuffix) {
        return String.format("%s%s", getPackageName(), actionSuffix);
    }

    private void launchAuth() {
        Intent intent = new Intent(getIntentAction(AuthenticationManager.INTENT_ACTION_AUTH));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}


package com.inerdev.hook.ui.messages;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.messages.MessagesCallBackOperation;
import com.inerdev.hook.core.messages.MessagesManager;
import com.inerdev.hook.provider.AppContract;


public class IncommingMsgBoxFragment extends BMsgFragment implements MessagesCallBackOperation {

    private static final String TAG = "IncommingMsgBox - ";

    private MessagesManager mMessagesManager;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        mId = 1;
        mActionMenu = this;
        mMsgType = AppContract.Messages.MSG_RECEIVED;
        super.onCreate(savedInstanceState);
        mMessagesManager = ((HookApplication)getActivity().getApplication()).getMessagesManager();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // reset all messages for the moment
        deleteAll();
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        mMessagesManager.addListener(this);
        return rootView;
    }

    @Override
    public void onDetach() {
        mLog.d(TAG, "onDetach");
        mMessagesManager.stopScanning();
        mMessagesManager.removeListener(this);
        super.onDetach();
    }

    @Override
    public void refresh() {
        mLog.d(TAG, "refresh");
        ((HookApplication)getActivity().getApplication()).cancelNotification(HookApplication.MESSAGES_NOTIFICATION_ID);
        // retrieve all devices from database in order to get the userid
        mMessagesManager.startScanning();
        super.refresh();
    }


    /**
     * on starting
     */
    @Override
    public void onStarting() {
        mLog.d(TAG, "onStarting");

    }

    /**
     * on onProgress
     * @param userId
     */
    @Override
    public void onProgress(String userId) {
        mLog.d(TAG, "onProgress userId " + userId);

    }

    /**
     * on End
     */
    @Override
    public void onEnd() {
        mLog.d(TAG, "onEnd");
        refreshData();
    }

    /**
     * on onError
     *
     * @param error
     */
    @Override
    public void onError(int error) {
        mLog.d(TAG, "onError error " + error);
    }
}

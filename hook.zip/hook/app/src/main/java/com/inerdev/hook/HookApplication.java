package com.inerdev.hook;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.core.auth.AuthenticationManagerHelper;
import com.inerdev.hook.core.config.ConfigHelper;
import com.inerdev.hook.core.devices.DevicesManager;
import com.inerdev.hook.core.devices.DevicesManagerImpl;
import com.inerdev.hook.core.messages.MessagesJobScheduler;
import com.inerdev.hook.core.messages.MessagesManager;
import com.inerdev.hook.core.messages.MessagesManagerImpl;
import com.inerdev.hook.provider.AppContract;
import com.inerdev.hook.ui.MainActivity;
import com.inerdev.hook.ui.utils.MySharePreferences;
import com.inerdev.hook.ui.utils.NotificationFactory;
import com.inerdev.hook.ui.utils.WifiBtStatusProvider;

/**
 * Created by ns on 10/05/2017.
 */
public class HookApplication extends Application {

    /** The Constant MESSAGES_NOTIFICATION_ID. */
    public static final int MESSAGES_NOTIFICATION_ID = 1;

    /** First Marketing carousel. */
    private static String HookApplication  = "HookApplication";

    private ConfigHelper mConfigHelper;
    private AuthenticationManagerHelper mAuthenticationManagerHelper;
    private WifiBtStatusProvider mWifiBtStatusProvider;
    private  MySharePreferences mMySharePreferences;
    private AppContract mAppContract;
    private DevicesManager mDevicesManager;
    private MessagesManager mMessagesManager;
    private MessagesJobScheduler mMessagesJobScheduler;
    private NotificationFactory mNotificationFactory;

    /**
     * On create.
     */
    public void onCreate() {
        super.onCreate();
        mConfigHelper = new ConfigHelper(this.getApplicationContext());
        mAuthenticationManagerHelper = new AuthenticationManagerHelper(this.getApplicationContext(), mConfigHelper);
        mWifiBtStatusProvider =  new WifiBtStatusProvider(this.getApplicationContext());
        mMySharePreferences = new MySharePreferences(this, HookApplication);
        mAppContract = new AppContract(this.getApplicationContext());
        mDevicesManager = new DevicesManagerImpl(this.getApplicationContext(), mConfigHelper);
        mMessagesManager = new MessagesManagerImpl(this.getApplicationContext(), mConfigHelper);
        mMessagesJobScheduler = new MessagesJobScheduler(this.getApplicationContext());
        mNotificationFactory = new NotificationFactory();
    }

    /**
     * On terminate.
     */
    @Override
    public void onTerminate() {
        mMessagesJobScheduler.cancelScheduler();
        super.onTerminate();
    }

    /**
     * get Config.
     * @return Config
     */
    public ConfigHelper getConfigHelper() {
        return mConfigHelper;
    }

    /**
     * get AuthenticationManagerHelper.
     * @return AuthenticationManagerHelper
     */
    public AuthenticationManager getAuthenticationManagerHelper() {
        return mAuthenticationManagerHelper;
    }

    /**
     * get WifiBtStatusProvider.
     * @return WifiBtStatusProvider
     */
    public WifiBtStatusProvider getWifiBtStatusProvider() {
        return mWifiBtStatusProvider;
    }

    /**
     * get MySharePreferences.
     * @return MySharePreferences
     */
    public MySharePreferences getMySharePreferences() {
        return mMySharePreferences;
    }

    /**
     * get mAppContract.
     * @return mAppContract
     */
    public AppContract getAppContract() {
        return mAppContract;
    }

    /**
     * get mDevicesManager.
     * @return DevicesManager
     */
    public DevicesManager getDevicesManager() {
        return mDevicesManager;
    }

    /**
     * get MessagesManager.
     * @return MessagesManager
     */
    public MessagesManager getMessagesManager() {
        return mMessagesManager;
    }

    /**
     * get mMessagesJobScheduler.
     * @return mMessagesJobScheduler
     */
    public MessagesJobScheduler getMessagesJobScheduler() {
        return mMessagesJobScheduler;
    }

    /**
     * get mNotificationFactory.
     * @return mNotificationFactory
     */
    public NotificationFactory getNotificationFactory() {
        return mNotificationFactory;
    }

    /**
     * Show message notification.
     * @param id the id
     * @param text the text
     */
    public void showMessageNotification(final int id, final String text) {
        showMessageNotification(id, this.getText(R.string.app_name), text);
    }

    /**
     * Cancel notification.
     * @param notificationId the notification id
     */
    public void cancelNotification(final int notificationId) {
        final NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(notificationId);
    }

    /**
     * Show message notification.
     * @param id the id
     * @param title the title
     * @param text the text
     */
    @SuppressWarnings("WrongConstant")
    private void showMessageNotification(final int id, final CharSequence title, final String text) {
        final NotificationFactory.NotificationWrapper notification = mNotificationFactory.
                createGenericNotification(getApplicationContext(), text,
                        System.currentTimeMillis(), Notification.FLAG_AUTO_CANCEL);

        notification.setLatestEventInfo(this, title, text, null);

        final Intent intent = new Intent(this.getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        notification.getNotification().contentIntent = PendingIntent.getActivity(this, 0, intent,
                intent.FLAG_ACTIVITY_NEW_TASK);
        ((NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, notification.getNotification());
    }
}

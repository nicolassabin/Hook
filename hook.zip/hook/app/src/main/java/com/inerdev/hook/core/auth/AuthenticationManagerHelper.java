package com.inerdev.hook.core.auth;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.ErrorCode;
import com.inerdev.hook.core.config.ConfigHelper;
import com.inerdev.hook.provider.AppContract;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.inerdev.hook.core.ErrorCode.OPERATION_UNAUTHORIZED;

/**
 * Created by nsab0001 on 15/05/2017.
 */

public class AuthenticationManagerHelper implements AuthenticationManager{
    private static final String LOG_TAG = "ConfigHelper";

    /**
     * The Constant REFRESH_TOKEN_AUTH_ATTEMPTS.
     */
    private static final int REFRESH_TOKEN_AUTH_ATTEMPTS = 2;

    /** The default token ID. */
    private static final String DEFAULT_ID = "1";

    /**
     * The m Token Refreshing.
     */
    private final AtomicBooleanMap mTokenRefreshing = new AtomicBooleanMap();

    /**
     * The m Token Refreshing.
     */
    private AuthenticationInfo mAuthenticationInfo;

    /**
     * The m AuthenticationUIController.
     */
    private AuthenticationUIController mAuthenticationUIController;

    /**
     * The m AuthenticationStorage.
     */
    private AuthenticationStorage mAuthenticationStorage;

    /**
     * The m ConfigHelper.
     */
    private ConfigHelper mConfigHelper;

    /** The m i authentication manager listeners. */
    protected List<AuthenticationManagerListener> mIAuthenticationManagerListeners
            = new ArrayList<>();

    /** The m log. */
    private Log mLog;

    /** The m Context. */
    private Context mContext;

    /** The m mAuthBackendHelper. */
    private AuthBackendHelper mAuthBackendHelper;


    public AuthenticationManagerHelper(final Context context, final ConfigHelper configHelper){
        mContext = context;
        mAuthenticationStorage = new AuthenticationStorage(context);
        mAuthenticationInfo = new AuthenticationInfo(mAuthenticationStorage.getDvUserUid(),
                mAuthenticationStorage.getShortLivedToken(),
                mAuthenticationStorage.getContextToken(),
                mAuthenticationStorage.getAccountName(), new Date(), mAuthenticationStorage.getDeviceAdr());
        mConfigHelper = configHelper;
        mAuthenticationUIController = new AuthenticationUIController(context, configHelper, mAuthenticationStorage);
        mAuthBackendHelper = new AuthBackendHelper(mContext);
    }

    public AuthenticationManagerHelper(final Context context, final ConfigHelper configHelper,
                                       final AuthenticationStorage authenticationStorage,
                                       final AuthenticationUIController authenticationUIController,
                                       final AuthBackendHelper authBackendHelper){
        mContext = context;
        mAuthenticationInfo = new AuthenticationInfo("","","","", new Date(), "");
        mAuthenticationStorage = authenticationStorage;
        mConfigHelper = configHelper;
        mAuthenticationUIController = authenticationUIController;
        mAuthBackendHelper = authBackendHelper;
    }

    /**
     * Provides the current authentication information.
     *
     * @return The current authentication information. Refer to {@link AuthenticationInfo}
     */
    @Override
    public AuthenticationInfo getAuthenticationInfo() {
        return mAuthenticationInfo;
    }


    /**
     * isAuthenticated.
     *
     * @return boolean
     */
    @Override
    public boolean isAuthenticated() {
        if (getAuthenticationInfo() == null) {
            return false;
        }

        if (TextUtils.isEmpty(getAccessToken())) {
            return false;
        }
        if (TextUtils.isEmpty(getUserUid())) {
            return false;
        }

        return true;
    }


        /**
         * refresh the auth token if needed.
         *
         * @return the auth token if needed
         * @throws AuthenticationException the auth model exception
         */
    @Override
    public String refreshAuthTokenIfNeeded() throws AuthenticationException {
        mLog.d(LOG_TAG, "refreshAuthTokenIfNeeded");
        return getAuthenticationToken(isAuthenticated());
    }

    /**
     * Refresh access token ex.
     *
     * @throws AuthenticationException the authentication exception
     */
    @Override
    public String refreshAccessToken() throws AuthenticationException {
        mLog.d(LOG_TAG, "refreshAccessToken user accessInfoId ");

        int retry = 0;
        boolean isRefreshing;

        do {
            if(!mTokenRefreshing.compareAndSet(DEFAULT_ID))
            {
                isRefreshing = true;

                mLog.d(LOG_TAG, "myRefreshAccessToken pending, waiting end ");

                try {
                    AtomicResult result = mTokenRefreshing.wait(DEFAULT_ID);
                    if(result != null)
                    {
                        if(result.hasErrorOccurred())
                        {
                            throw new AuthenticationException(result.getErrorCode());
                        }

                        String shortLivedToken  = mAuthenticationStorage.getShortLivedToken();
                        String contextToken     = mAuthenticationStorage.getContextToken();

                        mLog.d(LOG_TAG, "myRefreshAccessToken end waiting " + shortLivedToken + " " + contextToken);

                        return contextToken;
                    }
                    else if(retry < 3)
                    {
                        retry++;
                    }
                    else
                    {
                        mLog.e(LOG_TAG, "myRefreshAccessToken - Failed ");
                        throw new AuthenticationException(ErrorCode.OPERATION_FAILED);
                    }
                }
                catch(InterruptedException ex)
                {
                    mLog.e(LOG_TAG, "myRefreshAccessToken - InterruptedException ", ex);
                    throw new AuthenticationException(ErrorCode.OPERATION_INTERRUPTED);
                }
            }
            else
            {
                isRefreshing = false;
            }
        }
        while(isRefreshing);

        ErrorCode errorCode = null;

        try
        {
            for (int attempt = 0; attempt < REFRESH_TOKEN_AUTH_ATTEMPTS; attempt++) {
                try
                {
                    mLog.d(LOG_TAG, "refreshAccessToken default token to be refreshed : " + mAuthenticationStorage == null ? "null" : mAuthenticationStorage.getContextToken());

                    if (mAuthenticationStorage != null && !TextUtils.isEmpty(mAuthenticationStorage.getContextToken())) {
                        // TODO to change later
                        //mAtpHelper.doAuth(mAuthenticationStorage.getDvUserUid(), mAuthenticationStorage.getContextToken(), false);
                        String token = mAuthenticationStorage.getDvUserUid()+mAuthenticationStorage.getContextToken();
                        mAuthenticationStorage.setShortLivedToken(String.valueOf(token.hashCode()));


                        if (!TextUtils.isEmpty(mAuthenticationStorage.getShortLivedToken())) {
                            if (mAuthenticationInfo != null) {
                                mAuthenticationInfo.setInfo(mAuthenticationStorage.getDvUserUid(),
                                        mAuthenticationStorage.getShortLivedToken(),
                                        mAuthenticationStorage.getContextToken(),
                                        mAuthenticationStorage.getAccountName(),
                                        new Date(mAuthenticationStorage.getExpirationTime()),
                                                mAuthenticationStorage.getDeviceAdr());
                            }
                            else
                            {
                                mAuthenticationInfo = new AuthenticationInfo(
                                        mAuthenticationStorage.getDvUserUid(),
                                        mAuthenticationStorage.getShortLivedToken(),
                                        mAuthenticationStorage.getContextToken(),
                                        mAuthenticationStorage.getAccountName(),
                                        new Date(mAuthenticationStorage.getExpirationTime()),
                                        mAuthenticationStorage.getDeviceAdr());
                            }

                            return mAuthenticationStorage.getShortLivedToken();
                        }
                    } else {
                        mLog.e(LOG_TAG, "refreshAccessToken, no context token");
                        errorCode = ErrorCode.INVALID_PARAMETER;
                        throw new AuthenticationException(ErrorCode.INVALID_PARAMETER);
                    }
                }
                catch (final AuthenticationException e)
                {
                    mLog.e(LOG_TAG, "refreshAccessToken, AtpLoginFailedException: ", e);
                }
            }
            errorCode = ErrorCode.OPERATION_FAILED;
            throw new AuthenticationException(ErrorCode.OPERATION_FAILED);
        }
        catch (final AuthenticationException e) {
            mLog.e(LOG_TAG, "refreshAccessToken, AtpLoginUnauthorizedException: ", e);
            clearStorage();
            errorCode = ErrorCode.OPERATION_UNAUTHORIZED;
            throw new AuthenticationException(ErrorCode.OPERATION_UNAUTHORIZED);
        }
        finally {
            mLog.d(LOG_TAG, "myRefreshAccessToken end ");
            mTokenRefreshing.resetAndNotify(DEFAULT_ID, errorCode);
        }
    }

    /**
     * Stores the access token as expired access token for the lifetime of the process
     * <p class="note">
     * This call is used by classes that directly execute requests against the backend (adding the access token used in
     * requests that return 401/403 HTTP Status Code).
     *
     * @param accessToken The access token that is known to be expired
     */
    @Override
    public void addExpiredAccessToken(String accessToken) {
        mLog.d(LOG_TAG, "addExpiredAccessToken");
        mAuthenticationStorage.addExpiredAccessToken(accessToken);
    }

    /**
     * Authenticates the client.
     *
     * @param login    The user identifier
     * @param password The user password, or null when authenticationKey is OAUTH_TOKEN
     * @param deviceAdr The deviceAdr
     * @return AuthenticationInfo the AuthenticationInfo.
     * @throws AuthenticationException Occurs when the authentication operation fails and no callback has been provided.
     */
    @Override
    public AuthenticationInfo signin(final String login, final String password, final String deviceAdr) throws AuthenticationException {
        mLog.d(LOG_TAG, "signin");
        checkParameters(login);

        if (!TextUtils.isEmpty(mConfigHelper.getConfig().getAuthUrl())) {
            try {

                if (mAuthBackendHelper.authenticate(
                        mConfigHelper.getConfig().getServerUrl(),
                        login,
                        password, deviceAdr)){
                    String token = mAuthBackendHelper.getToken();
                    mAuthenticationStorage.setShortLivedToken(token);
                    Log.d(LOG_TAG, "signin successfull token " +
                            mAuthenticationStorage.getShortLivedToken()
                        + " getUserId() " + mAuthBackendHelper.getUserId()
                            + " getLogin() " + mAuthBackendHelper.getLogin()
                            + " getUserName() " + mAuthBackendHelper.getUserName()
                            + " getDeviceAdr() " + mAuthBackendHelper.getDeviceAdr());

                }
                //
                if (!TextUtils.isEmpty(mAuthenticationStorage.getShortLivedToken())) {
                    mAuthenticationStorage.setDvUserUid(mAuthBackendHelper.getUserId());
                    mAuthenticationStorage.setAccountName(mAuthBackendHelper.getUserName());
                    mAuthenticationStorage.setDeviceAdr(mAuthBackendHelper.getDeviceAdr());
                    mAuthenticationInfo = new AuthenticationInfo(
                            mAuthenticationStorage.getDvUserUid(),
                            mAuthenticationStorage.getShortLivedToken(),
                            mAuthenticationStorage.getContextToken(),
                            mAuthenticationStorage.getAccountName(),
                            new Date(mAuthenticationStorage.getExpirationTime()),
                            mAuthenticationStorage.getDeviceAdr());

                    onAuthenticationSuccess();
                    return mAuthenticationInfo;
                } else {
                    onAuthenticationError();
                    throw new AuthenticationException(
                            ErrorCode.INVALID_PARAMETER);
                }
            }
            catch (final AuthenticationException e) {
                mLog.e(LOG_TAG, "Authenticate, AuthenticationException: ", e);
                onAuthenticationError();
                throw new AuthenticationException(
                        ErrorCode.OPERATION_FAILED);
            }
        } else {
            onAuthenticationError();
            mLog.e(LOG_TAG, "Authenticate, failed to retrieve config: ");
            throw new AuthenticationException(
                    ErrorCode.INVALID_PARAMETER);

        }
    }

    /**
     * Logs out the user account. After this call, Personal Cloud service requests will fail until a new login is
     * performed using the API {@link #signin(String, String, String)}
     *
     * @return true if logout is sucessfull, false othernwise .
     * @throws AuthenticationException
     */
    @Override
    public void logout() throws AuthenticationException {
        mLog.d(LOG_TAG, "logout");
        if (mAuthBackendHelper.logout()){
            clearStorage();
        }else {
            mLog.e(LOG_TAG, "logout failed");
        }

    }

    /**
     * The API for provisioning a new account.
     *
     * @param signupInfo The necessary information for creating the account. Refer to {@link SignupInfo}
     * @return AuthenticationInfo the AuthenticationInfo.
     * @throws AuthenticationException Raised when provisioning fails.
     */
    @Override
    public AuthenticationInfo signup(SignupInfo signupInfo) throws AuthenticationException {
        mLog.d(LOG_TAG, "signup");
        return mAuthenticationInfo;
    }

    /**
     * Used when the user has forgotten their password.
     *
     * @param keyValue String
     * @return true if logout is sucessfull, false othernwise .
     * @throws AuthenticationException
     */
    @Override
    public void forgotPassword(String keyValue) throws AuthenticationException {
        mLog.d(LOG_TAG, "forgotPassword");

    }

    /**
     * addListener: add the listener to the specific list.
     * @param iAuthenticationManagerListener the i authentication manager listener
     */
    @Override
    public void addListener(final AuthenticationManagerListener iAuthenticationManagerListener) {
        if (mIAuthenticationManagerListeners != null) {
            if (mIAuthenticationManagerListeners.contains(iAuthenticationManagerListener)) {
                return;
            } else {
                mIAuthenticationManagerListeners.add(iAuthenticationManagerListener);
            }
        }
    }

    /**
     * removeListener: remove the listener from the specific list.
     * @param iAuthenticationManagerListener the i authentication manager listener
     */
    @Override
    public void removeListener(final AuthenticationManagerListener iAuthenticationManagerListener) {
        if (mIAuthenticationManagerListeners != null) {
            if (mIAuthenticationManagerListeners.contains(iAuthenticationManagerListener)) {
                mIAuthenticationManagerListeners.remove(iAuthenticationManagerListener);
                return;
            }
        }
    }

    /**
     * use getAuthenticationInfo().getUserId() instead
     * Gets the user uid.
     *
     * @return the user uid
     */
    @Override
    public String getUserUid() {
        if (mAuthenticationInfo != null) {
            return mAuthenticationInfo.getUserid();
        }

        return null;

    }

    /**
     * return getAuthenticationInfo().getAccessToken()
     * Gets the user access token.
     *
     * @return the user access token
     */
    @Override
    public String getAccessToken() {

        if (mAuthenticationInfo != null) {
            return mAuthenticationInfo.getAccessToken();
        }
        return null;
    }

    /**
     * String or to (re)authenticate the user.
     * @param redirectToAuthActivity the redirect to auth activity
     * @return the authentication token
     * @throws AuthenticationException the auth model exception
     */
    @Override
    public String getAuthenticationToken(final boolean redirectToAuthActivity) throws AuthenticationException {

        String result = null;

        try{
            result = myRefreshAuthTokenIfNeeded();
        }
        catch ( AuthenticationException e) {
            mLog.e(LOG_TAG, "getAuthenticationToken AuthenticationException", e);
            if (e.getErrorCode() == OPERATION_UNAUTHORIZED)
            {
                // we need to perform interactive auth as the last step

                // there is no result of this operation, as it'll be pending for an unknown amount of time
                // this function will just return null to the caller, like it also happens in the legacy code
                // in case of any kind of interactive login / nab
                // Note: This concept (like in the legacy version) is only expected to work at app launch
                // In all other cases, it depends on the legacy caller code what it exactly does in case
                // of interactive operations during getAuthenticationToken. I'll mostly just display
                // a WarningActivity informing the user that something went wrong (or will do nothing).
                mAuthenticationUIController.doInteractiveAuth(redirectToAuthActivity);
            }

        }

        return result;
    }

    /**
     * Gets the auth token if needed.
     *
     * @return the auth token if needed
     */
    private String myRefreshAuthTokenIfNeeded() throws AuthenticationException {
        mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded");

        if (mAuthenticationInfo == null) {
            mLog.e(LOG_TAG, "refreshAccessTokenIfNeeded the user is logout");
            throw new AuthenticationException(OPERATION_UNAUTHORIZED);
        }

        // SDCANDTACT-4274
        final boolean isDvAccountDeactivated = mAuthenticationStorage.isDvAccountDeactivated();

        final String accessToken = mAuthenticationStorage.getShortLivedToken();
        final boolean hasDvUserId = !TextUtils.isEmpty(mAuthenticationStorage.getDvUserUid());
        final boolean hasRefreshToken = !TextUtils.isEmpty(mAuthenticationStorage.getContextToken());
        final boolean hasShortLivedToken = !TextUtils.isEmpty(accessToken);
        final boolean isAccessTokenKnownToBeExpired = hasShortLivedToken ? mAuthenticationStorage
                .isAccessTokenKnownToBeExpired(accessToken) : false;

        boolean isInterrupted = false;

        // SDCANDTACT-4274
        if (isDvAccountDeactivated) {
            // We don't attempt any sort of auth, just return null
            // which will make the caller think that auth UI is showing
            // (this case should already be handled gracefully throughout the app)
            mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded DV Account is deactivated, returning null #authflow");
        } else if (/*hasLocationUri && */ hasDvUserId && hasShortLivedToken && !isAccessTokenKnownToBeExpired) {
            // We have all essential information to attempt a DV call,
            // therefore we don't need to force authentication now.
            // We just create a new result here with the DV User ID we already have.
            isInterrupted |= Thread.interrupted();
            mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded isInterrupted=%b before returning cached tokens" + isInterrupted);
            if (!isInterrupted) {
                mLog.d(LOG_TAG, "Returning cached tokens #authflow");

            }
            return accessToken;
        } else {
            // AuthenticationStorage is either forced explicitly by the caller or
            // necessary because we don't have all essential information to attempt a DV call

            if (!hasRefreshToken) {
                mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded, no refresh token");

                throw new AuthenticationException(OPERATION_UNAUTHORIZED);
            }

            mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded Performing auth (can not use cached tokens) #authflow");

            isInterrupted |= Thread.interrupted();
            mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded isInterrupted=%b before possibly(!) attempting auth with the refreshToken" + isInterrupted);
            if (!isInterrupted) {
                // First let's attempt to auth using the refresh token we have
                try {
                    mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded refreshToken auth");
                    return refreshAccessToken();
                } catch (final AuthenticationException e) {
                    mLog.e(LOG_TAG, "refreshAccessTokenIfNeeded AuthenticationException ", e);
                    if (e.getErrorCode() == OPERATION_UNAUTHORIZED) {
                        mLog.d(LOG_TAG, "refreshAccessTokenIfNeeded interactive auth, hasRefreshToken " + hasRefreshToken);
                    }

                }
            }
        }
        return null;
    }

    /**
     * On authentication success.
     */
    protected void onAuthenticationSuccess() {
        try {
            for (final AuthenticationManagerListener iAuthenticationManagerListener : mIAuthenticationManagerListeners) {
                iAuthenticationManagerListener.onAuthenticationSuccess();
            }
        } catch (final Exception e) {
            mLog.e(LOG_TAG, "onAuthenticationSuccess catch exception", e);
        }

    }

    /**
     * On authentication error.
     */
    protected void onAuthenticationError() {
        try {
            for (final AuthenticationManagerListener iAuthenticationManagerListener : mIAuthenticationManagerListeners) {
                iAuthenticationManagerListener.onAuthenticationError();
            }
        } catch (final Exception e) {
            mLog.e(LOG_TAG, "onAuthenticationError catch exception", e);
        }

    }

    /**
     * Check parameters.
     *
     * @param account                the account
     * @return true, if successful
     * @throws AuthenticationException the authentication exception
     */
    private boolean checkParameters(final Object account)
            throws AuthenticationException {
        mAuthenticationInfo = null;
        if (account == null) {
            throw new AuthenticationException(ErrorCode.INVALID_PARAMETER);
        }

//        if (mAtpHelper == null) {
//            throw new AuthenticationException(ErrorCode.INVALID_PARAMETER);
//        }

        if (mConfigHelper == null) {
            throw new AuthenticationException(ErrorCode.ERR_CANNOT_LOGIN_MS, "The Configuration is missing, please call retrieveConfig before any call of other API");
        }

        checkEnvironment();

        return true;

    }

    /**
     * Check environment.
     * @return the AuthenticationException exception
     */
    private void checkEnvironment() throws AuthenticationException {



    }

    private void clearStorage()
    {
        mLog.d(LOG_TAG, "clearStorage");

        mAuthenticationStorage.setShortLivedToken("");
        mAuthenticationStorage.setDeviceAdr("");
        mAuthenticationStorage.setContextToken("");
        if(mAuthenticationInfo != null) {
            mAuthenticationInfo.setInfo(mAuthenticationStorage.getDvUserUid(), "", "",
                    mAuthenticationStorage.getAccountName() , null, mAuthenticationStorage.getDeviceAdr()) ;
        }

        HookApplication application = (HookApplication) mContext.getApplicationContext();
        AppContract.Devices devices = new AppContract.Devices(application.getAppContract());
        mContext.getContentResolver().delete(devices.getContentUri(), null, null);
        AppContract.Messages messages = new AppContract.Messages(application.getAppContract());
        mContext.getContentResolver().delete(messages.getContentUri(), null, null);

    }

    private class AtomicResult
    {
        ErrorCode mErrorCode;

        public void setErrorCode(ErrorCode errorCode)
        {
            mErrorCode = errorCode;
        }

        public ErrorCode getErrorCode()
        {
            return mErrorCode;
        }

        public boolean hasErrorOccurred()
        {
            return mErrorCode != null;
        }
    }
    private class AtomicBooleanMap
    {
        private Map<String, AtomicResult> mKeyValue;

        public AtomicBooleanMap()
        {
            mKeyValue = new HashMap<String, AtomicResult>();
        }

        public boolean compareAndSet(String a_Key)
        {
            synchronized(mKeyValue)
            {
                Object exist = mKeyValue.get(a_Key);
                if(exist == null)
                {
                    mKeyValue.put(a_Key, new AtomicResult());

                    return true;
                }
                return false;
            }
        }


        public AtomicResult wait(String a_Key) throws InterruptedException
        {
            AtomicResult exist;

            synchronized(mKeyValue)
            {
                exist = mKeyValue.get(a_Key);
            }
            synchronized (exist)
            {
                exist.wait();
            }

            return exist;
        }

        public void resetAndNotify(String a_Key, ErrorCode errorCode)
        {
            synchronized(mKeyValue)
            {
                AtomicResult exist = mKeyValue.remove(a_Key);
                synchronized(exist)
                {
                    exist.setErrorCode(errorCode);
                    exist.notifyAll();
                }
            }
        }
    }
}

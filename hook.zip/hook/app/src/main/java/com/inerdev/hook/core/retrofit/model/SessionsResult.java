/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.Map;

/**
 * The Class SessionsResult.
 */
public class SessionsResult  {

    /** This contains the access token. This token should be stored by the client and used in all calls to protected Personal Cloud resources. */
    @SerializedName("token")
    private String mToken;

    /** The user's unique id */
    @SerializedName("id")
    private String mId;

    /** The user's name */
    @SerializedName("name")
    private String mName;

    /** The user's displayName */
    @SerializedName("displayName")
    private String mDisplayName;

    /** The user's password */
    @SerializedName("password")
    private String mPassword;

    /** The user's dateCreation */
    @SerializedName("dateCreation")
    private String mDateCreation;

    /** The user's currentDeviceId */
    @SerializedName("currentDeviceId")
    private String mCurrentDeviceId;

    /** When the configuration of the chosen service has refresh tokens enabled then a refresh token will appear in this field. This refresh token can be used by the client to refresh the access token returned in this response
     * instead of going through a full re-authentication process involving the issuing of a new access token. */
    @SerializedName("refreshToken")
    private String mRefreshToken;

    /**
     * Gets the  token.
     * @return the  token
     */
    public String getToken() {
        return mToken;
    }

    /**
     * Gets the Id.
     * @return the Id
     */
    public String getId() {
        return mId;
    }

    /**
     * Gets the mName.
     * @return the mName
     */
    public String getName() {
        return mName;
    }

    /**
     * Gets the mDisplayName.
     * @return the mDisplayName
     */
    public String getDisplayName() {
        return mDisplayName;
    }

    /**
     * Gets the mDateCreation.
     * @return the mDateCreation
     */
    public String getDateCreation() {
        return mDateCreation;
    }

    /**
     * Gets the mCurrentDeviceId.
     * @return the mCurrentDeviceId
     */
    public String getCurrentDeviceId() {
        return mCurrentDeviceId;
    }


    /**
     * Gets the refresh token.
     * @return the refresh token
     */
    public String getRefreshToken() {
        return mRefreshToken;
    }



}

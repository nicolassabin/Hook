/*
 * Copyright 2016 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit;


import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.inerdev.hook.core.ErrorCode;
import com.inerdev.hook.core.auth.AuthBackendHelper;
import com.inerdev.hook.core.auth.AuthenticationException;
import com.inerdev.hook.core.retrofit.model.SessionsResult;
import com.inerdev.hook.core.utils.DeviceDetails;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * Helper class to do Retrofit REST calls
 */
public class RetrofitFactory {

    /** The Constant TAG. */
    private static final String TAG = "RetrofitFactory";

    /** The constant GSON_DATE_FORMAT. */
    private String GSON_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";

    /** The Constant HEADER_CLIENT_APPLICATION_IDENTIFIER. */
    private static final String HEADER_CLIENT_APPLICATION_IDENTIFIER = "x-application-identifier";

    /**
     * The m mAtpApi.
     */
    private AuthApi mAuthApi;

    /** The mLog. */
    private final Log mLog;

    /** The m Gson. */
    private Gson mGson;

    /** The m Retrofit. */
    private Retrofit mRetrofit;

    /**
     * Create RetrofitFactory
     *
     * @param log - the log
     * @param serverUrl - the serverUrl
     * @param deviceDetails - the deviceDetails
     */
    public RetrofitFactory(final Log log, final String serverUrl, final DeviceDetails deviceDetails) {

        mLog = log;
        mLog.d(TAG, "RetrofitFactory constructor");
        final OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        httpClient.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                final Request original = chain.request();
                Request.Builder builderReq = original.newBuilder();

                if (!TextUtils.isEmpty(deviceDetails.getAppId())){
                    builderReq.addHeader(HEADER_CLIENT_APPLICATION_IDENTIFIER, deviceDetails.getAppId());
                }

                final Request request = builderReq.method(original.method(), original.body())
                        .build();

                return chain.proceed(request);
            }
        });

        final OkHttpClient client = httpClient.build();

        mGson = new GsonBuilder()
                .setDateFormat(GSON_DATE_FORMAT)
                .create();

        mRetrofit = new Retrofit.Builder()
                .baseUrl(addEndingSlash(serverUrl))
                .addConverterFactory(GsonConverterFactory.create(mGson))
                .client(client)
                .build();

        mAuthApi = mRetrofit.create(AuthApi.class);
    }




    /**
     * Returns an {@link SessionsResult} to log in using OAuth 2.0.
     * @param name The name
     * @param password The password
     * @param refreshToken The refresh token
     * @param token The token for use with SSO
     * @param callback the callback
     * @return an {@link SessionsResult}
     */
    public Response<SessionsResult> newLoginOperation(final String name, final String password,
                                                               final String refreshToken, final String token,
                                                               final AuthBackendHelper.AuthResult callback){
        mLog.d(TAG, "newLoginOperation clientId " + name);
        Response<SessionsResult> result = null;

        try{
            final Call<SessionsResult> call = mAuthApi.sessions(name, password, refreshToken);
            mLog.d(TAG, "newLoginOperation call.execute ");
            result = call.execute();
            if (result != null){
                if (result.isSuccessful()) {
                    mLog.d(TAG, "newLoginOperation call.execute isSuccessful ");
                    SessionsResult sessionsResult = result.body();
                    if (!TextUtils.isEmpty(sessionsResult.getToken())) {
                        mLog.d(TAG, "newLoginOperation call.execute callback.onSuccess");
                        callback.onSuccess(result);
                    } else {
                        handleError(result, callback);
                    }
                } else {
                    handleError(result, callback);
                }
            } else {
                mLog.d(TAG, "newLoginOperation call.execute failed ");
                callback.onFailure(new AuthenticationException(ErrorCode.OPERATION_UNAUTHORIZED,
                        result.message(), result.code()));
            }
        }
        catch (IOException e) {
            mLog.e(TAG, "newLoginOperation, IOException", e);
            callback.onFailure(e);
        }
        return result;
    }


    /**
     * logouyt in using OAuth 2.0.
     * @param userId the userId
     * @param token the token for use
     * @param callback the callback
     * @return the ResponseBody
     */
    public Response<ResponseBody> newLogoutOperation(final String userId,
                                                     final String token, final AuthBackendHelper.AuthResult callback) {

        mLog.d(TAG, "newLogoutOperation userId " + userId);
        Response<ResponseBody> result = null;

        try{
            final Call<ResponseBody> call = mAuthApi.sessionsDelete(userId, token);
            mLog.d(TAG, "newLogoutOperation call.execute");
            result = call.execute();

            if (result != null){
                if (result.isSuccessful()) {
                    mLog.d(TAG, "newLogoutOperation call.execute isSuccessful");
                    callback.onSuccess(result);
                } else {
                    mLog.d(TAG, "newLogoutOperation call.execute onFailure");
                    callback.onFailure(new AuthenticationException(ErrorCode.OPERATION_FAILED,
                            result.message(), result.code()));
                }
            } else {
                mLog.d(TAG, "newLogoutOperation call.execute failed");
                callback.onFailure(new AuthenticationException(ErrorCode.OPERATION_FAILED,
                        result.message(), result.code()));
            }
        }
        catch (IOException e) {
            mLog.e(TAG, "newLogoutOperation, IOException", e);
            callback.onFailure(e);
        }

        return result;
    }

    /**
     * Handle error.
     * @param response the response
     * @param callback the callback
     * @throws IOException Signals that an I/O exception has occurred.
     */
    private void handleError(final Response response, final AuthBackendHelper.AuthResult callback)
            throws IOException {
        mLog.d(TAG, "handleError ");
        if (response != null){
            callback.onFailure(new AuthenticationException(ErrorCode.OPERATION_UNAUTHORIZED,
                    response.message(), response.code()));
        } else{
            mLog.e(TAG, "handleError invalid response");
        }

//        if (response != null && response.errorBody() != null){
//            Converter<ResponseBody, Errors> converter = mRetrofit.responseBodyConverter(Errors.class, new Annotation[0]);
//            Errors errors = converter.convert(response.errorBody());
//            final AuthenticationException authException =
//                    new AuthenticationException(ErrorCode.OPERATION_FAILED, response.message(), response.code());
//            callback.onFailure(authException);
//        } else {
//            callback.onFailure(new AuthenticationException(ErrorCode.OPERATION_UNAUTHORIZED,
//                    response.message(), response.code()));
//        }

    }

    /**
     * Gets the address.
     *
     * @param urlParam the url
     * @return the string
     */
    private String addEndingSlash(final String urlParam) {
        String url = urlParam;
        if (!TextUtils.isEmpty(url) && !url.endsWith("/")) {
            url += "/";
        }
        return url;
    }

}


package com.inerdev.hook.core.auth;



import java.util.Map;

/**
 * Provisions a user.
 */
public class SignupInfo {
    /** The phone number. */
    private String mPhoneNumber;

    /** The username. */
    private String mUsername;

    /** The user's email address. */
    private String mEmail;

    /** The unique ID. */
    private String mUniqueId;

    /** The account password. */
    private String mAccountPassword;

    /** A map of questions and answers. */
    private Map<String, String> mQuestionAnswers;

    /**
     * Constructor for <b>ProvisioningInfo</b>.
     * @param userName The name of the user being provisioned
     * @param email The user's email address
     * @param phoneNumber The user's phone number
     * @param uniqueId The user's uniqueId (typically a deviceId)
     * @param accountPassword The user's password
     * @param questionAnswerList A map of key-value pairs containing security questions and answers that can be used if
     *            the user forgets their password.
     */
    public SignupInfo(final String userName, final String email, final String phoneNumber,
                      final String uniqueId, final String accountPassword, final Map<String, String> questionAnswerList) {

        mPhoneNumber = phoneNumber;
        mUsername = userName;
        mEmail = email;
        mUniqueId = uniqueId;
        mAccountPassword = accountPassword;
        mQuestionAnswers = questionAnswerList;
    }

    /**
     * Returns the name of the user.
     * @return The username
     */
    public String getUsername() {
        return mUsername;
    }

    /**
     * set the name of the user.
     * @param username The username
     */
    public void setUsername(String username) {

        mUsername = username;
    }

    /**
     * Returns the user's password.
     * @return The password
     */
    public String getAccountPassword() {
        return mAccountPassword;
    }

    /**
     * set the user's password.
     * @param accountPassword The username
     */
    public void setAccountPassword(String accountPassword) {

        mAccountPassword = accountPassword;
    }

    /**
     * Returns the unique ID (typically a deviceId).
     * @return A unique ID
     */
    public String getUniqueId() {
        return mUniqueId;
    }

    /**
     * set the unique ID (typically a deviceId).
     * @param uniqueId  unique ID
     */
    public void setUniqueId(String uniqueId) {

        mUniqueId = uniqueId;
    }

    /**
     * Returns the user's email address.
     * @return An email address
     */
    public String getEmail() {
        return mEmail;
    }

    /**
     * set the user's email address.
     * @param email email address
     */
    public void setEmail(String email) {

        mEmail = email;
    }

    /**
     * Returns the user's phone number.
     * @return A phone number
     */
    public String getPhoneNumber() {
        return mPhoneNumber;
    }

    /**
     * set the user's phone number.
     * @param phoneNumber A phone number
     */
    public void setPhoneNumber(String phoneNumber) {

        mPhoneNumber = phoneNumber;
    }

    /**
     * Returns a list of key-value pairs containing security questions and answers that can be used
     * if the user forgets their password.
     * @return A list of question and answer key-value pairs
     */
    public Map<String, String> getQuestions() {
        return mQuestionAnswers;
    }

    /**
     * set a list of key-value pairs containing security questions and answers that can be used
     * if the user forgets their password.
     * @param  questions A list of question and answer key-value pairs
     */
    public void setQuestions(Map<String, String> questions) {

        mQuestionAnswers = questions;
    }

}

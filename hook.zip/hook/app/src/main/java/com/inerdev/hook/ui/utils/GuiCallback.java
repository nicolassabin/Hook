/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;


import android.os.AsyncTask;

/**
 * The Interface GuiCallback.
 * @param <T> the generic type
 */
public interface GuiCallback<T> {

    /**
     * Checks if is cancelled.
     * @return true, if is cancelled
     */
    boolean isCancelled();

    /**
     * Cancel.
     */
    void cancel();

    /**
     * Task cancel.
     * @param task the task
     */
    void taskCancel(AsyncTask task);

    /**
     * On success.
     * @param response the response
     */
    void onSuccess(T response);

    /**
     * On progress.
     * @param state the state
     */
    void onProgress(Object state);

    /**
     * On error.
     * @param exception the exception
     * @return true, if successful
     */
    boolean onError(Exception exception);
}

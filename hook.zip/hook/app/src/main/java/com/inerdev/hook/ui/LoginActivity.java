package com.inerdev.hook.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationException;
import com.inerdev.hook.core.auth.AuthenticationInfo;
import com.inerdev.hook.core.devices.DeviceInfo;
import com.inerdev.hook.core.devices.DevicesCallBackOperation;
import com.inerdev.hook.core.devices.DevicesManager;
import com.inerdev.hook.core.devices.DevicesManagerImpl;
import com.inerdev.hook.ui.utils.PermissionManager;
import com.inerdev.hook.ui.utils.WifiBtStatusProvider;


public class LoginActivity extends HookAppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback, DevicesCallBackOperation {

    private static final String TAG = "LoginActivity";

    // UI references.
    private EditText mEmailView;
    private EditText mPasswordView;
    private View mProgressView;
    private View mLoginFormView;
    private DevicesManager mDevicesManager;
    private WifiBtStatusProvider mWifiBtStatusProvider;
    private String mUserDeviceAdr = null;
    private Button mEmailSignInButton;
    private TextView mInfoDeviceAdr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(getTitle() + " " + getString(R.string.title_authentication));
        setContentView(R.layout.activity_login);
        mWifiBtStatusProvider = new WifiBtStatusProvider(getApplicationContext());
        mDevicesManager = ((HookApplication)getApplication()).getDevicesManager();

        // Set up the login form.
        mEmailView = (EditText) findViewById(R.id.email);
        mInfoDeviceAdr = (TextView) findViewById(R.id.info_device_adr);

        mPasswordView = (EditText) findViewById(R.id.password);
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        mEmailSignInButton = (Button) findViewById(R.id.email_sign_in_button);
        mEmailSignInButton.setEnabled(false);
        mEmailSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);


    }

    /**
     *
     */
    @Override
    public void onResume() {
        super.onResume();
        mDevicesManager.addListener(this);
        mDevicesManager.startScanning(DevicesManager.TYPE_SCANNING_BT, 10);

    }

    /**
     * onDestroy
     */
    @Override
    public void onDestroy() {
        mDevicesManager.stopScanning();
        mDevicesManager.removeListener(this);
        super.onDestroy();
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    public void attemptLogin() {

        // Reset errors.
        mEmailView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        final String email = mEmailView.getText().toString();
        final String password = mPasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_field_required));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid password, if the user entered one.
        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {

            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            showProgress(true);

            AsyncTask<String, Void, AuthenticationInfo> asyncTask = new AsyncTask<String, Void, AuthenticationInfo>()
            {

                @Override
                protected AuthenticationInfo doInBackground(String... params) {
                    if (mHookApplication.getConfigHelper().retrieveConfig("")) {
                        try {

                            return mHookApplication.getAuthenticationManagerHelper().signin(email, password,
                                    mUserDeviceAdr);
                        } catch (AuthenticationException e) {
                            mLog.e(TAG, "doInBackground exception", e);

                        }
                    }

                    return null;

                }

                @Override
                protected void onPostExecute(AuthenticationInfo result) {
                    if (result != null) {
                        showProgress(false);
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    } if (result == null){
                        showProgress(false);
                        Toast.makeText(LoginActivity.this, "Signin failed", Toast.LENGTH_LONG).show();
                    } else {
                        showProgress(false);
                    }
                }
            };
            asyncTask.execute();




        }
    }

    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return true;
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 4;
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

        mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            }
        });

        mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
        mProgressView.animate().setDuration(shortAnimTime).alpha(
                show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            }
        });
    }

    /**
     * on start
     */
    @Override
    public void onStarting() {

    }

    /**
     * on onProgress
     *
     * @param deviceInfo
     */
    @Override
    public void onProgress(DeviceInfo deviceInfo) {

    }

    /**
     * on End
     */
    @Override
    public void onEnd() {

        DeviceInfo deviceInfoBt = mWifiBtStatusProvider.getBtDeviceInfo();
        DeviceInfo deviceInfoWifi = mWifiBtStatusProvider.getWifiDeviceInfo();
        mUserDeviceAdr = "adr:" + mEmailView.getText().toString();
        if ( deviceInfoBt != null){
            mUserDeviceAdr = deviceInfoBt.getAdr();
        } else if (deviceInfoWifi != null){
            mUserDeviceAdr = deviceInfoWifi.getAdr();
        }

        if (!TextUtils.isEmpty(mUserDeviceAdr)){
            mEmailSignInButton.setEnabled(true);
        }

        // display mUserDeviceAdr
        String adr = getString(R.string.device_identification) + mUserDeviceAdr;
        mInfoDeviceAdr.setText(adr);
    }

    /**
     * on onError
     *
     * @param error
     */
    @Override
    public void onError(int error) {
        mEmailSignInButton.setEnabled(false);
    }
}


/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui;


/**
 * The Interface Constants.
 */
public interface Constants  {


    /**
     * The user login already.
     */
    String FIRST_TIME_INSTALL = "FIRST_TIME_INSTALL";
    /**
     * The user login already.
     */
    String USER_LOGIN_ALREADY = "user_login_already";

    /**
     * The MESSAGES_ETAG.
     */
    String MESSAGES_ETAG = "messages_etag";




}




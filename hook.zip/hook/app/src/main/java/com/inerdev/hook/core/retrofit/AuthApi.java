package com.inerdev.hook.core.retrofit;



import com.inerdev.hook.core.retrofit.model.SessionsResult;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by nicolas on 02/12/2016.
 */

public interface AuthApi {

    /** The header accept atp json. */
    String APPLICATION_JSON = "application/json";

    /** The header accept auth json. */
    String HEADER_ACCEPT_AUTH_JSON = "Accept: " + APPLICATION_JSON;

    /**
     * log in using OAuth 2.0.
     *
     * @return - Call<SessionsResult>
     */
    @Headers({ HEADER_ACCEPT_AUTH_JSON })
    @FormUrlEncoded
    @POST("oauth2/sessions/")
    Call<SessionsResult>  sessions(@Field("name") String name,
                                   @Field("password") String password,
                                   @Field("refresh_token") String refreshToken);

    /**
     * Provisions a user account in the system. The required parameters and values depend on the ATP authentication flow
     * configured for your environment. Refer to the earlier chapters for descriptions and examples of supported flow
     * types.
     *
     * @return - Call<ProvisioningDetailsR>
     */
//    @Headers({ HEADER_ACCEPT_ATP_JSON })
//    @FormUrlEncoded
//    @POST("provision")
//    Call<ProvisionResult> provision(@Field("phoneNumber") String phoneNumber,
//                                    @Field("name") String userName,
//                                    @Field("email") String email,
//                                    @Field("password") String accountPassword);

    /**
     * logout using OAuth 2.0.
     *
     */
    @Headers({ HEADER_ACCEPT_AUTH_JSON })
    @DELETE("oauth2/sessions/{userUid}")
    Call<ResponseBody> sessionsDelete(@Path("userUid") String userId, @Query("token") String token);

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inerdev.hook.core.devices;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.http.CallBackHttpRequest;
import com.inerdev.hook.core.http.HttpClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 *
 * @author Nicolas Sabin
 */
public class DevicesBackendHelper implements CallBackHttpRequest{

    private static final String LOG_TAG = "DevicesBackendHelper";

    /*
    * BK_CALL
    */
    public static final int BK_CALL = 1;

    /*
    * SEARCH_USER_ADR
    */
    private static final String SEARCH_USER_ADR = "searchUserAdress";

    /*
    * RESPONSE_ID
    */
    private static final String RESPONSE_ID = "id";

    /**
    * the m Log
    */
    private Log mLog;


    /** The m result. */
    private String mResult;


    /** The m mContext. */
    private Context mContext;

    /**
     * Instantiates a new AuthBackendHelper.
     * @param context the context
     */
    public DevicesBackendHelper(final Context context) {
        mContext = context;
    }

    /**
     * connect the user from device adr
     * @return String the userId , null if not exist
     */
    public String getUserFromDevice(final String deviceAdr)
    {
        mLog.d(LOG_TAG, ">getUserFromDevice deviceAdr " + deviceAdr);

        if (!checkParams(deviceAdr)){
            mLog.e(LOG_TAG, ">getUserFromDevice invalid deviceAdr ");
            return null;
        }

        mResult = null;
        call(SEARCH_USER_ADR, "{\"1\":\"" + deviceAdr + "\"}", BK_CALL);
        if (TextUtils.isEmpty(mResult)){
            mLog.i(LOG_TAG, ">getUserFromDevice invalid searchUser " + mResult);
            return null;
        }

        mLog.d(LOG_TAG, "<getUserFromDevice mResult " + mResult);
        return mResult;
    }


    /*
    call to get data
    */
    private void call(String data, String params, int event)
    {
        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HttpClient client = new HttpClient(this,   event, keys, values);
        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();
        client.execute(hookApplication.getConfigHelper().getConfig().getServerUrl() + "call?token=" +
                hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken());
    }


    /**
     * call for http request
     * @param result
     * @param event
     */
    @Override
    public void onRequestResult(String result, int event) {
        mLog.d(LOG_TAG, "onRequestResult result " + result + " event " + event);
        switch(event) {
            case BK_CALL:

                if (!TextUtils.isEmpty(result)){
                    try {

                        JSONObject js = new JSONObject(result);
                        JSONArray entities = new JSONArray(js.get("entities").toString());

                        if (entities.length() == 0) {
                            mLog.i(LOG_TAG, "onRequestResult unknown user");
                            mResult = null;
                        } else {
                            JSONObject user = entities.getJSONObject(0);
                            mResult = user.getString(RESPONSE_ID);
                            mLog.i(LOG_TAG, "onRequestResult user found " + mResult);

                        }
                    } catch (Exception e) {
                        mLog.e(LOG_TAG, "onRequestResult user  Exception", e);
                    }
                } else {
                    mLog.i(LOG_TAG, "onRequestResult empty result");
                }
                break;
        }
    }

    private boolean checkParams(final String deviceAdr) {
        if (TextUtils.isEmpty(deviceAdr)){
            mLog.e(LOG_TAG, ">checkParams invalid deviceAdr ");
            return false;
        }
        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();

        if (hookApplication.getConfigHelper().getConfig() == null){
            mLog.e(LOG_TAG, ">checkParams invalid config ");
            return false;
        }
        if (TextUtils.isEmpty(hookApplication.getConfigHelper().getConfig().getServerUrl())){
            mLog.e(LOG_TAG, ">checkParams invalid ServerUrl ");
            return false;
        }
        if (hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo() == null){
            mLog.e(LOG_TAG, ">checkParams invalid AuthenticationInfo ");
            return false;
        }
        if (TextUtils.isEmpty(hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken())){
            mLog.e(LOG_TAG, ">checkParams invalid accessToken ");
            return false;
        }

        return true;
    }
}

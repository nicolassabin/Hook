/*
 * Copyright 2017 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.messages;

import android.annotation.TargetApi;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.inerdev.hook.R;


/**
 * Created by nsab0001 on 07/05/17.
 *
 * abstract class for JobScheduler from Marshmallow
 */
@TargetApi(Build.VERSION_CODES.LOLLIPOP_MR1)
public class MessagesJobScheduler {

    private static final String LOG_TAG = "MessagesJobScheduler";

    /**
     * The constant PERIODICITY.
     */
    //private static final int PERIODICITY = 1*60*1000;
    private static final int PERIODICITY = 5*1000; // for testing

    /**
     * The constant JOB_ID.
     */
    private static final int JOB_SCHEDULER_ID = 1969;

    /**
     * The m jobScheduler.
     */
    protected JobScheduler mJobScheduler;

    /**
     * The m JobInfo.
     */
    protected JobInfo mJobInfo;


    /**
     * The m log.
     */
    protected Log mLog;

    /**
     * The m Context.
     */
    protected Context mContext;

    /**
     * The m mMinLatentcy.
     */
    protected int mMinLatentcy = 0;

    /**
     * constructor
     * @param context
     */
    public MessagesJobScheduler(final Context context) {
        mContext = context;
        mJobScheduler = (JobScheduler) mContext.getSystemService(Context.JOB_SCHEDULER_SERVICE);
    }

    /**
     * start Scheduler
     */
    public void startScheduler(){

        // check feature is enabled
        if (!mContext.getResources().getBoolean(R.bool.enable_messages_scheduler)){
            mLog.i(LOG_TAG, "startScheduler Feature Disabled!!!");
            cancelScheduler();
            return;
        }

        if (!isJobScheduled()){
            Intent startServiceIntent = new Intent(mContext, MessagesService.class);
            mContext.startService(startServiceIntent);

            if (mJobScheduler != null){
                mLog.d(LOG_TAG, "startScheduler");
                JobInfo.Builder builder = new JobInfo.Builder(JOB_SCHEDULER_ID,
                        new ComponentName(mContext, MessagesService.class.getName()));
                builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
                builder.setRequiresCharging(false);
                builder.setRequiresDeviceIdle(false);
                builder.setPeriodic(PERIODICITY);
                //builder.setRequiresBatteryNotLow(true); // when Android O will be released
                if (mMinLatentcy > 0){
                    builder.setMinimumLatency(mMinLatentcy);
                }
                mJobInfo = builder.build();
                cancelScheduler();
                if (mJobScheduler.schedule(mJobInfo) == JobScheduler.RESULT_FAILURE){
                    mLog.d(LOG_TAG, "startScheduler schedule failed");
                }

            } else {
                mLog.i(LOG_TAG, "startScheduler invalid mJobScheduler");
            }
        } else {
            mLog.i(LOG_TAG, "startScheduler already scheduled");
        }

    }

    /**
     * cancel Scheduler
     */
    public void cancelScheduler(){
        mLog.d(LOG_TAG, "cancelScheduler");

        if (mJobScheduler != null){
            mJobScheduler.cancel(JOB_SCHEDULER_ID);
            mContext.stopService(new Intent(mContext, MessagesService.class));
        } else {
            mLog.i(LOG_TAG, "cancelScheduler invalid mJobScheduler");
        }

    }

    /**
     * is Job Scheduled
     * @return boolean
     */
    public boolean isJobScheduled(){

        if (mJobScheduler != null){
            return mJobInfo != null;
        } else {
            mLog.i(LOG_TAG, "isJobScheduled invalid mJobScheduler");
        }

        return false;

    }

}

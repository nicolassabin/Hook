
package com.inerdev.hook.core.devices;


import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.core.config.ConfigHelper;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * The Interface DevicesManagerImpl.
 */
public class DevicesManagerImpl extends BroadcastReceiver implements DevicesManager{

    private static final String LOG_TAG = "DevicesManagerImpl";



    /** The m log. */
    private Log mLog;

    /** The m Context. */
    private Context mContext;

    /**
     * The m ConfigHelper.
     */
    private ConfigHelper mConfigHelper;

    /**
     * The m mListeners.
     */
    private final List<WeakReference<DevicesCallBackOperation>> mListeners = new ArrayList<WeakReference<DevicesCallBackOperation>>();

    /**
     * The m mIsScanningInProgress.
     */
    private boolean mIsScanningInProgress = false;


    public DevicesManagerImpl(final Context context, final ConfigHelper configHelper){
        mContext = context;
        mConfigHelper = configHelper;
        final IntentFilter intentFilter = new IntentFilter(INTENT_ACTION_DEVICES_SCANNING_STARTED);
        intentFilter.addAction(INTENT_ACTION_DEVICES_SCANNING_PROGRESS);
        intentFilter.addAction(INTENT_ACTION_DEVICES_SCANNING_SUCCEED);
        intentFilter.addAction(INTENT_ACTION_DEVICES_SCANNING_FAILED);
        try {
            mContext.registerReceiver(this, intentFilter);
        }
        catch(Exception e) {
            mLog.e(LOG_TAG, "Exception in registerReceiver()", e);
        }

    }


    /**
     * update status of the devices.
     * @param callBackOperation
     *
     */
    public void updateStatus(DevicesCallBackOperation callBackOperation){
        try{
            Intent serviceIntent = new Intent(mContext.getPackageName() + DevicesService.SERVICE_NAME)
                    .setPackage(mContext.getPackageName());
            serviceIntent.putExtra(DevicesService.PARAM_ACTION,DevicesService.ACTION_UPDATE_STATUS);
            ComponentName compname = mContext.startService(serviceIntent);
            if(compname == null)
            {
                mLog.d(LOG_TAG, "updateStatus startService: starting service ACTION_UPDATE_STATUS");
                if (callBackOperation != null){
                    callBackOperation.onStarting();
                }
            }
            else
            {
                mLog.d(LOG_TAG, "updateStatus startService: service already starting or already started by "
                        + compname.flattenToString());
            }
        } catch(Throwable e){
            mLog.e(LOG_TAG, "updateStatus startService: Throwable " + e.getMessage(), e);
        }
    }

    /**
     * start Scanning.
     * @param typeScanning (refer to TYPE_SCANNING_BT....)
     * @param timeout (max is DEFAULT_TIMEOUT for BT)
     *
     */
    @Override
    public void startScanning(int typeScanning, int timeout) {
        mLog.d(LOG_TAG, "startScanning typeScanning " + typeScanning);
        try{
            Intent serviceIntent = new Intent(mContext.getPackageName() + DevicesService.SERVICE_NAME)
                    .setPackage(mContext.getPackageName());
            serviceIntent.putExtra(DevicesService.PARAM_ACTION,DevicesService.ACTION_START_SCANNING);
            serviceIntent.putExtra(DevicesService.PARAM_TYPE_SCANNING,typeScanning);
            serviceIntent.putExtra(DevicesService.PARAM_SCANNING_TIMEOUT, timeout);
            ComponentName compname = mContext.startService(serviceIntent);
            if(compname == null)
            {
                mLog.d(LOG_TAG, "startScanning startService: starting service ACTION_START_SCANNING");
            }
            else
            {
                mLog.d(LOG_TAG, "startScanning startService: service already starting or already started by "
                    + compname.flattenToString());
            }
        } catch(Throwable e){
            mLog.e(LOG_TAG, "startScanning startService: Throwable " + e.getMessage(), e);
        }
    }

    /**
     * stop Scanning.
     *
     */
    @Override
    public void stopScanning() {
        mLog.d(LOG_TAG, "stopScanning");
        Intent serviceIntent = new Intent(mContext.getPackageName() + DevicesService.SERVICE_NAME)
                .setPackage(mContext.getPackageName());
        //serviceIntent.putExtra(DevicesService.PARAM_ACTION,DevicesService.ACTION_STOP_SCANNING);
        if (mContext.stopService(serviceIntent)){
            mLog.d(LOG_TAG, "stopScanning: stopping service ACTION_STOP_SCANNING");
        } else {
            mLog.e(LOG_TAG, "stopScanning: stopping service. failed");
        }
    }

    /**
     * clear cache
     */
    @Override
    public void clearCache(String idDevices) {
        mLog.d(LOG_TAG, "clearCache idDevices " + idDevices);
        try{
            Intent serviceIntent = new Intent(mContext.getPackageName() + DevicesService.SERVICE_NAME)
                    .setPackage(mContext.getPackageName());
            serviceIntent.putExtra(DevicesService.PARAM_ACTION,DevicesService.ACTION_CLEAR_CACHE);
            if (!TextUtils.isEmpty(idDevices)){
                serviceIntent.putExtra(DevicesService.PARAM_ID_SERVICE, idDevices);
            }
            ComponentName compname = mContext.startService(serviceIntent);
            if(compname == null)
            {
                mLog.d(LOG_TAG, "clearCache startService: starting service ACTION_CLEAR_CACHE");

            }
            else
            {
                mLog.d(LOG_TAG, "clearCache startService: service already starting or already started by "
                        + compname.flattenToString());
            }
        } catch(Throwable e){
            mLog.e(LOG_TAG, "clearCache startService: Throwable " + e.getMessage(), e);
        }

    }


    /**
     * This method is called when the BroadcastReceiver is receiving an Intent
     * broadcast.  During this time you can use the other methods on
     * BroadcastReceiver to view/modify the current result values.  This method
     * is always called within the main thread of its process, unless you
     * explicitly asked for it to be scheduled on a different thread using
     * thread you should
     * never perform long-running operations in it (there is a timeout of
     * 10 seconds that the system allows before considering the receiver to
     * be blocked and a candidate to be killed). You cannot launch a popup dialog
     * in your implementation of onReceive().
     * <p>
     * <p><b>If this BroadcastReceiver was launched through a &lt;receiver&gt; tag,
     * then the object is no longer alive after returning from this
     * function.</b>  This means you should not perform any operations that
     * return a result to you asynchronously -- in particular, for interacting
     * with services, you should use
     * {@link Context#startService(Intent)} instead of
     * to interact with a service that is already running, you can use
     * {@link #peekService}.
     * <p>
     * <p>The Intent filters used in {@link Context#registerReceiver}
     * and in application manifests are <em>not</em> guaranteed to be exclusive. They
     * are hints to the operating system about how to find suitable recipients. It is
     * possible for senders to force delivery to specific recipients, bypassing filter
     * resolution.  For this reason, {@link #onReceive(Context, Intent) onReceive()}
     * implementations should respond only to known actions, ignoring any unexpected
     * Intents that they may receive.
     *
     * @param context The Context in which the receiver is running.
     * @param intent  The Intent being received.
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        mLog.d(LOG_TAG, "onReceive(), action: " + action);
        if (INTENT_ACTION_DEVICES_SCANNING_STARTED.equals(action)) {
            mIsScanningInProgress = true;
            synchronized (mListeners) {
                for (final WeakReference<DevicesCallBackOperation> weakRefListener : mListeners) {
                    DevicesCallBackOperation listener = weakRefListener.get();
                    if (listener != null) {
                        listener.onStarting();
                    }
                }
            }
        } else if (INTENT_ACTION_DEVICES_SCANNING_SUCCEED.equals(action)) {
            mIsScanningInProgress = false;

            mLog.d(LOG_TAG, "INTENT_ACTION_DEVICES_SCANNING_SUCCEED succeed, ");
            synchronized (mListeners) {
                for (final WeakReference<DevicesCallBackOperation> weakRefListener : mListeners) {
                    DevicesCallBackOperation listener = weakRefListener.get();
                    if (listener != null) {
                        listener.onEnd();
                    }
                }
            }
        } else if (INTENT_ACTION_DEVICES_SCANNING_PROGRESS.equals(action)) {
            mLog.d(LOG_TAG, "progress");
            final DeviceInfo deviceInfo = intent.getParcelableExtra(INTENT_DEVICES_SCANNING_DEVICE_INFO);
            synchronized (mListeners) {
                for (final WeakReference<DevicesCallBackOperation> weakRefListener : mListeners) {
                    final DevicesCallBackOperation listener = weakRefListener.get();
                    if (listener != null) {
                        listener.onProgress(deviceInfo);
                    }
                }
            }
        } else if (INTENT_ACTION_DEVICES_SCANNING_FAILED.equals(action)) {
            mIsScanningInProgress = false;
            final int error = intent.getIntExtra(INTENT_DEVICES_SCANNING_ERROR, 0);
            mLog.d(LOG_TAG, "failed, error " + error);
            synchronized (mListeners) {
                for (final WeakReference<DevicesCallBackOperation> weakRefListener : mListeners) {
                    final DevicesCallBackOperation listener = weakRefListener.get();
                    if (listener != null) {
                        listener.onError(error);
                    }
                }
            }
        } else {
            mLog.w(LOG_TAG, "not supported action: " + action);
        }
    }

    /**
     * Adds the listener.
     * @param listener the listener
     */
    @Override
    public void addListener(final DevicesCallBackOperation listener) {
        synchronized (mListeners) {
            for (final WeakReference<DevicesCallBackOperation> weakRefListener : mListeners) {
                if (listener == weakRefListener.get()) {
                    return;
                }
            }
            mListeners.add(new WeakReference<DevicesCallBackOperation>(listener));
        }
    }

    /**
     * Removes the listener.
     * @param listener the listener
     */
    @Override
    public void removeListener(final DevicesCallBackOperation listener) {
        synchronized (mListeners) {
            for (int idx = 0; idx < mListeners.size(); idx++) {
                if (listener == mListeners.get(idx).get()) {
                    mListeners.remove(idx);
                    break;
                }
            }
        }
    }


    /**
     * close
     */
    @Override
    public void close() {
        try {
            mContext.unregisterReceiver(this);
        } catch (Exception e) {
            mLog.e(LOG_TAG, "Unable to unregisterReceiver()", e);
        }
    }
}
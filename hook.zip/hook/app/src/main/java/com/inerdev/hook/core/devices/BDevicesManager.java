package com.inerdev.hook.core.devices;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.provider.AppContract;

import java.util.HashMap;
import java.util.Map;


/**
 * Created by nsab0001 on 01/06/2017.
 */

public abstract class BDevicesManager extends BroadcastReceiver{

    private static final String LOG_TAG = "BDevicesManager";

    /**  m log. */
    protected Log mLog;

    /** The m Context. */
    protected Context mContext;

    /** The m ScanCallBackOperation. */
    protected ScanCallBackOperation mScanCallBackOperation;

    /** The m mMyScanCallBack. */
    protected Map<String, DeviceInfo> mListDevicesAddress = new HashMap<>();

    /** The m AuthenticationManager. */
    protected AuthenticationManager mAuthenticationManager;


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    public BDevicesManager(Context context) {
        mContext = context;
        mAuthenticationManager = ((HookApplication)context.getApplicationContext()).getAuthenticationManagerHelper();

    }


    /**
     * close.
     *
     */
    public void close(){
        mLog.d(LOG_TAG, "close");
    }

    /**
     * clearCache.
     *
     */
    public void clearCache(String idDevices) {
        mLog.d(LOG_TAG, "clearCache idDevices " + idDevices);
        if (mListDevicesAddress != null){
            if (!TextUtils.isEmpty(idDevices) && mListDevicesAddress.containsKey(idDevices)){
                DeviceInfo deviceInfo = mListDevicesAddress.get(idDevices);
                deviceInfo.setStatus(AppContract.Devices.DEVICE_DELETED);
                mListDevicesAddress.put(idDevices, deviceInfo);
            } else {
                mLog.d(LOG_TAG, "clearCache clear all ");
                mListDevicesAddress.clear();
            }
        } else {
            mLog.e(LOG_TAG, "clearCache failed");
        }
    }

    /**
     * getDeviceUserId.
     * @param deviceAdr
     */
    protected String getDeviceUserId(final String deviceAdr){
        if (!TextUtils.isEmpty(deviceAdr)){
            mLog.d(LOG_TAG, "getDeviceUserId from " + deviceAdr);
            DevicesBackendHelper devicesBackendHelper = new DevicesBackendHelper(mContext);
            return devicesBackendHelper.getUserFromDevice(deviceAdr);
        } else {
            mLog.e(LOG_TAG, "getDeviceUserId invalid parameter");
        }

        return null;
    }

}

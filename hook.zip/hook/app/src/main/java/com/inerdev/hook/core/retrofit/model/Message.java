/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import com.google.gson.annotations.SerializedName;

/**
 * The Class Device.
 */
public class Message {


    /** The message id */
    @SerializedName("id")
    private String mId;

    /** The message from */
    @SerializedName("from")
    private String mFrom;

    /** The message's subject */
    @SerializedName("subject")
    private String mSubject;

    /** The message's text */
    @SerializedName("text")
    private String mText;

    /** The message's Data1 */
    @SerializedName("data1")
    private String mData1;

    /** The message's deviceId */
    @SerializedName("deviceId")
    private String mDeviceId;

    /** The message's dateCreation */
    @SerializedName("dateCreation")
    private String mDateCreation;

    /** The message's dateExpiration */
    @SerializedName("dateExpiration")
    private String mDateExpiration;

    /** The message's category */
    @SerializedName("category")
    private String mCategory;

    /** type */
    @SerializedName("type")
    private String mType;

    /** status */
    @SerializedName("status")
    private int mStatus;


    /**
     * Gets the Id.
     * @return the Id
     */
    public String getId() {
        return mId;
    }

    /**
     * Gets the From.
     * @return the From
     */
    public String getFrom() {
        return mFrom;
    }

    /**
     * Gets the Data1.
     * @return the Data1
     */
    public String getData1() {
        return mData1;
    }

    /**
     * Gets the mDateCreation.
     * @return the mDateCreation
     */
    public String getDateCreation() {
        return mDateCreation;
    }

    /**
     * Gets the mDateExpiration.
     * @return the mDateExpiration
     */
    public String getDateExpiration() {
        return mDateExpiration;
    }

    /**
     * Gets the mDeviceId.
     * @return the mDeviceId
     */
    public String getDeviceId() {
        return mDeviceId;
    }


    /**
     * Gets the mSubject.
     * @return the mSubject
     */
    public String getSubject() {
        return mSubject;
    }

    /**
     * Gets the mText.
     * @return the mText
     */
    public String getText() {
        return mText;
    }

    /**
     * Gets the mCategory.
     * @return the mCategory
     */
    public String getCategory() {
        return mCategory;
    }

    /**
     * Gets the mType.
     * @return the mType
     */
    public String getType() {
        return mType;
    }

    /**
     * Gets the mStatus.
     * @return the mStatus
     */
    public int getStatus() {
        return mStatus;
    }

}

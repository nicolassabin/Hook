
package com.inerdev.hook.core.messages;


/**
 * The Interface MessagesCallBackOperation.
 */
public interface MessagesCallBackOperation {

    /**
     * on starting
     */
    public void onStarting();

    /**
     * on onProgress
     * @param userId
     */
    public void onProgress(String userId);

    /**
     * on End
     */
    public void onEnd();

    /**
     * on onError
     * @param error
     */
    public void onError(int error);



}
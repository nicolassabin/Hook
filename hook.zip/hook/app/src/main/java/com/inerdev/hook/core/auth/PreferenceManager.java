/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;


import java.util.List;

/**
 * The Class PreferenceManager.
 */
@SuppressLint("ApplySharedPref")
public class PreferenceManager {

    /**
     * The Constant LOG_TAG.
     */
    private static final String LOG_TAG = "PreferenceManager";

    /**
     * The Constant SNC_CLIENT_VERSION_KEY.
     */
    private static final String SNC_CLIENT_VERSION_KEY = "snc_client_version_key";

    /**
     * The Constant SNC_GLOBAL_VERSION_KEY.
     */
    private static final String SNC_GLOBAL_VERSION_KEY = "snc_global_version_key";

    /**
     * The Constant SNC_CLIENT_VERSION_DEFAULT.
     */
    private static final String SNC_CLIENT_VERSION_DEFAULT = "0";

    /**
     * The Constant USER_LOGIN_STATUS_KEY.
     */
    public static final String USER_LOGIN_STATUS_KEY = "user_login_status_key";

    /**
     * Key should only be used when R.bool.nab_auth is set as true
     */
    public static final String NAB_AUTH_STATUS_KEY = "nab_auth_status_key";

    /**
     * The Constant GENERAL_PREF.
     */
    public static final String GENERAL_PREF = "GeneralPref";

    /**
     * The Constant ACCOUNTNAME_KEY.
     */
    private static final String ACCOUNTNAME_KEY = "accountNamekey";

    /**
     * The Constant DEVICEADR_KEY.
     */
    private static final String DEVICEADR_KEY = "deviceAdrkey";

    /**
     * The Constant USER_ID.
     */
    private static final String USER_ID = "UserID";

    /** The Constant EMAIL_KEY. */
    private static final String EMAIL_KEY = "emailkey";

    /**
     * The Constant CONTEXT_TOKEN_PREF.
     */
    private static final String CONTEXT_TOKEN_PREF = "ContextTokenPref";

    /**
     * The Constant CONTEXT_TOKEN.
     */
    private static final String CONTEXT_TOKEN = "ContextToken";

    /**
     * The Constant ACCESS_TOKEN.
     */
    private static final String ACCESS_TOKEN = "AccessToken";

    /**
     * The Constant IS_ACCOUNT_BLOCKED.
     */
    private static final String IS_ACCOUNT_BLOCKED = "IsAccountBlocked";

    /**
     * The Constant IS_ACCOUNT_BLOCKED_PREF.
     */
    private static final String IS_ACCOUNT_BLOCKED_PREF = IS_ACCOUNT_BLOCKED + "Pref";

    /**
     * The Constant LAST_UPLOAD_DATE_PREF.
     */
    private static final String LAST_UPLOAD_DATE_PREF = "last_upload_date_pref";

    /**
     * The Constant LAST_DOWNLOAD_DATE_PREF.
     */
    private static final String LAST_DOWNLOAD_DATE_PREF = "last_download_date_pref";

    /**
     * The Constant LAST_UPLOAD_DATE.
     */
    private static final String LAST_UPLOAD_DATE = "last_upload_date";

    /**
     * The Constant LAST_DOWNLOAD_DATE.
     */
    private static final String LAST_DOWNLOAD_DATE = "last_download_date";

    /**
     * The Constant LAST_UPLOAD_FILE_COUNT_PREF.
     */
    private static final String LAST_UPLOAD_FILE_COUNT_PREF = "lastupload_file_count_pref";

    /**
     * The Constant LAST_UPLOAD_FILE_COUNT.
     */
    private static final String LAST_UPLOAD_FILE_COUNT = "lastupload_file_count";

    /**
     * The Constant QUICK_ACTION_CHECK_BOX_PREF.
     */
    public static final String QUICK_ACTION_CHECK_BOX_PREF = "quickaction_checkbox_pref";

    /**
     * The Constant QUICK_ACTION_CHECK_BOX.
     */
    public static final String QUICK_ACTION_CHECK_BOX = "quickaction_checkbox";

    /**
     * The Constant CLIENT_CONFIG_APP_VERSION.
     */
    private static final String CLIENT_CONFIG_APP_VERSION = "client_config_app_version";

    /**
     * The Constant PREVIEW_IMAGE_VERSION.
     */
    private static final String PREVIEW_IMAGE_VERSION = "preview_image_version";

    /**
     * The Constant INITIAL_SYNC_FINISHED.
     */
    private static final String INITIAL_SYNC_FINISHED = "initial_sync_finished";

    // SDCANDTACT-4274
    /**
     * The Constant DV_ACCOUNT_DEACTIVATED.
     */
    private static final String DV_ACCOUNT_DEACTIVATED = "dv_account_deactivated";

    /**
     * The Constant NAB_ACCOUNT_CURRENT_VERSION
     */
    public static final String NAB_ACCOUNT_CURRENT_VERSION = "nabaccountcurrentversion";

    /**
     * The Constant NAB_ACCOUNT_N1_VERSION
     */
    public static final String NAB_ACCOUNT_N1_VERSION = "nabaccountn1version";

    /**
     * The Constant NAB_ACCOUNT_N2_VERSION
     */
    public static final String NAB_ACCOUNT_N2_VERSION = "nabaccountn2version";


    // PCLOUD-1032
    /**
     * The Constant CLIENT_CONFIG_DOWNLOAD_TIME.
     */
    public static final String CLIENT_CONFIG_DOWNLOAD_TIME = "client_config_download_time";

    /** The Constant AUTHENTICATED_ONCE. */
    private static final String AUTHENTICATED_ONCE = "authenticated_once";

    /**
     * The m log.
     */
    private final Log mLog;

    /**
     * The m context.
     */
    private final Context mContext;


    /**
     * Instantiates a new preference manager.
     *
     * @param log               the log
     * @param context           the context
     */
    public PreferenceManager(final Log log, final Context context) {
        mLog = log;
        mContext = context;
    }

    /**
     * Save pref.
     *
     * @param key   the key
     * @param value the value
     */
    private void savePref(final String key, final String value) {
        final SharedPreferences settings = mContext.getSharedPreferences(GENERAL_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(key, value);
        editor.commit();
    }

    /**
     * Save snc client version.
     *
     * @param version the version
     */
    public void saveSNCClientVersion(final int version) {
        final String value = Integer.toString(version);
        savePref(SNC_CLIENT_VERSION_KEY, value);
    }

    /**
     * Save snc global version.
     *
     * @param version the version
     */
    public void saveSNCGlobalVersion(final int version) {
        final String value = Integer.toString(version);
        savePref(SNC_GLOBAL_VERSION_KEY, value);
    }

    /**
     * Save nab account file version.
     * @param key the key for current, n-1 and n-2 version
     * @param version the version
     */
    public void saveNabAccountVersion(final String key, final float version) {
        final String value = Float.toString(version);
        savePref(key, value);
    }

    /**

    /**
     * Read accountName.
     *
     * @return the string
     */
    public String readAccountName() {
        return readPref(ACCOUNTNAME_KEY, null);
    }

    /**
     * Save accountName.
     *
     * @param accountName the accountName
     */
    public void saveAccountName(final String accountName) {
        savePref(ACCOUNTNAME_KEY, accountName);
    }

    /**
     * Read DeviceAdr.
     *
     * @return the string
     */
    public String readDeviceAdr() {
        return readPref(DEVICEADR_KEY, null);
    }

    /**
     * Save DeviceAdr.
     *
     * @param deviceAdr the DeviceAdr
     */
    public void saveDeviceAdr(final String deviceAdr) {
        savePref(DEVICEADR_KEY, deviceAdr);
    }

    /**
     * Save user login status.
     *
     * @param loginStatus the login status
     */
    public void saveUserLoginStatus(final boolean loginStatus) {
        savePref(USER_LOGIN_STATUS_KEY, String.valueOf(loginStatus));
    }

    /**
     * Save nab auth status.
     *
     * @param nabAuthStatus the nab auth status
     */
    public void saveNabAuthStatus(final boolean nabAuthStatus) {
        savePref(NAB_AUTH_STATUS_KEY, String.valueOf(nabAuthStatus));
    }

    /**
     * Read pref.
     *
     * @param key          the key
     * @param defaultValue the default value
     * @return the string
     */
    private String readPref(final String key, final String defaultValue) {
        String result;
        final SharedPreferences settings = mContext.getSharedPreferences(GENERAL_PREF, Context.MODE_PRIVATE);
        result = settings.getString(key, defaultValue);
        return result;
    }

    /**
     * Read snc client version.
     *
     * @return the int
     */
    public int readSNCClientVersion() {
        final String version = readPref(SNC_CLIENT_VERSION_KEY, SNC_CLIENT_VERSION_DEFAULT);
        return Integer.parseInt(version);
    }

    /**
     * Read snc global version.
     *
     * @return the int
     */
    public int readSNCGlobalVersion() {
        final String version = readPref(SNC_GLOBAL_VERSION_KEY, SNC_CLIENT_VERSION_DEFAULT);
        return Integer.parseInt(version);
    }


    /**
     * Read Nab account file version.
     * @return the float
     */
    public float readNabAccountVersion(final String key) {
        final String version = readPref(key, "-1");
        return Float.parseFloat(version);
    }

    /**
     * Clear General Preferences
     * @param preferencesName
     */
    public void clearGeneralPreferences(List<String> preferencesName){
        if(preferencesName != null && !preferencesName.isEmpty()) {
            final SharedPreferences settings = mContext.getSharedPreferences(GENERAL_PREF, Context.MODE_PRIVATE);
            final SharedPreferences.Editor editor = settings.edit();
            for (String key : preferencesName) {
                editor.remove(key);
            }

            editor.commit();
        }
    }

    /**
     * Read user login status.
     *
     * @return true, if successful
     */
    public boolean readUserLoginStatus() {
        final String loginStatus = readPref(USER_LOGIN_STATUS_KEY, "false");
        return Boolean.valueOf(loginStatus);
    }

    /**
     * Read if user authenticated once from GENERAL_PREF.
     * @return true, if is user authenticated once
     */
    public boolean isUserAuthenticatedOnce() {
        boolean isUserAuthenticatedOnce = true;
        final SharedPreferences settings = mContext.getSharedPreferences(AUTHENTICATED_ONCE,
                Context.MODE_PRIVATE);
        isUserAuthenticatedOnce = settings.getBoolean(AUTHENTICATED_ONCE, false);
        mLog.d(LOG_TAG, "isUserAuthenticatedOnce = " + isUserAuthenticatedOnce);
        return isUserAuthenticatedOnce;
    }

    /**
     * Sets the user authenticated once.
     */
    public void setUserAuthenticatedOnce() {
        final SharedPreferences settings = mContext.getSharedPreferences(AUTHENTICATED_ONCE,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(AUTHENTICATED_ONCE, true);
        editor.commit();
    }

    /**
     * Read preview images version.
     *
     * @return the int
     */
    public int readPreviewImagesVersion() {
        final String previewImagesVersion = readPref(PREVIEW_IMAGE_VERSION, "0");
        return Integer.valueOf(previewImagesVersion);
    }

    /**
     * Read nab auth status.
     *
     * @return true, if successful
     */
    public boolean readNabAuthStatus() {
        final String loginStatus = readPref(NAB_AUTH_STATUS_KEY, "false");
        return Boolean.valueOf(loginStatus);
    }

    /**
     * Saves user id in private local storage.
     *
     * @param userID the user id
     */
    public void saveUserID(final String userID) {
        savePref(USER_ID, userID);
    }

    /**
     * Reads user id from private local storage.
     *
     * @return the string
     */
    public String readUserID() {
        return readPref(USER_ID, "");
    }

    /**
     * Read user email from GENERAL_PREF.
     * @return the string
     */
    public String readEmail() {
        return readPref(EMAIL_KEY, "");
    }

    /**
     * Save user email in GENERAL_PREF.
     * @param email the email
     */
    public void saveEmail(final String email) {
        final SharedPreferences settings = mContext.getSharedPreferences(EMAIL_KEY, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(EMAIL_KEY, email);
        editor.commit();
    }

    /**
     * Save context token on private phone storage.
     *
     * @param token the token
     */
    public void saveContextToken(final String token) {
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(CONTEXT_TOKEN, token);
        editor.commit();
    }

    /**
     * Reads LLT from private local storage.
     *
     * @return the string
     */
    public String readContextToken() {
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final String token = settings.getString(CONTEXT_TOKEN, "");
        mLog.d(LOG_TAG, "readContextToken = " + token);
        return token;
    }

    /**
     * Save access token on private phone storage.
     *
     * @param token the token
     */
    public void saveAccessToken(final String token) {
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(ACCESS_TOKEN, token);
        editor.commit();
    }

    /**
     * Reads SLT from private local storage.
     *
     * @return the string
     */
    public String readAccessToken() {
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final String token = settings.getString(ACCESS_TOKEN, "");
        mLog.d(LOG_TAG, "readAccessToken = " + token);
        return token;
    }

    /**
     * Saves the status of the user account - is the user allowed to use the app over Wifi. This is just a helper, the
     * proper information is received from the server after a login attempt.
     *
     * @param isAccountBlocked the is account blocked
     */
    public void saveIsAccountBlocked(final boolean isAccountBlocked) {
        final SharedPreferences settings = mContext.getSharedPreferences(IS_ACCOUNT_BLOCKED_PREF,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(IS_ACCOUNT_BLOCKED, isAccountBlocked);
        editor.commit();
    }

    /**
     * Reads the status of the user account - is the user allowed to use the app over Wifi. This is just a helper, the
     * proper information is received from the server after a login attempt.
     *
     * @return {@code true} if the account was previously blocked or the user is yet to attempt a login for Wifi,
     * {@code false} otherwise.
     */
    public boolean readIsAccountBlocked() {
        // [OACJ-77]
        // isAccountBlocked = true at the begining, so that the app will pop up the login dialog
        boolean isAccountBlocked = true;
        final SharedPreferences settings = mContext.getSharedPreferences(IS_ACCOUNT_BLOCKED_PREF,
                Context.MODE_PRIVATE);
        isAccountBlocked = settings.getBoolean(IS_ACCOUNT_BLOCKED, true);
        mLog.d(LOG_TAG, "readIsAccountBlocked = " + isAccountBlocked);
        return isAccountBlocked;
    }

    /**
     * Save last upload date to preferences.
     *
     * @param date Last upload date
     */
    public void saveLastUploadDate(final String date) {
        mLog.d(LOG_TAG, "saveLastUploadDate " + date);
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_UPLOAD_DATE_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(LAST_UPLOAD_DATE, date);
        editor.commit();
    }

    /**
     * Save last uploaded file count.
     *
     * @param uploadedFileCount the uploaded file count
     */
    public void saveLastUploadedFileCount(final int uploadedFileCount) {
        mLog.d(LOG_TAG, "saveLastUploadedFileCount " + uploadedFileCount);
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_UPLOAD_FILE_COUNT_PREF,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putInt(LAST_UPLOAD_FILE_COUNT, uploadedFileCount);
        editor.commit();
    }

    /**
     * Save quick action check box status.
     *
     * @param checked the checked
     */
    public void saveQuickActionCheckBoxStatus(final boolean checked) {
        mLog.d(LOG_TAG, "saveQuickActionCheckBoxStatus " + checked);
        final SharedPreferences settings = mContext.getSharedPreferences(QUICK_ACTION_CHECK_BOX_PREF,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(QUICK_ACTION_CHECK_BOX, checked);
        editor.commit();
    }

    /**
     * Save initial sync status.
     *
     * @param initialSyncFinished the initial sync finished
     */
    public void saveInitialSyncStatus(final boolean initialSyncFinished) {
        mLog.d(LOG_TAG, "saveInitialSyncFinished " + initialSyncFinished);
        final SharedPreferences settings = mContext.getSharedPreferences(GENERAL_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(INITIAL_SYNC_FINISHED, initialSyncFinished);
        editor.commit();
    }

    /**
     * Save last download date to preferences.
     *
     * @param date Last download date
     */
    public void saveLastDownloadDate(final String date) {
        mLog.d(LOG_TAG, "saveLastDownloadDate " + date);
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_DOWNLOAD_DATE_PREF,
                Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putString(LAST_DOWNLOAD_DATE, date);
        editor.commit();
    }

    /**
     * Read quick action check box status.
     *
     * @return true, if successful
     */
    public boolean readQuickActionCheckBoxStatus() {
        boolean checked = false;
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(QUICK_ACTION_CHECK_BOX_PREF,
                Context.MODE_PRIVATE);
        checked = settings.getBoolean(QUICK_ACTION_CHECK_BOX, false);
        mLog.d(LOG_TAG, "readQuickActionCheckBoxStatus(): " + checked);
        return checked;
    }

    /**
     * Read initial sync status.
     *
     * @return true, if successful
     */
    public boolean readInitialSyncStatus() {
        boolean initialSyncFinished = false;
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(GENERAL_PREF, Context.MODE_PRIVATE);
        initialSyncFinished = settings.getBoolean(INITIAL_SYNC_FINISHED, false);
        mLog.d(LOG_TAG, "readInitialSyncStatus(): " + initialSyncFinished);
        return initialSyncFinished;
    }

    /**
     * Read last upload file count.
     *
     * @return the int
     */
    public int readLastUploadFileCount() {
        int lastUploadedFileCount = 0;
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_UPLOAD_FILE_COUNT_PREF,
                Context.MODE_PRIVATE);
        lastUploadedFileCount = settings.getInt(LAST_UPLOAD_FILE_COUNT, 0);
        mLog.d(LOG_TAG, "readLastUploadFileCount(): " + lastUploadedFileCount);
        return lastUploadedFileCount;
    }

    /**
     * Read last download date from preferences.
     *
     * @return Last download date as formatted string
     */
    public String readLastDownloadDate() {
        String date = "";
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_DOWNLOAD_DATE_PREF,
                Context.MODE_PRIVATE);
        date = settings.getString(LAST_DOWNLOAD_DATE, "");
        mLog.d(LOG_TAG, "readLastDownloadDate(): " + date);
        return date;
    }

    /**
     * Read last upload date from preferences.
     *
     * @return Last upload date as formatted string
     */
    public String readLastUploadDate() {
        String date = "";
        // Restore token
        final SharedPreferences settings = mContext.getSharedPreferences(LAST_UPLOAD_DATE_PREF, Context.MODE_PRIVATE);
        date = settings.getString(LAST_UPLOAD_DATE, "");
        mLog.d(LOG_TAG, "readLastUploadDate(): " + date);
        return date;
    }

    /**
     * Read client config app version.
     *
     * @return the int
     */
    public int readClientConfigAppVersion() {
        final String appVersion = readPref(CLIENT_CONFIG_APP_VERSION, "0");
        return Integer.valueOf(appVersion);
    }

    /**
     * Save client config app version.
     */
    public void saveClientConfigAppVersion() {
        final int appVersion = getAppVersion();
        savePref(CLIENT_CONFIG_APP_VERSION, String.valueOf(appVersion));
    }

    /**
     * Save preview images version.
     *
     * @param previewImagesVersion the preview images version
     */
    public void savePreviewImagesVersion(final int previewImagesVersion) {
        savePref(PREVIEW_IMAGE_VERSION, String.valueOf(previewImagesVersion));
    }

    // SDCANDTACT-4274

    /**
     * Read dv account deactivated.
     *
     * @return true, if successful
     */
    public boolean readDvAccountDeactivated() {
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final boolean result = settings.getBoolean(DV_ACCOUNT_DEACTIVATED, false);
        mLog.d(LOG_TAG, "readDvAccountDeactivated = " + result);
        return result;
    }

    // SDCANDTACT-4274

    /**
     * Save dv account deactivated.
     *
     * @param isDeactivated the is deactivated
     */
    public void saveDvAccountDeactivated(final boolean isDeactivated) {
        final SharedPreferences settings = mContext.getSharedPreferences(CONTEXT_TOKEN_PREF, Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean(DV_ACCOUNT_DEACTIVATED, isDeactivated);
        editor.commit();
    }

    /**
     * Gets the app version.
     * @return the app version
     */
    public int getAppVersion() {
        PackageInfo pInfo;
        try {
            pInfo = mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0);
            return pInfo.versionCode;
        } catch (final PackageManager.NameNotFoundException e) {
            mLog.d(LOG_TAG, "getAppVersion NameNotFoundException", e);
            return 0;
        }

    }

}

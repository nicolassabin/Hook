/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;


/**
 * The Class PreferencesEndPointImpl.
 */

@SuppressLint("ApplySharedPref")
public class MySharePreferences {

    /** The m preferences name. */
    private final String mPreferencesName;

    /** The m context app. */
    private final Context mContextApp;

    // @Inject
    /**
     * Instantiates a new preferences end point impl.
     * @param context the context
     * @param preferencesName the preferences name
     */
    public MySharePreferences(final Context context, final String preferencesName) {
        // @Named("applicationLabel") String applicationLabel
        mContextApp = context;
        mPreferencesName = preferencesName;
    }

    /**
     * Close editor.
     * @param editor the editor
     */
    private void closeEditor(final Editor editor) {
        // Don't forget to commit your edits!!!
        editor.commit();
    }

    /**
     * @see MySharePreferences#saveBooleanPreference(String, boolean)
     */
    public void saveBooleanPreference(final String key, final boolean value) {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.putBoolean(key, value);
        closeEditor(editor);
    }

    /**
     * @see MySharePreferences#saveIntPreference(String, int)
     */
    public void saveIntPreference(final String key, final int value) {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.putInt(key, value);
        closeEditor(editor);
    }

    /**
     * @see MySharePreferences#saveLongPreference(String, long)
     */
    public void saveLongPreference(final String key, final long value) {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.putLong(key, value);
        closeEditor(editor);
    }

    /**
     * @see MySharePreferences#saveStringPreference(String,
     *      String)
     */
    public void saveStringPreference(final String key, final String value) {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.putString(key, value);
        closeEditor(editor);
    }

    /**
     * @see MySharePreferences#getSharedPreferences()
     */
    public SharedPreferences getSharedPreferences() {
        return mContextApp.getSharedPreferences(mPreferencesName, 0);
    }

    /**
     * @see MySharePreferences#getBooleanPreference(String)
     */
    public boolean getBooleanPreference(final String key) {
        // Restore preferences
        return getSharedPreferences().getBoolean(key, false);
    }

    /**
     * @see MySharePreferences#getIntPreference(String)
     */
    public int getIntPreference(final String key) {
        return getSharedPreferences().getInt(key, 0);
    }

    /**
     * @see MySharePreferences#getIntPreference(String, int)
     */
    public int getIntPreference(final String key, final int defValue) {
        return getSharedPreferences().getInt(key, defValue);
    }

    /**
     * @see MySharePreferences#getLongPreference(String, long)
     */
    public long getLongPreference(final String key, final long defValue) {
        return getSharedPreferences().getLong(key, defValue);
    }

    /**
     * @see MySharePreferences#getStringPreference(String)
     */
    public String getStringPreference(final String key) {
        return getSharedPreferences().getString(key, "");
    }

    /**
     * @see MySharePreferences#getStringPreference(String,
     *      String)
     */
    public String getStringPreference(final String key, final String defValue) {
        return getSharedPreferences().getString(key, defValue);
    }

    /**
     * @see MySharePreferences#removePreference(String)
     */
    public void removePreference(final String key) {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.remove(key);
        closeEditor(editor);
    }

    /**
     * @see MySharePreferences#clearAll()
     */
    public void clearAll() {
        final SharedPreferences settings = getSharedPreferences();
        final Editor editor = settings.edit();
        editor.clear();
        editor.commit();
    }


}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.inerdev.hook.R;
import com.inerdev.hook.ui.utils.SpanTokensHelper;


public class WizardGetStartedActivity extends AppCompatActivity {

    /** The log tag. */
    private final String LOG_TAG = "WizardGetStartedActivity";

    /** The TextView terms and conditions. */
    private TextView termsAndConditions;

    /** The m span tokens helper. */
    private SpanTokensHelper mSpanTokensHelper;

    /** The m log. */
    private Log mLog;

    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSpanTokensHelper = new SpanTokensHelper();
        overridePendingTransition(0, 0);

        setContentView(R.layout.splashscreen_connecting);

        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }

        makeAllClickableAndVisible();

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
    }


    private void startWizard() {
        final Intent intent = new Intent(WizardGetStartedActivity.this, WizardActivity.class);
        if (getIntent().getExtras() != null) {
            intent.putExtras(getIntent().getExtras());
        }
        startActivity(intent);
        this.finish();
    }

    /**
     * Make terms and conditions clickable.
     */

    private void makeTermsAndConditionsClickable() {
        CharSequence link = getString(R.string.get_started_terms_of_service);
        link = mSpanTokensHelper.setSpanBetweenTokens(link, "##", new ForegroundColorSpan(getResources().getColor(
                R.color.text_white)), new UnderlineSpan(), new ClickableSpan() {
            public void onClick(final View widget) {
                launchTermsOfService(getApplicationContext());
            }
        });
        termsAndConditions.setText(link);
        termsAndConditions.setGravity(Gravity.CENTER);
        termsAndConditions.setMovementMethod(LinkMovementMethod.getInstance());
        termsAndConditions.setVisibility(View.VISIBLE);
    }

    private void makeAllClickableAndVisible() {
        final ProgressBar progressSplash = (ProgressBar) findViewById(R.id.progressSplash);
        final RelativeLayout bottomLayout = (RelativeLayout) findViewById(R.id.splash_bottom);
        final Button getStartedButton = (Button) findViewById(R.id.get_started_wizard_button);
        getStartedButton.setVisibility(View.VISIBLE);
        termsAndConditions = (TextView) findViewById(R.id.hook_terms_of_service_text);
        makeTermsAndConditionsClickable();

        if (progressSplash != null) {
            progressSplash.setVisibility(View.GONE);
        }

        if (bottomLayout != null) {
            bottomLayout.setVisibility(View.VISIBLE);
        }

        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startWizard();
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setContentView(R.layout.splashscreen_connecting);
        makeAllClickableAndVisible();
    }

    /**
     * Launch terms of service.
     *
     * @param context the context
     */
    private void launchTermsOfService(final Context context) {
        final Intent intent = new Intent(context, TermsOfService.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.provider.Settings;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;


import com.inerdev.hook.R;
import com.inerdev.hook.core.CoreException;
import com.inerdev.hook.core.ErrorCode;

import java.util.Locale;

/**
 * The Class DeviceDetails.
 */
//@Singleton
public class DeviceDetails {

    /** The Constant TAG. */
    private static final String TAG = "DeviceDetails";

    /**
     * The x_application_identifier.
     */
    protected final String application_user_agent = "hook/%1$s (%2$s; %3$s) %4$s";

    /** The Constant VERSION. */
    public static final String VERSION				= "v1";

    /** The Constant IMEI_PREFIX. */
    private static final String IMEI_PREFIX				= "imei_";
    /** The Constant DEVICEID_PREFIX. */
    private static final String DEVICEID_PREFIX			= "mac_";

    /** The Constant MCC_LENGTH. */
    private static final int MCC_LENGTH = 3;

    /** The m log. */
    private final Log mLog;

    /** The m context. */
    private final Context mContext;

    /**
     * Instantiates a new device details.
     * @param context the context
     * @param log the log
     */
    public DeviceDetails(final Context context, final Log log) {
        mContext = context;
        mLog = log;
    }

    /**
     * Gets the id.
     * @return the id
     */
    public String getId() {
        String result = getAndroidId();

        mLog.d(TAG, "getId: returning id " + result);
        return result;
    }

    /**
     * Gets the app id.
     * @return the app id
     */
    public String getAppId() {
        String result = generateUserAgent(mContext);

        mLog.d(TAG, "getAppId: returning id " + result);
        return result;
    }

    /**
     * Gets the android id.
     * @return the android id
     */
    private String getAndroidId() {
        return Secure.getString(mContext.getContentResolver(), Secure.ANDROID_ID);
    }

    /**
     * Gets the name.
     * @return the name
     */
    public String getName() {
        String result;

        // There is no "best combination" for all devices.
        // Manufacturer + Model is "somewhat friendly" on "some devices"

        if (Build.MODEL.toUpperCase().contains(Build.MANUFACTURER.toUpperCase())) {
            // If the OEM included the manufacturer string in the model string,
            // let's just use the model string alone (like "HTC Desire")
            // we make sure it starts with an upparcase char
            result = firstCharToUpper(Build.MODEL);
        } else {
            // ..otherwise let's use the manufacturer + model
            // it may result in strings like "motorola Milestone" and "HTC ADR6400L"
            // we make sure both components start with an upparcase char
            result = String.format("%s %s", firstCharToUpper(Build.MANUFACTURER), firstCharToUpper(Build.MODEL));
        }

        mLog.d(TAG, "name = " + result);

        return result;
    }

    /**
     * Generate user agent.
     *
     * @return the string
     */
    private String generateUserAgent(Context context) {
        // Version
        String version = null;
        try {
            final PackageManager pkgManager = context.getPackageManager();
            final PackageInfo pi = pkgManager.getPackageInfo(context.getPackageName(), 0);
            version = pi.versionName; // 0 - no flags
        } catch (final PackageManager.NameNotFoundException e) {
        }

        // Locale
        final String locale = Locale.getDefault().toString();

        // OS Version
        final StringBuilder osVersion = new StringBuilder("Android");
        // removed
        osVersion.append(" ").append(Build.VERSION.RELEASE);

        // Device
        final StringBuilder device = new StringBuilder();
        device.append(android.os.Build.MANUFACTURER);
        device.append("/");

        String detail = android.os.Build.MODEL;
        if (detail != null && detail.length() == 0) {
            detail = android.os.Build.DEVICE;
            if (detail != null && detail.length() == 0) {
                detail = android.os.Build.PRODUCT;
            }
        }
        device.append(detail);

        String ua = String.format(application_user_agent, version, locale, osVersion, device);
        //TODO shall be removed later
        ua = context.getResources().getString(R.string.app_id);
        return ua;
    }

    /**
     * Gets the DeviceIdentifier.
     * @return the DeviceIdentifier
     */
    public String getDeviceIdentifier() {
        return getVersionName(mContext)+"|"+ getDeviceId(mContext)+"|"+mContext.getPackageName()+"|"+ getDeviceName();
    }

    /**
     * Greturn if deveice is a tablet.
     * @return true if tablet
     */
    public static boolean isTablet(Context a_Context)
    {
        return isTabletConfiguration(a_Context);
    }



    // returns the 3 digit MCC as an integer OR -1
    /**
     * Gets the mcc.
     * @return the mcc
     */
    public int getMcc() {
        int result = -1;
        final TelephonyManager telMan = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        if (telMan != null) {
            try {
                final String operator = telMan.getSimOperator();
                if (!TextUtils.isEmpty(operator) && operator.length() >= MCC_LENGTH) {
                    final String mcc = operator.substring(0, MCC_LENGTH);
                    try {
                        result = Integer.valueOf(mcc);
                    } catch (final NumberFormatException e) {
                        mLog.e(TAG, "exception ", e);
                    }
                }
            }
            catch (Exception e)
            {
                mLog.e(TAG, "getMcc: exception ", e);
            }
        }

        mLog.d(TAG, "getMcc => " + result);
        return result;
    }

    /**
     * Creates an {@code Accept-Language} header value based on the actual local settings on the device (like
     * {@code en-IE} or {@code en}).
     * @return The {@code Accept-Language} header value
     * @throws CoreException the cloud sdk exception
     */
    public String getAcceptLanguageHeaderValue() throws CoreException {
        final Locale locale = Locale.getDefault();
        final String language = locale.getLanguage();
        final String country = locale.getCountry();
        final boolean hasLanguage = !TextUtils.isEmpty(language);
        final boolean hasCountry = !TextUtils.isEmpty(country);

        String result = null;

        if (hasLanguage && hasCountry) {
            result = String.format("%s-%s", language, country);
        } else if (hasLanguage) {
            result = language;
        } else {
            // This is not expected to happen, but let's handle this case anyways
            throw new CoreException(ErrorCode.ERR_IO, "Language is not set in locale");
        }

        mLog.d(TAG, "getAcceptHeaderValue() returns: " + result);

        return result;
    }

    private static String getDeviceName()
    {
        String manufacturer = filter(android.os.Build.BRAND);
        String product = filter(android.os.Build.PRODUCT);
        String model = filter(android.os.Build.MODEL);

        String deviceKey = manufacturer + "_" + product + "_" + model;

        return deviceKey;

    }

    /**
     * Get the versionname from the manifest
     *
     * @param a_Context
     * @return versionname
     */
    private static String getVersionName(Context a_Context)
    {
        return VERSION;
    }

    private String getDeviceId(Context a_Context)
    {
        // set as null for tablet or emulator
        String ret = null;

        if(a_Context == null)
        {
            return ret;
        }

        // should be changed later on server side.
        // that allows to map with the deviceAgent created by server at the first carddav sync

        TelephonyManager telManager = (TelephonyManager) (a_Context.getSystemService(Context.TELEPHONY_SERVICE));
        if(telManager != null)
        {
            boolean isEmulator = android.os.Build.MODEL != null
                    && (android.os.Build.MODEL.equalsIgnoreCase("google_sdk") || android.os.Build.MODEL
                    .equalsIgnoreCase("sdk"));

            if(!isEmulator && !isTablet(a_Context))
            {
                try {
                    String sImei = telManager.getDeviceId();
                    if (!TextUtils.isEmpty(sImei)) {
                        ret = IMEI_PREFIX + sImei;
                        return ret;
                    }
                }
                catch (Exception e)
                {
                    mLog.e(TAG, "getDeviceId: exception ", e);
                }
            }
            else if(isEmulator)
            {
                StringBuilder tempBuffer = new StringBuilder();
                tempBuffer.append(getDeviceName());
                tempBuffer.append("_");
                tempBuffer.append(Long.toString(System.currentTimeMillis()));
                ret = Integer.toString(tempBuffer.toString().hashCode());
            }
            else
            {
                ret = DEVICEID_PREFIX + Settings.Secure.getString(a_Context.getContentResolver(), Settings.Secure.ANDROID_ID);
            }
        }
        else
        {
            ret = DEVICEID_PREFIX + Settings.Secure.getString(a_Context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }

        return ret;
    }

    private static String filter(String a_Value)
    {
        String result;

        if(a_Value == null)
        {
            return null;
        }

        result = a_Value.replace('.', '_');
        result = result.replace(' ', '_');
        result = result.replace('-', '_');

        return result.toLowerCase();
    }



    private static boolean isTabletConfiguration(Context context)
    {
        try {
            Configuration config = context.getResources().getConfiguration();
            if(config.smallestScreenWidthDp >= 600) {
                return true;
            }
        } catch (ClassCastException ex) {
        }

        return false;
    }

    /**
     * First char to upper.
     * @param s the s
     * @return the string
     */
    private static String firstCharToUpper(final String s) {
        return TextUtils.isEmpty(s) ? s : (Character.toUpperCase(s.charAt(0)) + s.substring(1));
    }


}

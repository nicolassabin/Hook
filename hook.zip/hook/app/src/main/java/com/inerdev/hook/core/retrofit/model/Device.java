/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import com.google.gson.annotations.SerializedName;

/**
 * The Class Device.
 */
public class Device {


    /** The user's unique id */
    @SerializedName("id")
    private String mId;

    /** The user's name */
    @SerializedName("name")
    private String mName;

    /** The user's displayName */
    @SerializedName("displayName")
    private String mDisplayName;

    /** The user's dateCreation */
    @SerializedName("dateCreation")
    private String mDateCreation;

    /** The user's address */
    @SerializedName("address")
    private String mAddress;

    /** type */
    @SerializedName("type")
    private String mType;

    /** key */
    @SerializedName("key")
    private String mKey;

    /** status */
    @SerializedName("status")
    private int mStatus;


    /**
     * Gets the Id.
     * @return the Id
     */
    public String getId() {
        return mId;
    }

    /**
     * Gets the mName.
     * @return the mName
     */
    public String getName() {
        return mName;
    }

    /**
     * Gets the mDisplayName.
     * @return the mDisplayName
     */
    public String getDisplayName() {
        return mDisplayName;
    }

    /**
     * Gets the mDateCreation.
     * @return the mDateCreation
     */
    public String getDateCreation() {
        return mDateCreation;
    }

    /**
     * Gets the mAddress.
     * @return the mAddress
     */
    public String getAddress() {
        return mAddress;
    }


    /**
     * Gets the mKey.
     * @return the mKey
     */
    public String getKey() {
        return mKey;
    }

    /**
     * Gets the mType.
     * @return the mType
     */
    public String getType() {
        return mType;
    }

    /**
     * Gets the mStatus.
     * @return the mStatus
     */
    public int getStatus() {
        return mStatus;
    }


}

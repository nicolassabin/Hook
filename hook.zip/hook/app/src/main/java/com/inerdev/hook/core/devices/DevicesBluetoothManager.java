package com.inerdev.hook.core.devices;

import android.annotation.TargetApi;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.provider.AppContract;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.os.Build.VERSION_CODES.JELLY_BEAN_MR2;


/**
 * Created by nsab0001 on 01/06/2017.
 */

public class DevicesBluetoothManager extends BDevicesManager {

    private static final String LOG_TAG = "DevicesBluetoothManager";

    private static final boolean USE_BT_LE_SCANNER = false;

    /** The DEFAULT_TIMEOUT */
    public static final int		    DEFAULT_TIMEOUT							    = 300;


    /** The m BluetoothManager. */
    private BluetoothLeScanner mBluetoothLeScanner = null;

    /** The m BluetoothAdapter. */
    private BluetoothAdapter mBluetoothAdapter;

    /** The m mMyScanCallBack. */
    private Object mMyScanCallBack = null;

    private int mTimeout= DEFAULT_TIMEOUT;


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    public DevicesBluetoothManager(Context context) {
        super(context);
        if (Build.VERSION.SDK_INT >= JELLY_BEAN_MR2) {
            BluetoothManager bluetoothManager = (BluetoothManager) mContext.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager != null) {
                mMyScanCallBack = new MyScanCallBack();
                mBluetoothAdapter = bluetoothManager.getAdapter();
            }
        } else {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }

        IntentFilter i = new IntentFilter();
        i.addAction(BluetoothDevice.ACTION_FOUND);
        i.addAction(BluetoothDevice.ACTION_UUID);
        i.addAction(BluetoothDevice.ACTION_NAME_CHANGED);
        i.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        i.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        i.addAction(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        mContext.registerReceiver(this, i);

    }

    /**
     * start Scanning.
     * @param  scanCallBackOperation
     * @param timeout
     */
    public void startScanning(ScanCallBackOperation scanCallBackOperation, int timeout){
        mLog.d(LOG_TAG, "startScanning");
        if (mBluetoothAdapter != null){
            mScanCallBackOperation = scanCallBackOperation;
            mTimeout = timeout;
            if (!mBluetoothAdapter.isEnabled()){
                mBluetoothAdapter.enable();
            } else {
                startBTScan();
            }
        } else{
            mLog.e(LOG_TAG, "startScanning invalid mBluetoothAdapter");
        }


    }

    /**
     * close.
     *
     */
    public void close(){
        mLog.d(LOG_TAG, "close");
        if (mBluetoothLeScanner == null){
            mContext.unregisterReceiver(this);
        }
        stopScanning();
        super.close();
    }

    /**
     * stop Scanning.
     *
     */
    public void stopScanning(){
        mLog.d(LOG_TAG, "stopScanning");
        if (mBluetoothAdapter != null) {
            mScanCallBackOperation = null;
            mListDevicesAddress.clear();
            if (mBluetoothLeScanner != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mBluetoothLeScanner.stopScan(null);
            } else {
                mBluetoothAdapter.cancelDiscovery();
            }

            mBluetoothAdapter.disable();
        } else{
            mLog.e(LOG_TAG, "stopScanning invalid mBluetoothAdapter");
        }
    }


    /**
     * This method is called when the BroadcastReceiver is receiving an Intent
     * broadcast.  During this time you can use the other methods on
     * BroadcastReceiver to view/modify the current result values.  This method
     * is always called within the main thread of its process, unless you
     * explicitly asked for it to be scheduled on a different thread using
     * thread you should
     * never perform long-running operations in it (there is a timeout of
     * 10 seconds that the system allows before considering the receiver to
     * be blocked and a candidate to be killed). You cannot launch a popup dialog
     * in your implementation of onReceive().
     * <p>
     * <p><b>If this BroadcastReceiver was launched through a &lt;receiver&gt; tag,
     * then the object is no longer alive after returning from this
     * function.</b>  This means you should not perform any operations that
     * return a result to you asynchronously -- in particular, for interacting
     * with services, you should use
     * {@link Context#startService(Intent)} instead of
     * to interact with a service that is already running, you can use
     * {@link #peekService}.
     * <p>
     * <p>The Intent filters used in {@link Context#registerReceiver}
     * and in application manifests are <em>not</em> guaranteed to be exclusive. They
     * are hints to the operating system about how to find suitable recipients. It is
     * possible for senders to force delivery to specific recipients, bypassing filter
     * resolution.  For this reason, {@link #onReceive(Context, Intent) onReceive()}
     * implementations should respond only to known actions, ignoring any unexpected
     * Intents that they may receive.
     *
     * @param context The Context in which the receiver is running.
     * @param intent  The Intent being received.
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        mLog.d(LOG_TAG, "onReceive action " + action);
        if (BluetoothDevice.ACTION_FOUND.equals(action)
                || BluetoothDevice.ACTION_NAME_CHANGED.equals(action) ) {
            addBlueToothDevice((BluetoothDevice)intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE),
                    intent.getStringExtra(BluetoothDevice.EXTRA_NAME)
                ,(ParcelUuid)intent.getParcelableExtra(BluetoothDevice.EXTRA_UUID));

        } else if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)){
            int status = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
            mLog.d(LOG_TAG, "onReceive status " + status);
            if (status == BluetoothAdapter.STATE_ON) {
                startBTScan();
            }/* else if (status == BluetoothAdapter.STATE_TURNING_OFF || status == BluetoothAdapter.STATE_OFF ){
                if (mScanCallBackOperation != null){
                    mScanCallBackOperation.onError(status);
                }
            }*/
        } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
            if (mScanCallBackOperation != null){
                mScanCallBackOperation.onEnd();
            }
            mLog.d(LOG_TAG, "onReceive ACTION_DISCOVERY_FINISHED");
        }  else if (BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE.equals(action)){
            mLog.d(LOG_TAG, "onReceive ACTION_REQUEST_DISCOVERABLE");
            startBTScan();
        }


    }

    private void startBTScan() {
        mLog.d(LOG_TAG, "startBTScan mTimeout" + mTimeout);

        if (mBluetoothAdapter != null){
            if (USE_BT_LE_SCANNER && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
                if (mBluetoothLeScanner != null){
                    mBluetoothLeScanner.flushPendingScanResults((MyScanCallBack)mMyScanCallBack);
                    ScanSettings.Builder scanSettingsB = new ScanSettings.Builder();
                    scanSettingsB.setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES);
                    mBluetoothLeScanner.startScan(null, scanSettingsB.build(), (MyScanCallBack)mMyScanCallBack);
                } else {
                    mLog.i(LOG_TAG, "startBTScan getBluetoothLeScanner failed");
                    myStartDiscovery();
                }
            } else {
                mLog.d(LOG_TAG, "startBTScan mBluetoothAdapter.getScanMode() " + mBluetoothAdapter.getScanMode());
                myStartDiscovery();
            }
        }

    }

    private void myStartDiscovery() {
        if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            mLog.d(LOG_TAG, "myStartDiscovery startActivity(discoverableIntent) timeout " + mTimeout);
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK );
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, mTimeout);
            mContext.startActivity(discoverableIntent);
        }
        else {
            mBluetoothAdapter.startDiscovery();
        }
    }

    private boolean setBluetoothScanMode(int scanMode){
        Method method = null;

        try {
            method = mBluetoothAdapter.getClass().getMethod("setScanMode", int.class);
        } catch (SecurityException e) {
            return false;
        } catch (NoSuchMethodException e) {
            return false;
        }

        try {
            method.invoke(mBluetoothAdapter, scanMode);
        } catch (IllegalArgumentException e) {
            return false;
        } catch (IllegalAccessException e) {
            return false;
        } catch (InvocationTargetException e) {
            return false;
        }
        return true;
    }

    private void checkAndAddBlueToothDevice(BluetoothDevice device) {
        if (device != null){
            if (!mListDevicesAddress.containsKey(device.getAddress())){
                addBlueToothDevice(device, null, null);
            } else if ((mListDevicesAddress.get(device.getAddress()).getStatus() != AppContract.Devices.DEVICE_DELETED)
                    && (mListDevicesAddress.get(device.getAddress()).getStatus() != AppContract.Devices.DEVICE_ACCEPTED)){
                addBlueToothDevice(device, null, null);
            }
        }
    }

    private void addBlueToothDevice(final BluetoothDevice device, final String deviceNameParam, final ParcelUuid parcelUuid) {

        mLog.d(LOG_TAG, "addBlueToothDevice  myDevice name: "  +
                mBluetoothAdapter.getName() + " Address:" + mBluetoothAdapter.getAddress());
        Thread thread = new Thread(new Runnable(){
            public void run() {
                String deviceName = device.getName();
                if (TextUtils.isEmpty(deviceName)){
                    deviceName = device.getAddress();
                }
                // Create a new device item
                mLog.d(LOG_TAG, "addBlueToothDevice  deviceName " + deviceName
                                +  " device name " + device.getName());
                String Uiid = device.getAddress();
                if (parcelUuid != null) {
                    mLog.d(LOG_TAG, "addBlueToothDevice  parcelUuid " + parcelUuid.toString());
                    Uiid = parcelUuid.getUuid().toString();
                }

                // check if the device is registered on the platform,
                // if yes, it is auto-accepted
                // TODO later A notification will be send to the user to  accept or not the device
                String deviceUserId = getDeviceUserId(device.getAddress());
                mLog.d(LOG_TAG, "MSG_ADD_DEVICE_INFO device userID " +deviceUserId
                        + " for this adr:" + device.getAddress());

                DeviceInfo deviceInfo = new DeviceInfo(Uiid ,
                        device.getAddress(), deviceName, deviceName,
                        deviceUserId);
                // TODO will be accepted after user confirmation
                // check later if device should be added or not into database
                if (!TextUtils.isEmpty(deviceUserId)) {
                    deviceInfo.setStatus(AppContract.Devices.DEVICE_ACCEPTED);
                } else {
                    deviceInfo.setStatus(AppContract.Devices.DEVICE_PENDING);
                }
                mListDevicesAddress.put( deviceInfo.getAdr(), deviceInfo);
                if (mScanCallBackOperation != null){
                    mScanCallBackOperation.onScanResult(deviceInfo);
                }
                //mHandler.sendMessage(mHandler.obtainMessage(MSG_ADD_DEVICE_INFO, 0, 0, deviceInfo));
            }
        });
        thread.start();


    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private class MyScanCallBack extends ScanCallback{
        /**
         * Callback when a BLE advertisement has been found.
         *
         * @param callbackType Determines how this callback was triggered. Could be one of
         *            {@link ScanSettings#CALLBACK_TYPE_ALL_MATCHES},
         *            {@link ScanSettings#CALLBACK_TYPE_FIRST_MATCH} or
         *            {@link ScanSettings#CALLBACK_TYPE_MATCH_LOST}
         * @param result A Bluetooth LE scan result.
         */
        public void onScanResult(int callbackType, ScanResult result) {
            mLog.d(LOG_TAG, "onScanResult  callbackType " + callbackType
                + " ScanResult " + result.toString());
            switch(callbackType){
                case ScanSettings.CALLBACK_TYPE_ALL_MATCHES:
                    checkAndAddBlueToothDevice(result.getDevice());
                    break;
                case ScanSettings.CALLBACK_TYPE_FIRST_MATCH:
                    break;
                case ScanSettings.CALLBACK_TYPE_MATCH_LOST:
                    break;

            }

        }

        /**
         * Callback when batch results are delivered.
         *
         * @param results List of scan results that are previously scanned.
         */
        public void onBatchScanResults(List<ScanResult> results) {
            mLog.d(LOG_TAG, "onScanResult  results " + results.toString());
            for (ScanResult result : results){
                checkAndAddBlueToothDevice(result.getDevice());
            }
        //    stopScanning();
        }

        /**
         * Callback when scan could not be started.
         *
         * @param errorCode Error code (one of SCAN_FAILED_*) for scan failure.
         */
        public void onScanFailed(int errorCode) {
            mLog.d(LOG_TAG, "onScanFailed  errorCode " + errorCode);

        }
    }
}

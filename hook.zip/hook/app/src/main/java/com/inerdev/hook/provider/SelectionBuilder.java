/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */

/*
 * Modifications:
 * -Imported from AOSP frameworks/base/core/java/com/android/internal/content
 * -Changed package name
 */

package com.inerdev.hook.provider;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


/**
 * The Class SelectionBuilder.
 */
public class SelectionBuilder {

    /** The Constant TAG. */
    private static final String TAG = "SelectionBuilder";

    /** The m table. */
    private String mTable = null;

    /** The m projection map. */
    private final Map<String, String> mProjectionMap = new HashMap<String, String>();

    /** The m selection. */
    private final StringBuilder mSelection = new StringBuilder();

    /** The m selection args. */
    private final ArrayList<String> mSelectionArgs = new ArrayList<String>();

    /** The m log. */
    private Log mLog;

    /**
     * Instantiates a new selection builder.
     */
    public SelectionBuilder() {

    }

    /**
     * Reset.
     * @return the selection builder
     */
    public SelectionBuilder reset() {
        mTable = null;
        mSelection.setLength(0);
        mSelectionArgs.clear();
        return this;
    }

    /**
     * Where.
     * @param selection the selection
     * @param selectionArgs the selection args
     * @return the selection builder
     */
    public SelectionBuilder where(final String selection, final String... selectionArgs) {
        if (TextUtils.isEmpty(selection)) {
            if (selectionArgs != null && selectionArgs.length > 0) {
                throw new IllegalArgumentException("Valid selection required when including arguments=");
            }

            // Shortcut when clause is empty
            return this;
        }

        if (mSelection.length() > 0) {
            mSelection.append(" AND ");
        }

        mSelection.append("(").append(selection).append(")");
        if (selectionArgs != null) {
            Collections.addAll(mSelectionArgs, selectionArgs);
        }

        return this;
    }

    /**
     * Table.
     * @param table the table
     * @return the selection builder
     */
    public SelectionBuilder table(final String table) {
        mTable = table;
        return this;
    }

    /**
     * Assert table.
     */
    private void assertTable() {
        if (mTable == null) {
            throw new IllegalStateException("Table not specified");
        }
    }

    /**
     * Map.
     * @param fromColumn the from column
     * @param toClause the to clause
     * @return the selection builder
     */
    public SelectionBuilder map(final String fromColumn, final String toClause) {
        mProjectionMap.put(fromColumn, toClause + " AS " + fromColumn);
        return this;
    }

    /**
     * Gets the selection.
     * @return the selection
     */
    public String getSelection() {
        return mSelection.toString();
    }

    /**
     * Gets the selection args.
     * @return the selection args
     */
    public String[] getSelectionArgs() {
        return mSelectionArgs.toArray(new String[mSelectionArgs.size()]);
    }

    /**
     * Map columns.
     * @param columns the columns
     */
    private void mapColumns(final String[] columns) {
        for (int i = 0; i < columns.length; i++) {
            final String target = mProjectionMap.get(columns[i]);
            if (target != null) {
                columns[i] = target;
            }
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SelectionBuilder[table=" + mTable + ", selection=" + getSelection() + ", selectionArgs="
                + Arrays.toString(getSelectionArgs()) + "]";
    }

    /**
     * Query.
     * @param db the db
     * @param columns the columns
     * @param orderBy the order by
     * @return the cursor
     */
    public Cursor query(final SQLiteDatabase db, final String[] columns, final String orderBy) {
        return query(db, columns, null, null, orderBy, null);
    }

    /**
     * Query.
     * @param db the db
     * @param columns the columns
     * @param groupBy the group by
     * @param having the having
     * @param orderBy the order by
     * @param limit the limit
     * @return the cursor
     */
    public Cursor query(final SQLiteDatabase db, final String[] columns, final String groupBy, final String having, final String orderBy,
                        final String limit) {
        assertTable();
        if (columns != null)
            mapColumns(columns);
        final String selection = getSelection();
        final String[] selectionArgs = getSelectionArgs();
        return db.query(mTable, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
    }

    /**
     * Update.
     * @param db the db
     * @param values the values
     * @return the int
     */
    public int update(final SQLiteDatabase db, final ContentValues values) {
        assertTable();
        mLog.d(TAG, "update() " + this);
        return db.update(mTable, values, getSelection(), getSelectionArgs());
    }

    /**
     * Delete.
     * @param db the db
     * @return the int
     */
    public int delete(final SQLiteDatabase db) {
        assertTable();
        mLog.d(TAG, "delete() " + this);
        return db.delete(mTable, getSelection(), getSelectionArgs());
    }
}

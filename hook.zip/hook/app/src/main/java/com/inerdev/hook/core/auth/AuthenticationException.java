
package com.inerdev.hook.core.auth;

import com.inerdev.hook.core.CoreException;
import com.inerdev.hook.core.ErrorCode;

/**
 * The Class AuthenticationException.
 */
public class AuthenticationException extends CoreException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7777300877086026973L;

    /**
     * Instantiates an authentication exception with a root cause exception.
     * @param exception The root cause of this exception
     */
    public AuthenticationException(final Exception exception) {
        super(exception);
    }

    /**
     * Instantiates a new authentication exception with an error code.
     * @param code The error code
     */
    public AuthenticationException(final ErrorCode code) {
        super(code);
    }

    /**
     * Instantiates a new authentication exception with an error code and an error message.
     * @param code The error code
     * @param msg The error message
     */
    public AuthenticationException(final ErrorCode code, final String msg) {
        super(code, msg);
    }

    /**
     * Instantiates a new authentication exception with an error code and an error message.
     * @param code The error code
     * @param msg The error message
     * @param httpCode The error httpCode
     */
    public AuthenticationException(final ErrorCode code, final String msg, final int httpCode) {
        super(code, msg, httpCode);
    }

}

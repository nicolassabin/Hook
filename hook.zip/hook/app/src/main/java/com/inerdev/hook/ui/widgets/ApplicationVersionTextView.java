/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * The Class ApplicationVersionTextView.
 */
public class ApplicationVersionTextView extends AppCompatTextView {

    /**
     * Instantiates a new application version text view.
     * @param context the context
     * @param attrs the attrs
     */
    public ApplicationVersionTextView(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        if (isInEditMode()) {
            // avoid rendering issues in AndroidStudio
            setText("1.0.0");
        } else {
            setAppVersionString(getText().toString());
        }
    }

    /**
     * Sets the app version string.
     * @param text the new app version string
     */
    public void setAppVersionString(final String text) {
        PackageInfo packageInfo = null;
        try {
            packageInfo = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
        } catch (final NameNotFoundException e) {
            e.printStackTrace();
        }

        String version = "1.0.0";
        if (packageInfo != null) {
            version = packageInfo.versionName;
        }
        setText(String.format(text, version));
    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;


import com.google.gson.annotations.SerializedName;

/**
 *
 */

public class Error {

    /** This contains the message.*/
    @SerializedName("message")
    private String mMessage;

    /** This contains the statusCode.*/
    @SerializedName("statusCode")
    private String mStatusCode;

    /** This contains the code.*/
    @SerializedName("code")
    private String mCode;


    /**
     * return the message
     * @return String
     */
    public String getMessage()
    {

        return mMessage;
    }

    /**
     * return the StatusCode
     * @return String
     */
    public String getStatusCode()
    {
        return mStatusCode;
    }

    /**
     * return the Code
     * @return String
     */
    public String getCode()
    {
        return mCode;
    }

    /** set the Code
     * @param code the Code
     */
    public void setCode(String code)
    {
        mCode = code;
    }

    /** set the statusCode
     * @param statusCode the statusCode
     */
    public void setStatusCode(String statusCode)
    {
        mStatusCode = statusCode;
    }

    /** set the message
     * @param message the message
     */
    public void setMessage(String message)
    {
        mMessage = message;
    }

}


package com.inerdev.hook.core.auth;



/**
 * The Interface AuthenticationManager.
 */
public interface AuthenticationManager {

    /** The intent action auth. */
    public static final String INTENT_ACTION_AUTH = ".intent.action.AUTH";

    /**
     * Provides the current authentication information.
     * @return The current authentication information. Refer to {@link AuthenticationInfo}
     */
    public AuthenticationInfo getAuthenticationInfo();

    /**
     * isAuthenticated.
     *
     * @return boolean
     */
    public boolean isAuthenticated();

    /**
     * refresh the auth token if needed.
     * @return the auth token if needed
     * @throws AuthenticationException the auth model exception
     */
    public String refreshAuthTokenIfNeeded() throws AuthenticationException;

    /**
     * Refresh access token ex.
     *
     * @throws AuthenticationException the authentication exception
     */
    public String refreshAccessToken() throws AuthenticationException;

    /**
     * Stores the access token as expired access token for the lifetime of the process
     * <p class="note">
     * This call is used by classes that directly execute requests against the backend (adding the access token used in
     * requests that return 401/403 HTTP Status Code).
     * @param accessToken The access token that is known to be expired
     */
    public void addExpiredAccessToken(final String accessToken);

    /**
     * Authenticates the client.
     * @param login The user identifier
     * @param password The user password, or null when authenticationKey is OAUTH_TOKEN
     * @param deviceAdr The deviceAdr
     * @return AuthenticationInfo the AuthenticationInfo.
     * @throws AuthenticationException Occurs when the authentication operation fails and no callback has been provided.
     */
    public AuthenticationInfo signin(final String login, final String password, final String deviceAdr) throws AuthenticationException;

    /**
     * Logs out the user account. After this call, Personal Cloud service requests will fail until a new login is
     * performed using the API {@link #signin(String, String, String)}
     * @return true if logout is sucessfull, false othernwise .
     * @throws AuthenticationException
     */
    public void logout() throws AuthenticationException;

    /**
     * The API for provisioning a new account.
     * @param signupInfo The necessary information for creating the account. Refer to {@link SignupInfo}
     * @return AuthenticationInfo the AuthenticationInfo.
     * @throws AuthenticationException Raised when provisioning fails.
     */
    public AuthenticationInfo signup(SignupInfo signupInfo)
            throws AuthenticationException;


    /**
     * Used when the user has forgotten their password.
     * @param keyValue String
     * @return true if logout is sucessfull, false othernwise .
     * @throws AuthenticationException
     */
    public void forgotPassword(String keyValue) throws AuthenticationException;

    /**
     * Adds the listener.
     * @param iAuthenticationManagerListener the i authentication manager listener
     */
    public void addListener(AuthenticationManagerListener iAuthenticationManagerListener);

    /**
     * Removes the listener.
     * @param iAuthenticationManagerListener the i authentication manager listener
     */
    public void removeListener(AuthenticationManagerListener iAuthenticationManagerListener);

    /**
     * use getAuthenticationInfo().getUserId() instead
     * Gets the user uid.
     * @return the user uid
     */
    public String getUserUid();

    /**
     * return getAuthenticationInfo().getAccessToken()
     * Gets the user access token.
     * @return the user access token
     */
    public String getAccessToken();

    /**
     * String or to (re)authenticate the user.
     * @param redirectToAuthActivity the redirect to auth activity
     * @return the authentication token
     * @throws AuthenticationException the auth model exception
     */
    public String getAuthenticationToken(final boolean redirectToAuthActivity) throws AuthenticationException;



    }
/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import com.google.gson.annotations.SerializedName;


/**
 * The Class ProvisioningResult.
 */
public class ProvisionResult  {

    /** The id. */
    @SerializedName("id")
    private String mId;

    /** The _authorization code. */
    @SerializedName("authorization_code")
    private String mAuthorizationCode;

    /** The _phone number. */
    @SerializedName("phoneNumber")
    private String mPhoneNumber;

    /** The namespace. */
    @SerializedName("namespace")
    private String mNameSpace;

    /** The _account type. */
    @SerializedName("accountType")
    public String mAccountType;

    /** The name. */
    @SerializedName("name")
    private String mName;

    /** The _display name. */
    @SerializedName("displayName")
    private String mDisplayName;

    /** The _type. */
    @SerializedName("type")
    private String mType;


    /**
     * Gets the id.
     * @return the id
     */
    public String getId() {
        return mId;
    }

    /**
     * Gets the authorization code.
     * @return the authorization code
     */
    public String getAuthorizationCode() {
        return mAuthorizationCode;
    }

    /**
     * Gets the phone number.
     * @return the phone number
     */
    public String getPhoneNumber() {
        return mPhoneNumber;
    }

    /**
     * Gets the account type.
     * @return the account type
     */
    public String getAccountType() {
        return mAccountType;
    }

    /**
     * Gets the Namespace.
     * @return the Namespace
     */
    public String getNameSpace() {
        return mNameSpace;
    }

    /**
     * Gets the display name.
     * @return the display name
     */
    public String getDisplayName() {
        return mDisplayName;
    }

    /**
     * Gets the mName.
     * @return the mName
     */
    public String getName() {
        return mName;
    }

    /**
     * Gets the type.
     * @return the type
     */
    public String getType() {
        return mType;
    }

}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.inerdev.hook.core.auth.AuthenticationException;
import com.inerdev.hook.core.auth.AuthenticationManager;


/**
 * The Class LogOutTask.
 */
public class LogOutTask extends AsyncTask<Void, Void, Void> {

    /** The Constant LOG_TAG. */
    private static final String LOG_TAG = "LogOutTask";

    /** The m context. */
    private final Context mContext;

    /** The m mActivity. */
    private final Activity mActivity;

    /** The m log. */
    private Log mLog;

    /** The m AuthenticationManager. */
    private final AuthenticationManager mAuthenticationManager;

    /** The m  mPreferenceManager. */
    //private final PreferenceManager mPreferenceManager;


    /**
     * Instantiates a new log out task.
     */
    public LogOutTask(Context context, AuthenticationManager authenticationManager,
                      Activity activity) {
        super();

        mContext = context;
        mAuthenticationManager = authenticationManager;
        mActivity = activity;
    }

    /**
     * On pre execute.
     */
    @Override
    protected void onPreExecute() {

    }

    /**
     * Do in background.
     * @param params the params
     * @return the void
     */
    @Override
    protected Void doInBackground(final Void... params) {
        mLog.d(LOG_TAG, "Canceling UploadQueue...");

        try {
            mAuthenticationManager.logout();
        } catch (AuthenticationException e) {
            mLog.e(LOG_TAG, "doInBackground logout exception", e);
        }

        // clear all other core

        return null;
    }

    /**
     * On post execute.
     * @param result the result
     */
    @Override
    protected void onPostExecute(final Void result) {
        if (mActivity != null) {
            mActivity.finish();
        }
    }


}

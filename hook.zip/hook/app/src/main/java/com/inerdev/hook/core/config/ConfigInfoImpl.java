package com.inerdev.hook.core.config;

import android.content.Context;
import android.util.Log;

/**
 * Created by nsab0001 on 15/05/2017.
 */

public class ConfigInfoImpl implements ConfigInfo{

    private static final String LOG_TAG = "ConfigInfoImpl";

    // TODO change later that into http://inerdev.gomatch.com
    private static final String SERVER_URL = "https://easybackend.herokuapp.com/";
    private static final String AUTH_URL = "https://easybackend.herokuapp.com/";

    /**
     * The Log.
     */
    private Log mLog;

    /**
     * The Context.
     */
    private Context mContext;

    public ConfigInfoImpl(Context context){
        mContext = context;
        
    }

    /**
     * getServerUrl
     *
     * @return String
     */
    @Override
    public String getServerUrl() {
        return SERVER_URL;
    }

    /**
     * getAuthUrl
     *
     * @return String
     */
    @Override
    public String getAuthUrl() {
        return AUTH_URL;
    }
}

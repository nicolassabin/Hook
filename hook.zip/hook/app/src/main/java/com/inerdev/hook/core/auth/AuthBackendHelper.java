/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inerdev.hook.core.auth;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.core.http.CallBackHttpRequest;
import com.inerdev.hook.core.http.HttpClient;
import com.inerdev.hook.core.retrofit.model.Errors;
import com.inerdev.hook.core.utils.DeviceDetails;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;

import retrofit2.Response;

/**
 *
 * @author Nicolas Sabin
 */
public class AuthBackendHelper implements CallBackHttpRequest{

    private static final String LOG_TAG = "AuthBackendHelper";

    /*
    * BK_CONNECT
    */
    public static final int BK_CONNECT = 1;
    /*
    * BK_GETDATA
    */
    public static final int BK_GETDATA = 2;
    /*
    * BK_SETDATA
    */
    public static final int BK_SETDATA = 3;
    /*
    * BK_CALL
    */
    public static final int BK_CALL = 4;

    /*
    * USER_ID
    */
    private static final String USER_ID = "id";

    /*
    * USER_NAME
    */
    private static final String USER_NAME = "name";

    /*
    * USER_ADRESS
    */
    private static final String USER_ADRESS = "adress";


    /**
    * the m backend url server
    */
    private String mUrlServer;

    /**
    * the m Token
    */
    private String mToken;

    /**
     * the m mUserId
     */
    private String mUserId;

    /**
     * the m mUserName
     */
    private String mUserName;

    /**
     * the m mLogin
     */
    private String mLogin;

    /**
     * the m mDeviceAdr
     */
    private String mDeviceAdr;

    /**
     * the m mDeviceAdrInput
     */
    private String mDeviceAdrInput;

    /**
     * the m mDeviceAdr
     */
    private boolean mbAccountCreated;

    /**
    * the m Log
    */
    private Log mLog;

    /** The m lock. */
    private Object mLock;

    /** The m result. */
    private String mResult;

    /** The m mAuthBackendHelper. */
    private DeviceDetails mDeviceDetails;

    /** The m mContext. */
    private Context mContext;

    /**
     * Instantiates a new AuthBackendHelper.
     * @param context the context
     */
    public AuthBackendHelper(final Context context) {
        mContext = context;
        mDeviceDetails = new DeviceDetails(context, mLog);
    }

    /**
     * get login
     * @return String the login
     */
    public String getLogin() {
        return mLogin;
    }

    /**
     * get mToken
     * @return String the mToken
     */
    public String getToken() {
        return mToken;
    }

    /**
     * get mUserId
     * @return String the mUserId
     */
    public String getUserId() {
        return mUserId;
    }

    /**
     * get getUserName
     * @return String the getUserName
     */
    public String getUserName() {
        return mUserName;
    }

    /**
     * get mDeviceAdr
     * @return String the mDeviceAdr
     */
    public String getDeviceAdr() {
        return mDeviceAdr;
    }


    /**
     * connect the app with the backend
     * @param urlServer
     * @param login
     * @param password
     * @param deviceAdr
     * @return String the token
     */
    public boolean authenticate(final String urlServer, final String login, final String password, final String deviceAdr)
    {
        String appId = mDeviceDetails.getAppId();
        mLog.d(LOG_TAG, ">authenticate urlServer " + urlServer + " appId " + appId
            + " login " + login + " password "  + password + " deviceAdr " + deviceAdr);


        if (TextUtils.isEmpty(login)){
            mLog.e(LOG_TAG, ">authenticate invalid mLogin ");
            return false;
        }
        if (TextUtils.isEmpty(deviceAdr)){
            mLog.e(LOG_TAG, ">authenticate mDeviceAdr invalid mLogin ");
            return false;
        }
        mbAccountCreated = false;
        // connect to serveur
        connect(urlServer, appId);
        if (TextUtils.isEmpty(mToken)){
            mLog.e(LOG_TAG, ">authenticate invalid Token ");
            return false;
        }

        mUserName = null;
        mUserId = null;
        mLogin = login;
        mDeviceAdrInput = deviceAdr;
        call("searchUser", "{\"1\": \"" + mLogin + "\"}", BK_CALL);
        if (TextUtils.isEmpty(mResult)){
            mLog.e(LOG_TAG, ">authenticate invalid searchUser " + mResult);
            return false;
        }

        // check if senderAdr is different, if yes, update it.
        mLog.d(LOG_TAG, ">authenticate mbAccountCreated " + mbAccountCreated
            + " update senderAdr " + mDeviceAdr);
        setData("user", "{\"name\":\"" + mLogin + "\",  \"adress\":\"" + deviceAdr + "\"  }");
        if (TextUtils.isEmpty(mResult)){
            mLog.e(LOG_TAG, ">authenticate invalid account creation " + mResult);
            return false;
        }

        // login again to retrieve the userID
        call("searchUser", "{\"1\": \"" + mLogin + "\"}", BK_CALL);
        if (TextUtils.isEmpty(mResult)){
            mLog.e(LOG_TAG, ">authenticate invalid login userId " + mResult);
            return false;
        }

        // check response is ok
        if (TextUtils.isEmpty(mUserId)){
            mLog.e(LOG_TAG, ">authenticate invalid userId ");
            return false;
        }
        if (TextUtils.isEmpty(mDeviceAdr)){
            mLog.e(LOG_TAG, ">authenticate invalid deviceAdr ");
            return false;
        }
        if (TextUtils.isEmpty(mUserName)){
            mLog.e(LOG_TAG, ">authenticate invalid mUserName ");
            return false;
        }

        //if (mbAccountCreated){
//            mLog.d(LOG_TAG, ">authenticate mbAccountCreated " + mbAccountCreated
//                    + " update senderAdr " + mDeviceAdr);
//            setData("user", "{\"name\":\"" + mLogin + "\",  \"adress\":\"" + mDeviceAdr + "\"  }");
//            if (TextUtils.isEmpty(mResult)){
//                mLog.e(LOG_TAG, ">authenticate invalid account creation " + mResult);
//                return false;
//            }
//
//            // login again to rerieve the userID
//            call("searchUser", "{\"1\": \"" + mLogin + "\"}", BK_CALL);
//            if (TextUtils.isEmpty(mResult)){
//                mLog.e(LOG_TAG, ">authenticate invalid login userId " + mResult);
//                return false;
//            }
        //}

        mLog.d(LOG_TAG, "<authenticate  mUserId " + mUserId + " mUserName "  + mUserName + " deviceAdr " + mDeviceAdr);
        return true;
    }

    /**
     * connect the app with the backend
     * @return String the token
     */
    public boolean logout() {
        String appId = mDeviceDetails.getAppId();
        mLog.d(LOG_TAG, ">logout urlServer " + mUrlServer + " appId " + appId
                + " mUserId " + mUserId + " deviceAdr " + mDeviceAdr);
        return true;
    }

    /**
    * connect the app with the backend
    * @param urlServer
    * @param appId
    * @return String the token
    */
    private String connect(String urlServer, String appId)
    {
        mLog.d(LOG_TAG, ">connect urlServer " + urlServer + " appId " + appId);
        mResult = "";

        HttpClient client = new HttpClient(this,
                BK_CONNECT, new ArrayList<String>(), new ArrayList<String>());
        client.execute(urlServer + "connect?token=app:" + appId);
        mLog.d(LOG_TAG, "<connect");
        mUrlServer = urlServer;

        mToken = mResult;
        return mResult;
    }


    /**
     * set the data to the backend
     * @param data
     * @param params
     * @return String the result
     */
    private String setData(final String data, final String params)
    {
        mLog.d(LOG_TAG, ">setData data " + data + " params " + params);

        if (!checkParams(data, params)){
            mLog.e(LOG_TAG, ">setData checkParams failed ");
            return null;
        }
        mResult = "";

        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HttpClient client = new HttpClient(this,  BK_SETDATA, keys, values);
        client.execute(mUrlServer + "setdata?token=" +  mToken    );
        return mResult;
    }


    /*
    call to get data
    */
    private void call(String data, String params, int event)
    {
        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HttpClient client = new HttpClient(this,   event, keys, values);
        client.execute(mUrlServer + "call?token=" +  mToken);
    }


    /**
     * call for http request
     * @param result
     * @param event
     */
    @Override
    public void onRequestResult(String result, int event) {
        mLog.d(LOG_TAG, "onRequestResult result " + result + " event " + event);
        switch(event) {
            case BK_CONNECT :

                if(!TextUtils.isEmpty(result)) {
                    mResult = result;
                    mLog.d(LOG_TAG, "onRequestResult BK_CONNECT sucessfull");

                    mResult = result.replace("null", "");
                    mLog.d(LOG_TAG, "onRequestResult BK_CONNECT sucessfull token "
                        + mResult);

                }
                else {
                    mLog.e(LOG_TAG, "onRequestResult BK_CONNECT failed");
                }
                break;
            case BK_GETDATA:
                mResult = result;
                break;
            case BK_CALL :

                if(!TextUtils.isEmpty(result)) {
                    mResult = result;

                    try {
                        JSONObject js = new JSONObject(result);
                        JSONArray entities = new JSONArray(js.get("entities").toString());

                        if (entities.length() == 0) {
                            mLog.d(LOG_TAG, "onRequestResult BK_CALL create the account");
                            mbAccountCreated = true;
                        } else {
                            mbAccountCreated = false;
                            // iterator //TODO should be remove later when server will return only one entity for the user
                            mUserId = null;
                            mUserName = null;
                            mDeviceAdr = null;
                            int i = 0;
                            for (i = 0; i < entities.length(); i++) {
                                JSONObject user = entities.getJSONObject(i);
                                if (user != null && mDeviceAdrInput != null) {
                                    String userAdr = URLDecoder.decode(user.getString(USER_ADRESS));

                                    if (mDeviceAdrInput.equalsIgnoreCase(userAdr)) {
                                        // adr macth, this is the user
                                        mUserId = URLDecoder.decode(user.getString(USER_ID));
                                        mResult = mUserId;
                                        mUserName = URLDecoder.decode(user.getString(USER_NAME));
                                        mDeviceAdr = userAdr;
                                        break;
                                    }
                                }

                            }

                            mLog.d(LOG_TAG, "onRequestResult BK_CALL account already created " + mUserId);


                        }

                    } catch (Exception e) {
                        mLog.e(LOG_TAG, "onRequestResult Exception ", e);

                    }
                } else {
                    mLog.e(LOG_TAG, "onRequestResult failed empty result ");
                }

                break;
            case BK_SETDATA:
                mLog.d(LOG_TAG, "onRequestResult BK_SETDATA account creation sucessfull " + result);
                mResult = result;
                break;

        }
    }

    private boolean checkParams(final String data, final String params) {
        if (TextUtils.isEmpty(mUrlServer)){
            mLog.e(LOG_TAG, ">checkParams invalid server url ");
            return false;
        }
        if (TextUtils.isEmpty(mToken)){
            mLog.e(LOG_TAG, ">checkParams invalid mToken ");
            return false;
        }
        if (TextUtils.isEmpty(data)){
            mLog.e(LOG_TAG, ">checkParams invalid data ");
            return false;
        }
        if (TextUtils.isEmpty(params)){
            mLog.e(LOG_TAG, ">checkParams invalid params ");
            return false;
        }

        return true;
    }

    /**
     * The Class AuthResult.
     */
    public class AuthResult {

        /** The m success. */
        protected boolean mSuccess = false;

        /** The m success Response. */
        protected Response mSuccessResponse = null;

        /** The m unauthorized. */
        protected boolean mUnauthorized = false;

        /** The m failure result. */
        protected Throwable mFailureResult = null;

        /** The m errors. */
        protected Errors mErrors = null;

        /** The m mStatusCode. */
        protected int mStatusCode = 0;

        /**
         * On failure.
         * @param throwable the throwable
         */
        public void onFailure(final Throwable throwable) {
            mFailureResult = throwable;
            if (mFailureResult != null) {
                if (mFailureResult instanceof AuthenticationException) {
                    final AuthenticationException authenticationException = (AuthenticationException) mFailureResult;
                    mStatusCode = authenticationException.getHttpCode();
                    checkStatusCode();

                    mLog.d(LOG_TAG, "AuthResult, statusCode=" + mStatusCode);

                }
            }
        }

        private void checkStatusCode() {
            if (mStatusCode >= 400 && mStatusCode < 500) {
                // SDCANDTACT-2462: Modify AtpHelper to interpret all 4xx as unauthorized
                mUnauthorized = true;
            }

        }
        /**
         * On success.
         * @param response the response
         */
        public void onSuccess(final Response response) {
            mSuccessResponse = response;
            mSuccess = response != null;
        }

        /**
         * return StatusCode.
         * @return int, StatusCode
         */
        public int getStatusCode() {
            return mStatusCode;
        }

        /**
         * Checks if is success.
         * @return true, if is success
         */
        public boolean isSuccess() {
            return mSuccess;
        }

        /**
         * Gets the success Response.
         * @return the success result
         */
        public Response getSuccessResponse() {
            return mSuccessResponse;
        }

        /**
         * Checks if is unauthorized failure.
         * @return true, if is unauthorized failure
         */
        public boolean isUnauthorizedFailure() {
            return mUnauthorized;
        }

        /**
         * Gets the failure result.
         * @return the failure result
         */
        public Throwable getFailureResult() {
            return mFailureResult;
        }

        /**
         * Gets the errors.
         * @return the errors
         */
        public Errors getErrors() {
            return mErrors;
        }
    }
}

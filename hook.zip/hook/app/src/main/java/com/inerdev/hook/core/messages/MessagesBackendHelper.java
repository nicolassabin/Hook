/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inerdev.hook.core.messages;

import android.content.ContentValues;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.http.CallBackHttpRequest;
import com.inerdev.hook.core.http.HttpClient;
import com.inerdev.hook.provider.AppContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Nicolas Sabin
 */
public class MessagesBackendHelper implements CallBackHttpRequest{

    private static final String LOG_TAG = "MessagesBackendHelper";

    /*
    * BK_GETDATA
    */
    public static final int BK_GETDATA = 1;

    /*
    * BK_SETDATA
    */
    public static final int BK_SETDATA = 2;

    /*
    * SEARCH_MESSAGES
    */
    private static final String SEARCH_MESSAGES = "searchMessage";

    /*
        * REQUEST_MESSAGE
        */
    private static final String REQUEST_MESSAGE = "message";

    /*
    * RESPONSE_MESSAGE_ID
    */
    private static final String RESPONSE_MESSAGE_ID = "id";

    /*
    * RESPONSE_MESSAGE_DATE
    */
    private static final String RESPONSE_MESSAGE_DATE = "date";

    /*
    * RESPONSE_SENDER
    */
    private static final String RESPONSE_MESSAGE_SENDER = "sender";

    /*
    * RESPONSE_MESSAGE_TEXT
    */
    private static final String RESPONSE_MESSAGE_TEXT = "message";

    /*
    * PARAM_MSG_ALL
    */
    private static final String PARAM_MSG_ALL = "getAll";

    /**
    * the m Log
    */
    private Log mLog;

    /** The m mContext. */
    private Context mContext;

    /** The m mResult. */
    private String mResult;

    /** The m mEtag. */
    private String mEtag;

    /**
     * Instantiates a new AuthBackendHelper.
     * @param context the context
     */
    public MessagesBackendHelper(final Context context) {
        mContext = context;
    }

    /**
     * retrieve the messages from userId
     * @param userId
     * @param etag
     */
    public void getMessages(final String userId, final String etag)
    {
        mLog.d(LOG_TAG, ">getMessages userId " + userId + " Etag " + etag);

        if (!checkParams(userId)){
            mLog.e(LOG_TAG, ">getMessages invalid userId ");
            return;
        }

        call(SEARCH_MESSAGES, "{\"1\": \"" + userId + "\"}", BK_GETDATA);

    }

    /**
     * retrieve the messages from userId list
     * @param userIds
     * @param etag
     * @return Srring etag
     */
    public String getMessages(final List<String> userIds, final String etag)
    {
        mLog.d(LOG_TAG, ">getMessages userIds list and etag " + etag );

        if (userIds != null && userIds.size() > 0){

            mEtag = etag;
            for (String userId : userIds){
                if (!checkParams(userId)){
                    mLog.e(LOG_TAG, ">getMessages invalid deviceAdr ");
                    continue;
                }

                call(SEARCH_MESSAGES, "{\"1\": \"" + userId + "\"}", BK_GETDATA);
            }

            return mEtag;
        } else {
            mLog.i(LOG_TAG, ">getMessages userIds empty");
        }

        return null;
    }

    /**
     * retrieve the messages from userId
     * @param etag
     * @return Srring etag
     */
    public String getAllMessages(final String etag)
    {
        mLog.d(LOG_TAG, ">getAllMessages Etag " + etag);

        mEtag = etag;
        getData(REQUEST_MESSAGE, PARAM_MSG_ALL);
        return mEtag;

    }

    /**
     * remove the messages from serverId
     * @param serverId
     * @return boolean
     */
    public boolean removeMessage(final String serverId)
    {
        mLog.d(LOG_TAG, ">removeMessage serverId " + serverId);

        // TODO delete from server
        return true;

    }

    /**
     * post a message
     * @param msgText
     * @param msgSubject
     */
    public boolean postMessage(final String msgText, final String msgSubject)
    {
        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();
        String userId = hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getUserid();
        String senderName = hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccountName();
        mLog.d(LOG_TAG, ">postMessage userId: " + userId
            + " msgText: " + msgText + " msgSubject: " + msgSubject
            + " msgSender " + senderName);

        if (!checkParams(userId)){
            mLog.e(LOG_TAG, "<postMessage invalid deviceAdr ");
            return false;
        }

        setData(REQUEST_MESSAGE, "{\"userId\":\"" + userId + "\", \"message\":\""
                + msgText+ "\" , \"sender\":\"" + senderName + "\" }");

        if (TextUtils.isEmpty(mResult)){
            mLog.e(LOG_TAG, "<postMessage invalid result ");
            return false;
        }

        mLog.d(LOG_TAG, "<postMessage successfull " + mResult);
        return true;
    }


    /**
     * call to get data
     * @param data
     * @param params
     * @param event
     */
    private void call(String data, String params, int event)
    {
        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HttpClient client = new HttpClient(this,   event, keys, values);
        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();
        client.execute(hookApplication.getConfigHelper().getConfig().getServerUrl() + "call?token=" +
                hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken());

    }

    /**
     * get data
     * @param data
     * @param params
     */
    private String getData(String data, String params)
    {
        String message ="";

        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();
        HttpClient client = new HttpClient(this,  BK_GETDATA, keys, values);
        client.execute(hookApplication.getConfigHelper().getConfig().getServerUrl()
                + "getdata?token=" +  hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken()    );

        return message;
    }

    /**
     * set data
     * @param data
     * @param params
     */
    private void setData(String data, String params)
    {
        //Set The data and Params
        ArrayList<String> keys =  new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        keys.add("data");
        keys.add("params");

        values.add(data);
        values.add(params);

        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();
        HttpClient client = new HttpClient(this,  BK_SETDATA, keys, values);
        client.execute(hookApplication.getConfigHelper().getConfig().getServerUrl()
                + "setdata?token="
                +  hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken()    );
    }


    /**
     * call for http request
     * @param result
     * @param event
     */
    @Override
    public void onRequestResult(String result, int event) {
        mLog.d(LOG_TAG, "onRequestResult result " + result + " event " + event);
        switch(event) {
            case BK_GETDATA :
                mResult = result;
                mLog.d(LOG_TAG, "onRequestResult messages list " + mResult);
                if (!TextUtils.isEmpty(mResult)){
                    try {
                        JSONObject js = new JSONObject(result);
                        JSONArray entities = new JSONArray(js.get("entities").toString());

                        if (entities.length() > 0)
                        {
                            for (int i = 0; i < entities.length() ; i++) {

                                JSONObject message = entities.getJSONObject(i);
                                String msgId = URLDecoder.decode(message.getString(RESPONSE_MESSAGE_ID));
                                String msgSender = URLDecoder.decode(message.getString(RESPONSE_MESSAGE_SENDER));
                                String msgText = URLDecoder.decode(message.getString(RESPONSE_MESSAGE_TEXT));
                                String msgDate = String.valueOf(System.currentTimeMillis());//URLDecoder.decode(message.getString(RESPONSE_MESSAGE_DATE));
                                // compare etag
                                mEtag = msgDate;
                                // insert into Database?
                                // TODO subject to be changed later
                                storeInDatabase(msgId, msgSender, msgText, msgText);
                                mLog.d(LOG_TAG, "onRequestResult - BK_GETDATA message sender: "
                                        + msgSender + " msgId " + msgId + " text: " + msgText);
                            }

                        }
                    }catch (Exception e) {
                        mLog.e(LOG_TAG, "onRequestResult - BK_GETDATA Exception", e);
                    }
                } else {
                    mLog.e(LOG_TAG, "onRequestResult - messages list empty response");
                }

                break;
            case BK_SETDATA:
                mLog.d(LOG_TAG, "onRequestResult BK_SETDATA post message");
                mResult = result;
                break;

        }
    }

    private boolean checkParams(final String userId) {
        if (TextUtils.isEmpty(userId)){
            mLog.e(LOG_TAG, ">checkParams invalid userId ");
            return false;
        }
        HookApplication hookApplication = (HookApplication) mContext.getApplicationContext();

        if (hookApplication.getConfigHelper().getConfig() == null){
            mLog.e(LOG_TAG, ">checkParams invalid config ");
            return false;
        }
        if (TextUtils.isEmpty(hookApplication.getConfigHelper().getConfig().getServerUrl())){
            mLog.e(LOG_TAG, ">checkParams invalid ServerUrl ");
            return false;
        }
        if (hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo() == null){
            mLog.e(LOG_TAG, ">checkParams invalid AuthenticationInfo ");
            return false;
        }
        if (TextUtils.isEmpty(hookApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccessToken())){
            mLog.e(LOG_TAG, ">checkParams invalid accessToken ");
            return false;
        }

        return true;
    }

    private void storeInDatabase(final String msgId, final String userId, final String msgText, final String msgSubject){
        AppContract.Messages message = new AppContract.Messages(((HookApplication)mContext.getApplicationContext()).getAppContract());

        ContentValues contentValues = new ContentValues();
        long lTime = System.currentTimeMillis();
        contentValues.put(AppContract.Messages.COLUMN_DATE_CREATION, lTime);
        int iDays = 2;

        //contentValues.put(AppContract.Messages.COLUMN_DATE_EXPIRATION, lTime
        //        + iDays*24*60*60*1000);
        contentValues.put(AppContract.Messages.COLUMN_NAME_VERSION, "1.0");
        contentValues.put(AppContract.Messages.COLUMN_SUBJECT, msgSubject);
        contentValues.put(AppContract.Messages.COLUMN_TEXT, msgText);
        contentValues.put(AppContract.Messages.COLUMN_SERVER_ID, msgId);

        //contentValues.put(AppContract.Messages.COLUMN_ITEM_CATEGORY_TYPE, (String)mCategorySpinner.getSelectedItem());
        contentValues.put(AppContract.Messages.COLUMN_SENDER_NAME,
                userId);
        contentValues.put(AppContract.Messages.COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME,
                userId);

        mLog.d(LOG_TAG, "storeInDatabase userId " + userId);


        contentValues.put(AppContract.Messages.COLUMN_ITEM_TYPE, AppContract.Messages.MSG_RECEIVED);
        contentValues.put(AppContract.Messages.COLUMN_STATUS, AppContract.Messages.STATUS_COMPLETE);

        // sent the message to the server

        //request is succesfull then , save in database

        if (mContext.getContentResolver().insert(message.getContentUri(),
                contentValues) == null){
            mLog.e(LOG_TAG, "storeInDatabase insert failed");

        }
    }
}

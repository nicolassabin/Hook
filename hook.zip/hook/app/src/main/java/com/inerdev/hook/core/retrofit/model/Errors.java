/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;


import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */

public class Errors

{
    /** This contains the message.*/
    @SerializedName("errors")
    private List<Error> mErrors = new ArrayList<Error>();

    /**
     * return the errors list
     * @return ArrayList<Error>
     */
    public List<Error> getErrors()
    {

        return mErrors;
    }

}

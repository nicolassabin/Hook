/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

/**
 * The listener interface for receiving swipePage events. The class that is interested in processing a swipePage event
 * implements this interface, and the object created with that class is registered with a component using the
 * component's <code>addSwipePageListener<code> method. When
 * the swipePage event occurs, that object's appropriate
 * method is invoked.
 */
public interface SwipePageListener {

    /**
     * On page scrolled.
     * @param position the position
     * @param positionOffset the position offset
     * @param positionOffsetPixels the position offset pixels
     */
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels);

    /**
     * On page selected.
     * @param position the position
     */
    public void onPageSelected(int position);

    /**
     * On page scroll state changed.
     * @param state the state
     */
    public void onPageScrollStateChanged(int state);
}

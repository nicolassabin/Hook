
package com.inerdev.hook.core.auth;

import java.util.Date;

/**
 * The Class AuthenticationInfoImpl.
 */
public class AuthenticationInfo {

    /**
     * The Constant TAG.
     */
    protected static final String TAG = "AuthenticationInfo";

    /** The m UserId. */
    private String mUserId;

    /** The m AccountName. */
    private String mAccountName;

    /**
     * The m access token.
     */
    private String mAccessToken;

    /** The m refresh token. */
    private String mRefreshToken;

    /** The m mDeviceAdr. */
    private String mDeviceAdr;

    /**
     * The m access token expiration date.
     */
    private Date mAccessTokenExpirationDate;

    /**
     * Instantiates a new authentication info impl.
     * @param userid the userid
     * @param accessToken the access token
     * @param refreshToken the refresh token
     * @param accountName the accountName
     * @param accessTokenExpirationDate the accessTokenExpirationDate
     * @param deviceAdr the deviceAdr
     */
    public AuthenticationInfo(final String userid, final String accessToken, final String refreshToken, final String accountName,
                              final Date accessTokenExpirationDate, final String deviceAdr) {
        mAccessToken = accessToken;
        mAccessTokenExpirationDate = accessTokenExpirationDate;
        mRefreshToken = refreshToken;
        mUserId = userid;
        mAccountName = accountName;
        mDeviceAdr = deviceAdr;
    }

    /**
     * set the info a new authentication info impl.
     * @param userid the userid
     * @param accessToken the access token
     * @param refreshToken the refresh token
     * @param accessTokenExpirationDate the accessTokenExpirationDate
     * @param accountName the accountName
     * @param accessTokenExpirationDate the accessTokenExpirationDate
     * @param deviceAdr the deviceAdr
     */
    public void setInfo(final String userid, final String accessToken, final String refreshToken,
                        final String accountName, final Date accessTokenExpirationDate, final String deviceAdr) {
        mUserId = userid;
        mAccountName = accountName;
        mAccessToken = accessToken;
        mRefreshToken = refreshToken;
        mAccessTokenExpirationDate = accessTokenExpirationDate;
        mDeviceAdr = deviceAdr;

    }

    /**
     * Returns the Refresh token (a.k.a. NWB/SLT)
     * @return The Refresh token
     */
    public String getRefreshToken() {
        return mRefreshToken;
    }

    /**
     * Returns the Access Token
     * @return The Access Token
     */
    public String getAccessToken() {
        return mAccessToken;
    }

    /**
     * Returns the user id (a.k.a. DV user ID)
     * @return The user id
     */
    public String getUserid() {
        return mUserId;
    }

    /**
     * Returns the user id (a.k.a. DV user ID)
     * @return The user id
     */
    public String getAccountName() {
        return mAccountName;
    }

    /**
     * Returns the AccessTokenExpirationDate
     * @return The AccessTokenExpirationDate
     */
    public Date getAccessTokenExpirationDate() {
        return mAccessTokenExpirationDate;
    }

    /**
     * Returns the DeviceAdr
     * @return The DeviceAdr
     */
    public String getDeviceAdr() {
        return mDeviceAdr;
    }


}

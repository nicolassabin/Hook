package com.inerdev.hook.core.http;

/**
 * Created by jerome on 30/05/2017.
 */
public interface CallBackHttpRequest {

    /**
     * call for http request
     * @param result
     * @param event
     */
    public void onRequestResult(String result, int event);
}

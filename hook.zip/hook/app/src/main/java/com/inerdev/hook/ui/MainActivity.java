package com.inerdev.hook.ui;

import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationException;
import com.inerdev.hook.ui.devices.DevicesFragment;
import com.inerdev.hook.ui.messages.IncommingMsgBoxFragment;
import com.inerdev.hook.ui.messages.MyMsgPostFragment;
import com.inerdev.hook.ui.utils.PermissionManager;


public class MainActivity extends HookAppCompatActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks, ActivityCompat.OnRequestPermissionsResultCallback {

    /** The intent action wizard get started. */
    private static final String INTENT_ACTION_WIZARD_GET_STARTED = ".intent.action.WIZARD_GET_STARTED";

    /** The ARG_SECTION_NUMBER */
    public static final String ARG_SECTION_NUMBER = "section_number";

    private static final String TAG = "MainActivity";

    public interface IActionFragment
    {
        boolean onKeyBackDown();
        void onPrepareOptionsMenu(Menu menu);
        boolean onOptionsItemSelected(MenuItem item);
    }

    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;

    /**
     * the m PermissionManager
     */
    private PermissionManager mPermissionManager = new PermissionManager();


    /**
     * Used to store the last screen title. For use in {@link #restoreActionBar()}.
     */
    private CharSequence mTitle;
    private IActionFragment mCurrentAction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mTitle = getTitle();

        // Set up the drawer.
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));

        ((HookApplication)getApplication()).getMessagesJobScheduler().startScheduler();
        incommingBox();
    }


    private void incommingBox() {
        Fragment    fragment;
        String      tag = null;


        mTitle = getString(R.string.title_section1);
        tag             = "IncommingBoxFragment";
        fragment        = new IncommingMsgBoxFragment();
        mCurrentAction  = (IActionFragment)fragment;

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, fragment, tag)
                .commit();
        restoreActionBar();

    }

    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments

        Fragment fragment = null;
        String      tag = null;

        if(position == 0) {
            mTitle = getString(R.string.title_section1);
            tag             = "IncommingBoxFragment";
            fragment        = new IncommingMsgBoxFragment();
        } else if(position == 1) {
            mTitle = getString(R.string.title_section2);
            tag             = "myposts";
            fragment        = new MyMsgPostFragment();
        } else if(position == 2) {
            mTitle = getString(R.string.title_section3);
            tag             = "devices";
            fragment        = new DevicesFragment();
        }
        mCurrentAction  = (IActionFragment)fragment;

        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.container, fragment, tag)
                .commit();
    }

    public void onSectionAttached(int number) {
        switch (number) {
            case 1:
                mTitle = getString(R.string.title_section1);
                break;
            case 2:
                mTitle = getString(R.string.title_section2);
                break;
            case 3:
                mTitle = getString(R.string.title_section3);
                break;
        }
        restoreActionBar();
    }

    public void setTitleEx(String title) {
        mTitle = title;
        restoreActionBar();
    }

    public void restoreActionBar() {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_STANDARD);
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.setTitle(mTitle);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if ( !mNavigationDrawerFragment.isDrawerOpen() && mCurrentAction != null) {
            // Only show items in the action bar relevant to this screen
            // if the drawer is not showing. Otherwise, let the drawer
            // decide what to show in the action bar.
            if (mCurrentAction instanceof MyMsgPostFragment){
                getMenuInflater().inflate(R.menu.menu_main_mypost, menu);
            } else if (mCurrentAction instanceof DevicesFragment){
                getMenuInflater().inflate(R.menu.menu_main_devices, menu);
            } else {
                getMenuInflater().inflate(R.menu.menu_main, menu);
            }
            restoreActionBar();
            return true;
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu)
    {
        mCurrentAction.onPrepareOptionsMenu(menu);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        Fragment fragment;
        String      tag = null;

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_logout) {

            final ProgressDialog progressDialog = showProgressDialog("", getString(R.string.logout_wait), true);
            progressDialog.show();

            AsyncTask<String, Void, Integer> asyncTask = new AsyncTask<String, Void, Integer>()
            {

                @Override
                protected Integer doInBackground(String... params) {
                    try {
                        mHookApplication.getAuthenticationManagerHelper().logout();
                    } catch (AuthenticationException e) {
                        mLog.e(TAG, "logout AuthenticationException", e);
                    }
                    return 0;
                }

                @Override
                protected void onPostExecute(Integer result) {
                    progressDialog.dismiss();
                    finish();
                }
            };
            asyncTask.execute();

        }
        else
        {
            mCurrentAction.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }


    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */


        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }

        @Override
        public void onAttach(Activity activity) {
            super.onAttach(activity);
            ((MainActivity) activity).onSectionAttached(
                    getArguments().getInt(ARG_SECTION_NUMBER));
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if(keyCode == KeyEvent.KEYCODE_BACK)
        {
            if(mCurrentAction != null)
            {
                if(mCurrentAction.onKeyBackDown())
                {
                    return true;
                }
            }
        }
        finish();
        return super.onKeyDown(keyCode, event);
    }

    private ProgressDialog showProgressDialog(String title, String message, boolean indeterminate) {
        return ProgressDialog.show(this, title, message, indeterminate);
    }

}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.ui.Constants;
import com.inerdev.hook.ui.utils.MySharePreferences;
import com.inerdev.hook.ui.utils.WifiBtStatusProvider;


/**
 * The Class SplashLogoActivity.
 */
public class SplashLogoActivity extends AppCompatActivity {

    /** The display length long. */
    private final int DISPLAY_LENGTH_LONG = 1500;

    /** The display length short. */
    private final int DISPLAY_LENGTH_SHORT = 500;

    /** The m display length. */
    private int mDisplayLength;

    /** The run activity. */
    private Runnable runActivity;

    /** The m orientation. */
    private static int mOrientation = -1;

    /** The was run. */
    private static boolean wasRun = false;

    /** The m handler. */
    private final Handler mHandler = new Handler();

    /** The Constant LOG_TAG. */
    private static final String LOG_TAG = SplashLogoActivity.class.getSimpleName();

    /** The m user login. */
    private boolean mUserLogin = false;

    View splashParent;

    /** The m MySharePreferences. */
    MySharePreferences mMySharePreferences;

    /** The m start touch time for the cheat code. */
    private long mStartTouchTime = 0;

    /** The m log. */
    private Log mLog;

    /** The m AuthenticationManager. */
    private AuthenticationManager mAuthenticationManagerHelper;

    /** The m WifiBtStatusProvider. */
    private WifiBtStatusProvider mWifiBtStatusProvider;

    /**
     *
     */
    @SuppressLint("MissingSuperCall")
    @Override
    public void onCreate(final Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        mLog.d(LOG_TAG, "onCreate()");

        mAuthenticationManagerHelper = ((HookApplication)getApplication()).getAuthenticationManagerHelper();
        mWifiBtStatusProvider = ((HookApplication)getApplication()).getWifiBtStatusProvider();
        mMySharePreferences = ((HookApplication)getApplication()).getMySharePreferences();
        checkingInstallSharePreference();

        // Need to set force in case if app crashed
        cancelOldNotifications();

        setContentView(R.layout.splashscreen_connecting);
        // if previously loaded don't load animation
        if (!wasRun) {
            mDisplayLength = DISPLAY_LENGTH_LONG;
            allocateResources();
        } else {
            mDisplayLength = DISPLAY_LENGTH_SHORT;
        }

        mUserLogin = mAuthenticationManagerHelper.isAuthenticated();

        mLog.d(LOG_TAG, "Saved getInstance state userLogin: " + mUserLogin);
        if (mOrientation == -1)
            mOrientation = getResources().getConfiguration().orientation;

        startConnecting(mDisplayLength);

    }


    // Starts the connecting activity
    // Needed to extract this into a method, since it needs to
    // be called also when we receive a new intent from the SSO observer

    /**
     * Start connecting.
     * @param displayLength the display length
     */
    private void startConnecting(final int displayLength) {

        if (mUserLogin) {
            runActivity = getUserLoginRunnable();
            mHandler.postDelayed(runActivity, displayLength);
        } else {
            runActivity = getUserLogoutRunnable();

            mHandler.removeCallbacks(runActivity); /* make sure that run Activity hasn't been already dispatched */
            mHandler.postDelayed(runActivity, displayLength);
            mLog.d(LOG_TAG, "Posted delayed Connecting activity");
        }
    }

    @NonNull
    private Runnable getUserLogoutRunnable() {
        return new Runnable() {

            @Override
            public void run() {
                mLog.d(LOG_TAG, "startConnecting().runActivity.run(): ");
                // OACJ-55 fix was moved here (because it broke OACJ-202)
                // check if we have any data/wifi connection
                if (!mWifiBtStatusProvider.checkDataConnectionEstablished()) {
                    mLog.d(LOG_TAG, "Ignoring warning activity, finish activity checkDataConnectionEstablished");
                    Toast.makeText(SplashLogoActivity.this, getString(R.string.error_close_due_no_connection), Toast.LENGTH_SHORT).show();
                    SplashLogoActivity.this.finish();
                } else {
                    final Intent mainIntent = new Intent(SplashLogoActivity.this, SplashConnectingActivity.class);
                    // let's indicate to the connecting activity whether we've been started by the
                    // SSO observer, so it can pass this information back SingleSignOn when it tries
                    // to login via SSO
                    final String action = mainIntent.getAction();
                    mainIntent.putExtra(Constants.USER_LOGIN_ALREADY, mUserLogin);
                    mainIntent.setAction(Intent.ACTION_MAIN);
                    SplashLogoActivity.this.startActivity(mainIntent);
                    // Because the SplashConnectingActivity has the same screen layout
                    // we do not want a transition effect SDCANDTACT-316
                    overridePendingTransition(0, 0);
                    SplashLogoActivity.this.finish();
                    mLog.d(LOG_TAG, "Connecting activity set to start");
                }
            }
        };
    }

    @NonNull
    private Runnable getUserLoginRunnable() {
        return new Runnable() {

            @Override
            public void run() {
                final Intent mainIntent = new Intent(SplashLogoActivity.this, SplashConnectingActivity.class);

                // let's indicate to the connecting activity whether we've been started by the
                // SSO observer, so it can pass this information back SingleSignOn when it tries
                // to login via SSO
                mainIntent.putExtra(Constants.USER_LOGIN_ALREADY, mUserLogin);
                mainIntent.setAction(Intent.ACTION_MAIN);
                startActivity(mainIntent);
                finish();
            }
        };
    }

    /**
     * On search requested.
     * @return true, if successful
     */
    @Override
    public boolean onSearchRequested() {
        // ignore search button
        return false;
    }

    /**
     *
     */
    @Override
    public void onConfigurationChanged(final Configuration newConfig) {
        mLog.d(LOG_TAG, "onConfigurationChanged()");
        if (mOrientation == Configuration.ORIENTATION_PORTRAIT) {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
        super.onConfigurationChanged(newConfig);
    }

    /* Handles close of activity. */

    /**
     *
     */
    @Override
    public void onDestroy() {
        mLog.d(LOG_TAG, "onDestroy");
        super.onDestroy();
    }

    /**
     * Allocate resources.
     */
    private void allocateResources() {
        /**
         * This is an empty method.
         */
    }



    /**
     * Checking install share preference.
     */
    private void checkingInstallSharePreference() {
        final SharedPreferences sharedPreferences = mMySharePreferences.getSharedPreferences();
        final boolean isInstall = sharedPreferences.getBoolean(Constants.FIRST_TIME_INSTALL, false);
        if (!isInstall) {

            saveInstallVariable();
        }
    }

    /**
     * Save install variable.
     */
    private void saveInstallVariable() {
        mMySharePreferences.saveBooleanPreference(Constants.FIRST_TIME_INSTALL, true);
    }


    public void uninstallSuccess() {
        if (splashParent != null) {
            splashParent.setVisibility(View.VISIBLE);
        }
        startConnecting(mDisplayLength);
    }


    private void cancelOldNotifications(){

    }


}

package com.inerdev.hook.core.devices;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.provider.AppContract;

import java.util.Iterator;
import java.util.List;

/**
 * Created by nsab0001 on 01/06/2017.
 */

public class DevicesWifiManager extends BDevicesManager {

    private static final String LOG_TAG = "DevicesWifiManager";

    /** The m WifiManager. */
    private WifiManager mWifiManager;


    public DevicesWifiManager(Context context){
        super(context);
        mWifiManager = (WifiManager) mContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!mWifiManager.isWifiEnabled()){
            mWifiManager.setWifiEnabled(true);
        }

    }


    /**
     * start Scanning.
     *
     */
    public void startScanning(ScanCallBackOperation scanCallBackOperation){
        mLog.d(LOG_TAG, "startScanning");
        IntentFilter i = new IntentFilter();
        i.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        mContext.registerReceiver(this, i);
        mScanCallBackOperation = scanCallBackOperation;

        mWifiManager.startScan();

    }

    /**
     * close.
     *
     */
    public void close(){
        mLog.d(LOG_TAG, "close");
        stopScanning();
        super.close();
    }

    /**
     * stop Scanning.
     *
     */
    public void stopScanning(){
        mLog.d(LOG_TAG, "stopScanning");
        mListDevicesAddress.clear();
        mScanCallBackOperation = null;
        mContext.unregisterReceiver(this);
    }

    private void checkAndAddWifiDevice(ScanResult scanResult) {
        if (scanResult != null){
            if (!mListDevicesAddress.containsKey(scanResult.BSSID)){
                addWifiDevice(scanResult);
            } else if ((mListDevicesAddress.get(scanResult.BSSID).getStatus() != AppContract.Devices.DEVICE_DELETED)
                    && (mListDevicesAddress.get(scanResult.BSSID).getStatus() != AppContract.Devices.DEVICE_ACCEPTED)){
                addWifiDevice(scanResult);
            }
        }
    }

    private void addWifiDevice(ScanResult scanResult) {
        if (scanResult != null){

            // check if the device is registered on the platform,
            // if yes, it is auto-accepted
            // TODO later A notification will be send to the user to  accept or not the device
            String deviceUserId = getDeviceUserId(scanResult.BSSID);

            mLog.d(LOG_TAG, "MSG_ADD_DEVICE_INFO device userID " +deviceUserId
                    + " for this adr:" + scanResult.BSSID);

            DeviceInfo deviceInfo = new DeviceInfo(scanResult.BSSID, scanResult.BSSID,
                    scanResult.SSID, scanResult.SSID,
                    deviceUserId);
            // TODO will be accepted after user confirmation
            // check later if device should be added or not into database
            if (TextUtils.isEmpty(deviceUserId)) {
                deviceInfo.setStatus(AppContract.Devices.DEVICE_ACCEPTED);
            } else {
                deviceInfo.setStatus(AppContract.Devices.DEVICE_PENDING);
            }
            mLog.d(LOG_TAG, "addWifiDevice deviceInfo " + deviceInfo.toString());
            mListDevicesAddress.put( scanResult.BSSID, deviceInfo);
            if (mScanCallBackOperation != null){
                mScanCallBackOperation.onScanResult(deviceInfo);
            }
        }
    }

    /**
     * This method is called when the BroadcastReceiver is receiving an Intent
     * broadcast.  During this time you can use the other methods on
     * BroadcastReceiver to view/modify the current result values.  This method
     * is always called within the main thread of its process, unless you
     * explicitly asked for it to be scheduled on a different thread using
     * thread you should
     * never perform long-running operations in it (there is a timeout of
     * 10 seconds that the system allows before considering the receiver to
     * be blocked and a candidate to be killed). You cannot launch a popup dialog
     * in your implementation of onReceive().
     * <p>
     * <p><b>If this BroadcastReceiver was launched through a &lt;receiver&gt; tag,
     * then the object is no longer alive after returning from this
     * function.</b>  This means you should not perform any operations that
     * return a result to you asynchronously -- in particular, for interacting
     * with services, you should use
     * {@link Context#startService(Intent)} instead of
     * to interact with a service that is already running, you can use
     * {@link #peekService}.
     * <p>
     * <p>The Intent filters used in {@link Context#registerReceiver}
     * and in application manifests are <em>not</em> guaranteed to be exclusive. They
     * are hints to the operating system about how to find suitable recipients. It is
     * possible for senders to force delivery to specific recipients, bypassing filter
     * resolution.  For this reason, {@link #onReceive(Context, Intent) onReceive()}
     * implementations should respond only to known actions, ignoring any unexpected
     * Intents that they may receive.
     *
     * @param context The Context in which the receiver is running.
     * @param intent  The Intent being received.
     */
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onReceive(Context context, Intent intent) {
        final List<ScanResult> wirelessNetworkList =  mWifiManager.getScanResults(); // Returns a <list> of scanResults
        if (wirelessNetworkList != null
                && !wirelessNetworkList.isEmpty()){

            Thread thread = new Thread(new Runnable(){
                public void run() {
                    Iterator<ScanResult> iterator = wirelessNetworkList.iterator();
                    while(iterator.hasNext())
                    {
                        ScanResult scanResult = iterator.next();
                        mLog.d(LOG_TAG, "onReceive scanResult  " + scanResult.toString());

                        checkAndAddWifiDevice(scanResult);

                    }
                }
            });
            thread.start();

        } else {
            mLog.i(LOG_TAG, "onReceive empty result");
        }

        if (mScanCallBackOperation != null){
            mScanCallBackOperation.onEnd();
        }
    }
}

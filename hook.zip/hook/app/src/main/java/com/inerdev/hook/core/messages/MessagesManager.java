
package com.inerdev.hook.core.messages;


/**
 * The Interface MessagesManager.
 */
public interface MessagesManager {

    // Devices scanning Intent
    /** The intent action INTENT_ACTION_MESSAGES_SCANNING_STARTED. */
    public static final String INTENT_ACTION_MESSAGES_SCANNING_STARTED = "com.inerdev.action.INTENT_ACTION_MESSAGES_SCANNING_STARTED";

    /** The intent action INTENT_ACTION_MESSAGES_SCANNING_PROGRESS. */
    public static final String INTENT_ACTION_MESSAGES_SCANNING_PROGRESS = "com.inerdev.action.INTENT_ACTION_MESSAGES_SCANNING_PROGRESS";

    /** The intent action INTENT_ACTION_MESSAGES_SCANNING_SUCCEED. */
    public static final String INTENT_ACTION_MESSAGES_SCANNING_SUCCEED = "com.inerdev.action.INTENT_ACTION_MESSAGES_SCANNING_SUCCEED";

    /** The intent action INTENT_ACTION_MESSAGES_SCANNING_FAILED. */
    public static final String INTENT_ACTION_MESSAGES_SCANNING_FAILED = "com.inerdev.action.INTENT_ACTION_MESSAGES_SCANNING_FAILED";

    /** The intent action INTENT_MESSAGES_SCANNING_ERROR. */
    public static final String INTENT_MESSAGES_SCANNING_ERROR = "INTENT_MESSAGES_SCANNING_ERROR";

    /** The intent action INTENT_MESSAGES_SCANNING_USER_MESSAGES. */
    public static final String INTENT_MESSAGES_SCANNING_USER_MESSAGES = "INTENT_MESSAGES_SCANNING_USER_MESSAGES";


    /**
     * start Scanning.
     *
     */
    public void startScanning();

    /**
     * stop Scanning.
     *
     */
    public void stopScanning();

    /**
     * clear cache
     */
    public void clearCache();

    /**
     * Adds the on vault synced listener.
     * @param listener the listener
     */
    public void addListener(final MessagesCallBackOperation listener);

    /**
     * Removes the listener.
     * @param listener the listener
     */
    public void removeListener(final MessagesCallBackOperation listener);

    /**
     * close
     */
    public void close();

}

package com.inerdev.hook.core.config;


/**
 * Interface for retrieving configuration values.
 */
public interface ConfigInfo {

    /**
     * getServerUrl
     * @return String
     */
    String getServerUrl();

    /**
     * getAuthUrl
     * @return String
     */
    String getAuthUrl();

}


package com.inerdev.hook.core.devices;


import java.util.List;

/**
 * The Interface DevicesManager.
 */
public interface DevicesManager {

    // Devices scanning Intent
    /** The intent action INTENT_ACTION_DEVICES_SCANNING_STARTED. */
    public static final String INTENT_ACTION_DEVICES_SCANNING_STARTED = "com.inerdev.action.INTENT_ACTION_DEVICES_SCANNING_STARTED";

    /** The intent action INTENT_ACTION_DEVICES_SCANNING_PROGRESS. */
    public static final String INTENT_ACTION_DEVICES_SCANNING_PROGRESS = "com.inerdev.action.INTENT_ACTION_DEVICES_SCANNING_PROGRESS";

    /** The intent action INTENT_ACTION_DEVICES_SCANNING_SUCCEED. */
    public static final String INTENT_ACTION_DEVICES_SCANNING_SUCCEED = "com.inerdev.action.INTENT_ACTION_DEVICES_SCANNING_SUCCEED";

    /** The intent action INTENT_ACTION_DEVICES_SCANNING_FAILED. */
    public static final String INTENT_ACTION_DEVICES_SCANNING_FAILED = "com.inerdev.action.INTENT_ACTION_DEVICES_SCANNING_FAILED";

    /** The intent action INTENT_DEVICES_SCANNING_DEVICE_INFO. */
    public static final String INTENT_DEVICES_SCANNING_DEVICE_INFO = "INTENT_DEVICES_SCANNING_DEVICE_INFO";

    /** The intent action INTENT_DEVICES_SCANNING_ERROR. */
    public static final String INTENT_DEVICES_SCANNING_ERROR = "INTENT_DEVICES_SCANNING_ERROR";

    /** The TYPE_SCANNING_BT_ONLY */
    public static final int		    TYPE_SCANNING_BT							    = 1;
    /** The TYPE_SCANNING_WIFI */
    public static final int		    TYPE_SCANNING_WIFI							    = 2;
    /** The TYPE_SCANNING_BT_WIFI */
    public static final int		    TYPE_SCANNING_BT_WIFI							= 3;
    /** The TYPE_SCANNING_ALL */
    public static final int		    TYPE_SCANNING_ALL							    = 4;


    /**
     * update status of the devices.
     * @param callBackOperation
     *
     */
    public void updateStatus(DevicesCallBackOperation callBackOperation);

    /**
     * start Scanning.
     * @param typeScanning (refer to TYPE_SCANNING_BT....)
     * @param timeout (rmax is 300 for BT, NA for Wifi)
     *
     */
    public void startScanning(int typeScanning, int timeout);

    /**
     * stop Scanning.
     *
     */
    public void stopScanning();

    /**
     * clear cache
     * @param  idDevices
     */
    public void clearCache(String idDevices);

    /**
     * Adds the on vault synced listener.
     * @param listener the listener
     */
    public void addListener(final DevicesCallBackOperation listener);

    /**
     * Removes the listener.
     * @param listener the listener
     */
    public void removeListener(final DevicesCallBackOperation listener);

    /**
     * close
     */
    public void close();

}
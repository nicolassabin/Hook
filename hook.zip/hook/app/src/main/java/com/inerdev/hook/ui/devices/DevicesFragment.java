package com.inerdev.hook.ui.devices;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.core.auth.AuthenticationManagerHelper;
import com.inerdev.hook.core.devices.DeviceInfo;
import com.inerdev.hook.core.devices.DevicesBluetoothManager;
import com.inerdev.hook.core.devices.DevicesCallBackOperation;
import com.inerdev.hook.core.devices.DevicesManager;
import com.inerdev.hook.provider.AppContract;
import com.inerdev.hook.ui.AbstractFragment;
import com.inerdev.hook.ui.MainActivity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_ACCEPTED;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_DELETED;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_DELETING;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_PENDING;


public class DevicesFragment extends AbstractFragment implements MainActivity.IActionFragment, AbstractFragment.ActionMenu,
        DevicesCallBackOperation {

    private static final String TAG = "DevicesFragment - ";

    private DevicesManager mDevicesManager;
    private AuthenticationManager mAuthenticationManager;
    protected AsyncTask<Void, Void, Void> mAsyncTask = null;
    protected Cursor mCursor = null;
    protected AppContract.Devices mDevices;
    protected DevicesCursorAdapter mAdapter = null;
    protected boolean mSelectionEnable = false;
    protected TextView mSectionLabel;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        mId = 3;
        mActionMenu = this;
        super.onCreate(savedInstanceState);
        mDevicesManager = ((HookApplication)getActivity().getApplication()).getDevicesManager();
        mAuthenticationManager = ((HookApplication)getActivity().getApplication()).getAuthenticationManagerHelper();
        mDevices = new AppContract.Devices(((HookApplication)getActivity().getApplication()).getAppContract());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        mSectionLabel = (TextView)rootView.findViewById(R.id.section_label);
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                mSelectionEnable = true;
                refreshData();
                return false;
            }
        });
        mDevicesManager.addListener(this);
        refresh();
        return rootView;
    }

    /**
     * Called when the Fragment is visible to the user.  This is generally
     * tied to {@link Activity#onStart() Activity.onStart} of the containing
     * Activity's lifecycle.
     */
    @Override
    public void onStart() {
        super.onStart();
        if (mAuthenticationManager.getAuthenticationInfo() != null){
            String tmp = getString(R.string.my_device_adr) + mAuthenticationManager.getAuthenticationInfo().getDeviceAdr();
            mSectionLabel.setText(tmp);
            mSectionLabel.setVisibility(View.VISIBLE);
        } else {
            mSectionLabel.setVisibility(View.GONE);
        }
        refreshData();
    }

    @Override
    public void onDetach() {
        mDevicesManager.stopScanning();
        mDevicesManager.removeListener(this);
        super.onDetach();
    }

    @Override
    public void onItemClick(int position, long id) {

    }

    @Override
    public void delete() {
        mLog.d(TAG, "delete selection");
        if (!mAdapter.mSelectedItemId.isEmpty()){
            Iterator<String> iterator = mAdapter.mSelectedItemId.iterator();
            ContentValues contentValues = new ContentValues();
            contentValues.put(AppContract.Devices.COLUMN_STATUS, DEVICE_DELETED);
            while(iterator.hasNext())
            {
                String id = iterator.next();
                mLog.d(TAG, "delete deleting id " + id);

                mDevicesManager.clearCache(id);
                if (getContext().getContentResolver().update(mDevices.getContentUri(),
                        contentValues, AppContract.Devices.COLUMN_ADDRESS + "=?",
                        new String[]{String.valueOf(id)}) == 0){
                    mLog.e(TAG, "delete failed id " + id);
                }
            }

        } else {
            mLog.d(TAG, "delete no selection");
        }

    }

    @Override
    public void deleteAll() {
        mLog.d(TAG, "deleteAll");
        mDevicesManager.clearCache(null);
        getContext().getContentResolver().delete(mDevices.getContentUri(),
                null, null);
    }

    @Override
    public void refresh() {
        mLog.d(TAG, "refresh");
        mDevicesManager.startScanning(DevicesManager.TYPE_SCANNING_ALL, DevicesBluetoothManager.DEFAULT_TIMEOUT);
        mDevicesManager.updateStatus(this);
    }

    @Override
    public boolean onKeyBackDown() {
        if (mSelectionEnable)
        {
            mSelectionEnable = false;
            refreshData();
            return true;
        }
        return false;
    }

    @Override
    public void refreshData() {
        mLog.d(TAG, "refreshData");
        if (mAsyncTask == null || mAsyncTask.getStatus() == AsyncTask.Status.FINISHED){
            mAsyncTask = new AsyncTask<Void, Void, Void>() {
                final ProgressDialog uploadProgressDialog = new ProgressDialog(getActivity());

                @Override
                protected void onPreExecute() {
                    // display details of the current the groupspace
                    mLog.d(TAG, "refreshData onPreExecute");
                    uploadProgressDialog.setIndeterminate(true);
                    uploadProgressDialog.setMessage(getString(R.string.refreshing));
                    uploadProgressDialog.setCancelable(false);
                    uploadProgressDialog.show();

                }

                /**
                 * Override this method to perform a computation on a background thread. The
                 * specified parameters are the parameters passed to {@link #execute}
                 * by the caller of this task.
                 * <p>
                 * This method can call {@link #publishProgress} to publish updates
                 * on the UI thread.
                 *
                 * @param params The parameters of the task.
                 * @return A result, defined by the subclass of this task.
                 * @see #onPreExecute()
                 * @see #onPostExecute
                 * @see #publishProgress
                 */
                @Override
                protected Void doInBackground(Void... params) {
                    mLog.d(TAG, "refreshData doInBackground ");
                    mCursor = getActivity().getContentResolver().query(mDevices.getContentUri(),
                            //null, AppContract.Devices.COLUMN_STATUS + "=?", new String[]{String.valueOf(DEVICE_ACCEPTED)},
                            null, AppContract.Devices.COLUMN_STATUS + "=? OR " + AppContract.Devices.COLUMN_STATUS + "=?"
                            , new String[]{String.valueOf(DEVICE_ACCEPTED),String.valueOf(DEVICE_PENDING)},
                            AppContract.Devices.COLUMN_DATE_CREATION + " DESC");
                    return null;
                }

                @Override
                protected void onPostExecute(Void result) {
                    mLog.d(TAG, "refreshData onPostExecute");
                    uploadProgressDialog.dismiss();
                    if (mAdapter == null) {
                        mAdapter = new DevicesCursorAdapter(getActivity(), mCursor);
                    } else {
                        mAdapter.changeCursor(mCursor);
                    }
                    mListView.setAdapter(mAdapter);

                }

            };
            mAsyncTask.execute((Void[]) null);
        }


    }

    @Override
    public void onStarting() {

    }

    /**
     * on onProgress
     *
     * @param deviceInfo
     */
    @Override
    public void onProgress(DeviceInfo deviceInfo) {
        mLog.d(TAG, "onProgress");
        refreshData();

    }

    /**
     * on End
     */
    @Override
    public void onEnd() {
        mLog.d(TAG, "onEnd");
        refreshData();
    }

    /**
     * on onError
     *
     * @param error
     */
    @Override
    public void onError(int error) {
        mLog.d(TAG, "onError " + error);

    }


    public class DevicesCursorAdapter extends CursorAdapter {
        public DevicesCursorAdapter(Context context, Cursor cursor) {
            super(context, cursor, 0);
        }

        public List<String> mSelectedItemId = new ArrayList<>();

        private class ViewHolder {
            TextView deviceDisplayName;
            TextView deviceName;
            TextView deviceAdr;
            TextView deviceUserId;
            TextView deviceStatus;
            CheckBox checked;
        }
        // The newView method is used to inflate a new view and return it,
        // you don't bind any data to the view at this point.
        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return LayoutInflater.from(context).inflate(R.layout.device_item_view, parent, false);
        }

        // The bindView method is used to bind all data to a given view
        // such as setting the text on a TextView.
        @Override
        public void bindView(View view, Context context, final Cursor cursor) {
            ViewHolder viewHolder = (ViewHolder) view.getTag();

            if (viewHolder == null) {
                viewHolder = new ViewHolder();
                // Find fields to populate in inflated template
                viewHolder.deviceDisplayName = (TextView) view.findViewById(R.id.deviceDisplayName);
                viewHolder.deviceName = (TextView) view.findViewById(R.id.deviceName);
                viewHolder.deviceAdr = (TextView) view.findViewById(R.id.deviceAdr);
                viewHolder.deviceUserId = (TextView) view.findViewById(R.id.deviceUserId);
                viewHolder.deviceStatus = (TextView) view.findViewById(R.id.deviceStatus);
                viewHolder.checked = (CheckBox) view.findViewById(R.id.checkBox);

                viewHolder.checked.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        String id = (String) cb.getTag();
                        if (cb.isChecked()){
                            mSelectedItemId.add(id);
                        } else {
                            mSelectedItemId.remove(id);
                        }
                    }
                });
            }

            if (mSelectionEnable){
                viewHolder.checked.setVisibility(View.VISIBLE);
            } else {
                viewHolder.checked.setVisibility(View.GONE);
            }

            // Extract properties from cursor
            String displayName = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_DISPLAY_NAME_NAME))
                    + "(" + cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_TYPE)) + ")";
            String name = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_NAME));
            String adr = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_ADDRESS));
            String userId = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_USER_ID));

            int status = cursor.getInt(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_STATUS));
            switch(status){
                case  DEVICE_ACCEPTED:
                    viewHolder.deviceStatus.setText(getString(R.string.item_status_accepted));
                    break;
                case  DEVICE_DELETED:
                    viewHolder.deviceStatus.setText(getString(R.string.item_status_deleted));
                    break;
                case  DEVICE_PENDING:
                    viewHolder.deviceStatus.setText(getString(R.string.item_status_pending));
                    break;
                case  DEVICE_DELETING:
                    viewHolder.deviceStatus.setText(getString(R.string.item_status_deleting));
                    break;
            }

            // Populate fields with extracted properties
            viewHolder.deviceDisplayName.setText(displayName);
            viewHolder.deviceName.setText(name);
            viewHolder.deviceAdr.setText(adr);
            viewHolder.deviceUserId.setText(userId);
            viewHolder.checked.setChecked(mSelectedItemId.contains(adr));
            viewHolder.checked.setTag(adr);
            view.setTag(viewHolder);

        }
    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import com.inerdev.hook.R;


/**
 * The Class DialogButtons.
 */
public class DialogButtons extends FrameLayout {

    /** The m inflater. */
    private final LayoutInflater mInflater;

    /** The m dialog button left. */
    private final Button mDialogButtonLeft;

    /** The m dialog button middle. */
    private final Button mDialogButtonMiddle;

    /** The m dialog button right. */
    private final Button mDialogButtonRight;

    /** The m first separator. */
    private final View mFirstSeparator;

    /** The m second separator. */
    private final View mSecondSeparator;

    /**
     * Instantiates a new dialog buttons.
     * @param context the context
     * @param attrs the attrs
     */
    public DialogButtons(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View view = mInflater.inflate(R.layout.uiwidgets_dialog_buttons, null);
        mDialogButtonLeft = (Button) view.findViewById(R.id.uiwidgets_dialog_button_left);
        mDialogButtonMiddle = (Button) view.findViewById(R.id.uiwidgets_dialog_button_middle);
        mDialogButtonRight = (Button) view.findViewById(R.id.uiwidgets_dialog_button_right);
        mFirstSeparator = view.findViewById(R.id.uiwidgets_first_separator);
        mSecondSeparator = view.findViewById(R.id.uiwidgets_second_separator);
        addView(view);

        final TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsDialogButtons);

        CharSequence value = a.getString(R.styleable.UIWidgetsDialogButtons_textButtonLeft);
        if (!TextUtils.isEmpty(value)) {
            setLeftButton(value, null);
        }

        value = a.getString(R.styleable.UIWidgetsDialogButtons_textButtonMiddle);
        if (!TextUtils.isEmpty(value)) {
            setMiddleButton(value, null);
        }

        value = a.getString(R.styleable.UIWidgetsDialogButtons_textButtonRight);
        if (!TextUtils.isEmpty(value)) {
            setRightButton(value, null);
        }

        boolean enabled = a.getBoolean(R.styleable.UIWidgetsDialogButtons_buttonLeftEnabled, true);
        setEnabledButton(mDialogButtonLeft, enabled);
        enabled = a.getBoolean(R.styleable.UIWidgetsDialogButtons_buttonMiddleEnabled, true);
        setEnabledButton(mDialogButtonMiddle, enabled);
        enabled = a.getBoolean(R.styleable.UIWidgetsDialogButtons_buttonRightEnabled, true);
        setEnabledButton(mDialogButtonRight, enabled);

        a.recycle();
    }

    /**
     * Change separators visibility.
     */
    private void changeSeparatorsVisibility() {
        if (mDialogButtonLeft.getVisibility() == View.VISIBLE
                && mDialogButtonMiddle.getVisibility() == View.VISIBLE) {
            mFirstSeparator.setVisibility(View.VISIBLE);
        } else {
            mFirstSeparator.setVisibility(View.GONE);
        }

        if (mDialogButtonMiddle.getVisibility() == View.VISIBLE
                && mDialogButtonRight.getVisibility() == View.VISIBLE) {
            mSecondSeparator.setVisibility(View.VISIBLE);
        } else {
            mSecondSeparator.setVisibility(View.GONE);
        }

        if (mDialogButtonLeft.getVisibility() == View.VISIBLE
                && mDialogButtonMiddle.getVisibility() == View.GONE
                && mDialogButtonRight.getVisibility() == View.VISIBLE) {
            mSecondSeparator.setVisibility(View.VISIBLE);
        } else {
            mSecondSeparator.setVisibility(View.GONE);
        }
    }

    /**
     * Sets the button.
     * @param button the button
     * @param text the text
     * @param onClickListener the on click listener
     */
    private void setButton(final Button button, final CharSequence text, final OnClickListener onClickListener) {
        button.setText(text);
        button.setVisibility(View.VISIBLE);
        setButtonListener(button, onClickListener);
        changeSeparatorsVisibility();
    }

    /**
     * Sets the button listener.
     * @param button the button
     * @param onClickListener the on click listener
     */
    private void setButtonListener(final Button button, final OnClickListener onClickListener) {
        button.setOnClickListener(onClickListener);
    }

    /**
     * Sets the enabled button.
     * @param button the button
     * @param enabled the enabled
     */
    private void setEnabledButton(final Button button, final boolean enabled) {
        button.setEnabled(enabled);
    }

    /**
     * Sets the left button.
     * @param text the text
     * @param onClickListener the on click listener
     */
    public void setLeftButton(final CharSequence text, final OnClickListener onClickListener) {
        setButton(mDialogButtonLeft, text, onClickListener);
    }

    /**
     * Sets the on left click listener.
     * @param onClickListener the new on left click listener
     */
    public void setOnLeftClickListener(final OnClickListener onClickListener) {
        setButtonListener(mDialogButtonLeft, onClickListener);
    }

    /**
     * Sets the middle button.
     * @param text the text
     * @param onClickListener the on click listener
     */
    public void setMiddleButton(final CharSequence text, final OnClickListener onClickListener) {
        setButton(mDialogButtonMiddle, text, onClickListener);
    }

    /**
     * Sets the on middle click listener.
     * @param onClickListener the new on middle click listener
     */
    public void setOnMiddleClickListener(final OnClickListener onClickListener) {
        setButtonListener(mDialogButtonMiddle, onClickListener);
    }

    /**
     * Sets the right button.
     * @param text the text
     * @param onClickListener the on click listener
     */
    public void setRightButton(final CharSequence text, final OnClickListener onClickListener) {
        setButton(mDialogButtonRight, text, onClickListener);
    }

    /**
     * Sets the on right click listener.
     * @param onClickListener the new on right click listener
     */
    public void setOnRightClickListener(final OnClickListener onClickListener) {
        setButtonListener(mDialogButtonRight, onClickListener);
    }

    /**
     * Sets the enabled left button.
     * @param enabled the new enabled left button
     */
    public void setEnabledLeftButton(final boolean enabled) {
        setEnabledButton(mDialogButtonLeft, enabled);
    }

    /**
     * Sets the enabled middle button.
     * @param enabled the new enabled middle button
     */
    public void setEnabledMiddleButton(final boolean enabled) {
        setEnabledButton(mDialogButtonMiddle, enabled);
    }

    /**
     * Sets the enabled right button.
     * @param enabled the new enabled right button
     */
    public void setEnabledRightButton(final boolean enabled) {
        setEnabledButton(mDialogButtonRight, enabled);
    }
}

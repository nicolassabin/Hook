package com.inerdev.hook.core;

/**
 * Created by nsab0001 on 15/05/2017.
 */

/**
 * The ErrorCode enum.
 */
public enum ErrorCode {

    /**
     * The network connection was lost.
     */
    ERR_LOST_CONN,
    /**
     * An unknown network error occurred.
     */
    ERR_CONN,
    /**
     * A network I/O error occurred.
     */
    ERR_IO,
    /**
     * A network I/O error occurred.
     */
    ERR_IO_RETRY,
    /**
     * An unexpected HTTP error code was received.
     */
    ERR_HTTP_CODE,
    /**
     * The HTTP communication was aborted.
     */
    ERR_HTTP_ABORT,
    /**
     * Error logging in to the MySpace service.
     */
    ERR_CANNOT_LOGIN_MS,
    /**
     * Error logging out of the MySpace service.
     */
    ERR_CANNOT_LOGOUT_MS,
    /**
     * The Launcher cannot be instantiated because a required permission is missing.
     */
    MISSING_PERMISSION,
    /**
     * The operation has failed.
     */
    OPERATION_FAILED,
    /**
     * The operation is not authorized.
     */
    OPERATION_UNAUTHORIZED,
    /**
     * The client provided at least one invalid parameter.
     */
    INVALID_PARAMETER,
    /**
     * The operation has been paused and is waiting for a resume or cancel call.
     */
    OPERATION_PAUSED,
    /**
     * The operation has been cancelled.
     */
    OPERATION_CANCELED,
    /**
     * An unspecified exception was thrown.
     *  */
    OTHER_EXCEPTION,
    /**
     * The Personal Cloud server is in maintenance mode. Please retry later.
     */
    ERR_MAINTENANCE_MODE,
    /**
     * The call to the API is forbidden.
     */
    ERR_FORBIDDEN,
    /**
     * The required access info isn't valid.
     */
    INVALID_ACCESS_INFO,
    /**
     * The logged-in user has insufficient permissions for the client to make this call
     */
    ERR_PERMISSION_DENIED,
    /**
     * The OPERATION_INTERRUPTED
     */
    OPERATION_INTERRUPTED,



}

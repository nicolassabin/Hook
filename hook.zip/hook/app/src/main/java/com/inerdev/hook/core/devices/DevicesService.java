package com.inerdev.hook.core.devices;

import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.provider.AppContract;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static android.os.Build.VERSION_CODES.JELLY_BEAN_MR2;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_ACCEPTED;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_PENDING;

/**
 * Created by nsab0001 on 31/05/2017.
 */

public class DevicesService extends Service {

    public static final String		SERVICE_NAME									= ".DevicesService";


    /** The ACTION_START_SCANNING */
    public static final String		ACTION_UPDATE_STATUS							= "ACTION_UPDATE_STATUS";
    /** The ACTION_START_SCANNING */
    public static final String		ACTION_START_SCANNING							= "ACTION_START_SCANNING";
    /** The ACTION_STOP_SCANNING. */
    public static final String		ACTION_STOP_SCANNING							= "ACTION_STOP_SCANNING";
    /** The ACTION_CLEAR_CACHE */
    public static final String		ACTION_CLEAR_CACHE								= "ACTION_CLEAR_CACHE";
    /** The PARAM_ACTION */
    public static final String		PARAM_ACTION							        = "PARAM_ACTION";
    /** The PARAM_ID_SERVICE. */
    public static final String		PARAM_ID_SERVICE								= "PARAM_ID_SERVICE";
    /** The PARAM_TYPE_SCANNING */
    public static final String		PARAM_TYPE_SCANNING							    = "PARAM_TYPE_SCANNING";
    /** The PARAM_SCANNING_TIMEOUT */
    public static final String		PARAM_SCANNING_TIMEOUT							= "PARAM_SCANNING_TIMEOUT";


    private static final boolean WIFI_SCANNING = false;


    private static final String LOG_TAG = "DevicesService";

    /** The m log. */
    private Log mLog;

    /** The m Devices. */
    private AppContract.Devices mDevices;

    /** The m DevicesWifiManager. */
    private DevicesWifiManager mDevicesWifiManager;

    /** The m DevicesBluetoothManager. */
    private DevicesBluetoothManager mDevicesBluetoothManager;

    /** The m DevicesBackendHelper. */
    private DevicesBackendHelper mDevicesBackendHelper;


    /**
     */
    @Override
    public void onCreate() {
        super.onCreate();

        mLog.d(LOG_TAG, "Service created");
        mDevicesWifiManager = new DevicesWifiManager(getApplicationContext());
        mDevicesBluetoothManager = new DevicesBluetoothManager(getApplicationContext());
        mDevicesBackendHelper = new DevicesBackendHelper(getApplicationContext());
        mDevices = new AppContract.Devices(((HookApplication) getApplication()).getAppContract());
    }

    /**
     * On destroy.
     */
    @Override
    /**
     * Logging-only destructor.
     */
    public void onDestroy() {
        if (mDevicesBluetoothManager != null){
            mDevicesBluetoothManager.close();
        }
        if (WIFI_SCANNING){
            mDevicesWifiManager.close();
        }
        super.onDestroy();
        mLog.d(LOG_TAG, "Service destroyed");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent !=null){
            String action = intent.getStringExtra(PARAM_ACTION);
            mLog.d(LOG_TAG, "onStartCommand action " + action);
            if (ACTION_START_SCANNING.equalsIgnoreCase(action)) {
                int iTypeScanning = intent.getIntExtra(PARAM_TYPE_SCANNING, DevicesManager.TYPE_SCANNING_ALL);
                int iTimeOut = intent.getIntExtra(PARAM_SCANNING_TIMEOUT, DevicesBluetoothManager.DEFAULT_TIMEOUT);
                mLog.d(LOG_TAG, "onStartCommand iTypeScanning " + iTypeScanning + " iTimeOut " + iTimeOut);
                Intent intentResult = new Intent(DevicesManager.INTENT_ACTION_DEVICES_SCANNING_STARTED);
                intentResult.setPackage(getApplicationContext().getPackageName());
                sendBroadcast(intentResult);

                mLog.d(LOG_TAG, "onStartCommand ACTION_START_SCANNING");

                if (mDevicesBluetoothManager != null && iTypeScanning != DevicesManager.TYPE_SCANNING_WIFI) {
                    mDevicesBluetoothManager.startScanning(new MyScanCallBackOperation("Bluetooth"), iTimeOut);
                }
                if (mDevicesWifiManager != null && WIFI_SCANNING && iTypeScanning != DevicesManager.TYPE_SCANNING_BT){
                    mDevicesWifiManager.startScanning(new MyScanCallBackOperation("WIFI"));
                }
            } else if (ACTION_UPDATE_STATUS.equalsIgnoreCase(action)) {
                mLog.d(LOG_TAG, "onStartCommand ACTION_UPDATE_STATUS");

                // parse the device database with pending status and try to get user from backen d in order to update the status.
                Thread thread = new Thread(new Runnable(){
                    public void run() {
                        updateDevicesStatus();
                    }
                });
                thread.start();


            } else if (ACTION_STOP_SCANNING.equalsIgnoreCase(action)){
                if (mDevicesBluetoothManager != null) {
                    mDevicesBluetoothManager.close();
                }
                if (mDevicesWifiManager != null && WIFI_SCANNING) {
                    mDevicesWifiManager.close();
                }
            } else if (ACTION_CLEAR_CACHE.equalsIgnoreCase(action)){
                if (mDevicesBluetoothManager != null) {
                    mDevicesBluetoothManager.clearCache(intent.getStringExtra(PARAM_ID_SERVICE));
                }
                mDevicesWifiManager.clearCache(intent.getStringExtra(PARAM_ID_SERVICE));
            }
        }

        return START_STICKY;
    }

    private void updateDevicesStatus() {
        mLog.d(LOG_TAG, "updateDevicesStatus");
        Cursor cursor = null;
        try{
            DevicesBackendHelper devicesBackendHelper = new DevicesBackendHelper(getApplicationContext());
            cursor = getContentResolver().query(mDevices.getContentUri(),
                    null, AppContract.Devices.COLUMN_STATUS + "=? AND " + AppContract.Devices.COLUMN_USER_ID + " IS NULL"
                    , new String[]{String.valueOf(DEVICE_PENDING)},
                    AppContract.Devices.COLUMN_DATE_CREATION + " DESC");
            if (cursor.moveToFirst()) {
                do {
                    String adr = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_ADDRESS));
                    String userId = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_USER_ID));
                    mLog.d(LOG_TAG, "updateDevicesStatus adr " + adr + " userId " + userId);
                    if (TextUtils.isEmpty(userId)) {
                        mLog.i(LOG_TAG, "updateDevicesStatus retrieve user id from the server ");
                        userId = devicesBackendHelper.getUserFromDevice(adr);
                        if (!TextUtils.isEmpty(userId)) {
                            // update data
                            ContentValues contentValues = new ContentValues();
                            contentValues.put(AppContract.Devices.COLUMN_USER_ID, userId);
                            contentValues.put(AppContract.Devices.COLUMN_STATUS, AppContract.Devices.DEVICE_ACCEPTED);

                            mLog.d(LOG_TAG, "updateDevicesStatus try to update into database");
                            if (getContentResolver().update(mDevices.getContentUri(),
                                    contentValues, AppContract.Devices.COLUMN_ADDRESS + "=?",
                                    new String[]{adr}) == 0) {

                                mLog.i(LOG_TAG, "updateDevicesStatus update failed to update adr " + adr);

                            }

                        }
                    }
                } while (cursor.moveToNext());
            } else {
                mLog.i(LOG_TAG, "updateDevicesStatus moveToFirst empty cursor ");
            }
        } catch (Exception e){
            mLog.e(LOG_TAG, "updateDevicesStatus Exception ", e);
        } finally {
            if (cursor !=null){
                cursor.close();
            }
        }
    }

    /**
     * Return the communication channel to the service.  May return null if
     * clients can not bind to the service.  The returned
     * {@link IBinder} is usually for a complex interface
     * that has been <a href="{@docRoot}guide/components/aidl.html">described using
     * aidl</a>.
     * <p>
     * <p><em>Note that unlike other application components, calls on to the
     * IBinder interface returned here may not happen on the main thread
     * of the process</em>.  More information about the main thread can be found in
     * <a href="{@docRoot}guide/topics/fundamentals/processes-and-threads.html">Processes and
     * Threads</a>.</p>
     *
     * @param intent The Intent that was used to bind to this service,
     *               as given to {@link Context#bindService
     *               Context.bindService}.  Note that any extras that were included with
     *               the Intent at that point will <em>not</em> be seen here.
     * @return Return an IBinder through which clients can call on to the
     * service.
     */
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void addDeviceInfo(DeviceInfo deviceInfo, String type) {
        if (deviceInfo != null) {

            Intent intentResult;
            ContentValues contentValues = new ContentValues();
            long lTime = System.currentTimeMillis();

            contentValues.put(AppContract.Devices.COLUMN_DATE_CREATION, lTime);
            contentValues.put(AppContract.Devices.COLUMN_ADDRESS, deviceInfo.getAdr());
            contentValues.put(AppContract.Devices.COLUMN_NAME, deviceInfo.getName());
            contentValues.put(AppContract.Devices.COLUMN_DISPLAY_NAME_NAME, deviceInfo.getDisplayName());
            contentValues.put(AppContract.Devices.COLUMN_TYPE, type);
            contentValues.put(AppContract.Devices.COLUMN_UIID, deviceInfo.getId());
            contentValues.put(AppContract.Devices.COLUMN_STATUS, deviceInfo.getStatus());
            contentValues.put(AppContract.Devices.COLUMN_USER_ID, deviceInfo.getUserId());

            mLog.d(LOG_TAG, "addDeviceInfo try to update");
            if (getContentResolver().update(mDevices.getContentUri(),
                    contentValues, AppContract.Devices.COLUMN_UIID + "=? AND " + AppContract.Devices.COLUMN_STATUS + "<>?",
                    new String[]{deviceInfo.getId(), String.valueOf(AppContract.Devices.DEVICE_DELETED)}) == 0) {

                mLog.i(LOG_TAG, "addDeviceInfo update failed so, insert " + deviceInfo.getAdr());
                if (getContentResolver().insert(mDevices.getContentUri(),
                        contentValues) == null) {
                    mLog.e(LOG_TAG, "addDeviceInfo insert failed");
                    intentResult = new Intent(DevicesManager.INTENT_ACTION_DEVICES_SCANNING_FAILED);
                    intentResult.setPackage(getApplicationContext().getPackageName());
                    intentResult.putExtra(DevicesManager.INTENT_DEVICES_SCANNING_ERROR, 1);
                    sendBroadcast(intentResult);
                }
            }

            intentResult = new Intent(DevicesManager.INTENT_ACTION_DEVICES_SCANNING_PROGRESS);
            intentResult.setPackage(getApplicationContext().getPackageName());
            intentResult.putExtra(DevicesManager.INTENT_DEVICES_SCANNING_DEVICE_INFO, deviceInfo);
            sendBroadcast(intentResult);
        } else {
            mLog.e(LOG_TAG, "addDeviceInfo invalid deviceInfo");
        }

    }

    private class MyScanCallBackOperation implements ScanCallBackOperation {
        private String mType;

        public MyScanCallBackOperation (String type){
            mType = type;
        }

        @Override
        public void onScanResult(DeviceInfo deviceInfo) {
            addDeviceInfo(deviceInfo, mType);
        }

        /**
         * on onEnd
         */
        @Override
        public void onEnd() {
            Intent intentResult = new Intent(DevicesManager.INTENT_ACTION_DEVICES_SCANNING_SUCCEED);
            intentResult.setPackage(getApplicationContext().getPackageName());
            sendBroadcast(intentResult);
        }

        /**
         * on onError
         * @param error
         */
        public void onError(int error){
            Intent intentResult = new Intent(DevicesManager.INTENT_ACTION_DEVICES_SCANNING_FAILED);
            intentResult.putExtra(DevicesManager.INTENT_DEVICES_SCANNING_ERROR, error);
            intentResult.setPackage(getApplicationContext().getPackageName());
            sendBroadcast(intentResult);
        }

    }
}

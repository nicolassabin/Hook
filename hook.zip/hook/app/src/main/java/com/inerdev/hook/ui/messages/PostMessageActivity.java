package com.inerdev.hook.ui.messages;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.devices.DeviceInfo;
import com.inerdev.hook.core.messages.MessagesBackendHelper;
import com.inerdev.hook.provider.AppContract;
import com.inerdev.hook.ui.utils.WifiBtStatusProvider;


public class PostMessageActivity extends AppCompatActivity {

    private static final String TAG = "PostMessageActivity";

    /** The m log. */
    private Log mLog;

    private HookApplication mApplication;
    private static final int MAX_INSERT = 1;
    private WifiBtStatusProvider mWifiBtStatusProvider;
    private Spinner mCategorySpinner;
    private Spinner mDateExpirationSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_post);
        mApplication = (HookApplication) getApplication();
        mWifiBtStatusProvider = mApplication.getWifiBtStatusProvider();


        mCategorySpinner = (Spinner) findViewById(R.id.category_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.msg_category_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        mCategorySpinner.setAdapter(adapter);

        mDateExpirationSpinner = (Spinner) findViewById(R.id.dateexpiration_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapterDateExpiration = ArrayAdapter.createFromResource(this,
                R.array.msg_expiration_date_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapterDateExpiration.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        mDateExpirationSpinner.setAdapter(adapterDateExpiration);

        final EditText subject = (EditText) findViewById(R.id.nameEditSubject);
        final EditText text = (EditText) findViewById(R.id.nameEditText);

        findViewById(R.id.saveButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(TextUtils.isEmpty(subject.getText())){

                    subject.setError(getResources().getString(R.string.empty_field));
                    return;
                }
                if(TextUtils.isEmpty(text.getText())){

                    text.setError(getResources().getString(R.string.empty_field));
                    return;
                }
                final ProgressDialog progressDialog = showProgressDialog("",
                        getString(R.string.msg_posting), true);
                progressDialog.show();

                final String subjectS = subject.getText().toString();
                final String textS = text.getText().toString();

                AsyncTask<String, Boolean, Boolean> asyncTask = new AsyncTask<String, Boolean, Boolean>()
                {

                    @Override
                    protected Boolean doInBackground(String... params) {

//                        String senderDeviceAdr = mApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getDeviceAdr();
//                        if (TextUtils.isEmpty(senderDeviceAdr)){
//                            senderDeviceAdr = mApplication.getAuthenticationManagerHelper().getUserUid();
//                        }

                        mLog.d(TAG, "doInBackground postMessage textS:"
                                + textS + " subjectS:" + subjectS);
                        MessagesBackendHelper messagesBackendHelper = new MessagesBackendHelper(PostMessageActivity.this);
                        if (messagesBackendHelper.postMessage(textS, subjectS)){
                            storeInDatabase(textS, subjectS);
                            return Boolean.valueOf(true);
                        }
                        return Boolean.valueOf(false);

                    }

                    @Override
                    protected void onPostExecute(Boolean result) {
                        mLog.d(TAG, "onPostExecute result" + result);
                        progressDialog.dismiss();
                        if (result == true) {
                            setResult(RESULT_OK);
                            finish();
                        } else {
                            Toast.makeText(PostMessageActivity.this, getResources().getString(R.string.msg_error_post), Toast.LENGTH_LONG).show();
                        }
                    }
                };
                asyncTask.execute();

            }
        });

        findViewById(R.id.cancelButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    private ProgressDialog showProgressDialog(String title, String message, boolean indeterminate) {
        return ProgressDialog.show(this, title, message, indeterminate);
    }

    private void storeInDatabase(final String msgText, final String msgSubject){
        AppContract.Messages message = new AppContract.Messages(mApplication.getAppContract());

        ContentValues contentValues = new ContentValues();
        long lTime = System.currentTimeMillis();
        contentValues.put(AppContract.Messages.COLUMN_DATE_CREATION, lTime);
        int iDays = 2;
        switch(mDateExpirationSpinner.getSelectedItemPosition()){
            case 0: // 1 day
                iDays = 1;
                break;
            case 1: // 2 days
                iDays = 2;
                break;
            case 2: // 1 week
                iDays = 7;
                break;
            case 3: // 2 week
                iDays = 14;
                break;
            case 4: // 1 month
                iDays = 30;
                break;
            case 5: // 3 month
                iDays = 90;
                break;
        }
        contentValues.put(AppContract.Messages.COLUMN_DATE_EXPIRATION, lTime
                + iDays*24*60*60*1000);
        contentValues.put(AppContract.Messages.COLUMN_NAME_VERSION, "1.0");
        contentValues.put(AppContract.Messages.COLUMN_SUBJECT, msgSubject);
        contentValues.put(AppContract.Messages.COLUMN_TEXT, msgText);
        contentValues.put(AppContract.Messages.COLUMN_ITEM_CATEGORY_TYPE, (String)mCategorySpinner.getSelectedItem());
        contentValues.put(AppContract.Messages.COLUMN_SENDER_NAME,
                mApplication.getAuthenticationManagerHelper().getUserUid());
        contentValues.put(AppContract.Messages.COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME,
                mApplication.getAuthenticationManagerHelper().getUserUid());

        String senderDeviceId = mApplication.getAuthenticationManagerHelper().getAuthenticationInfo().getAccountName();
        String senderDeviceAdr = mApplication.getAuthenticationManagerHelper().getUserUid();
        DeviceInfo deviceInfoBt = mWifiBtStatusProvider.getBtDeviceInfo();
        DeviceInfo deviceInfoWifi = mWifiBtStatusProvider.getWifiDeviceInfo();
        if ( deviceInfoBt != null){
            senderDeviceAdr = deviceInfoBt.getAdr();
        } else if (deviceInfoWifi != null){
            senderDeviceAdr = deviceInfoWifi.getAdr();
        }
        mLog.d(TAG, "storeInDatabase senderDeviceId " + senderDeviceId
                + " senderDeviceAdr " + senderDeviceAdr);

        contentValues.put(AppContract.Messages.COLUMN_SENDER_DEVICE_ID,
                senderDeviceId);

        contentValues.put(AppContract.Messages.COLUMN_SENDER_ADR,
                senderDeviceAdr);

        contentValues.put(AppContract.Messages.COLUMN_ITEM_TYPE, AppContract.Messages.MSG_POSTED);
        contentValues.put(AppContract.Messages.COLUMN_STATUS, AppContract.Messages.STATUS_COMPLETE);

        // sent the message to the server

        //request is succesfull then , save in database

        if (getContentResolver().insert(message.getContentUri(),
                contentValues) == null){
            mLog.e(TAG, "storeInDatabase insert failed");

        }
    }
}


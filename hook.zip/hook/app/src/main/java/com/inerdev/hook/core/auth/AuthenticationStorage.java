/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


/**
 * The Class AuthenticationStorage.
 */
public class AuthenticationStorage {

    /** The Constant HEADER_AUTHORIZATION. */
    public static final String HEADER_AUTHORIZATION = "Authorization";

    /** @deprecated The Constant AUTHORIZATION_HEADER. */
    @Deprecated public static final String AUTHORIZATION_HEADER = HEADER_AUTHORIZATION;

    /** The Constant AUTHORIZATION_HEADER_VALUE_FORMAT. */
    public static final String HEADER_AUTHORIZATION_VALUE_FORMAT = "NWB token=\"%s\" authVersion=\"1.0\"";

    /** @deprecated The Constant AUTHORIZATION_HEADER_VALUE_FORMAT. */
    @Deprecated public static final String AUTHORIZATION_HEADER_VALUE_FORMAT = HEADER_AUTHORIZATION_VALUE_FORMAT;

    /** The Constant HEADER_AUTHORIZATION_VALUE_SYNTAXE. */
    public static final String HEADER_AUTHORIZATION_VALUE_SYNTAXE = "NWB token=\"{token}\" authVersion=\"1.0\"";

    /** @deprecated The Constant AUTHORIZATION_HEADER_VALUE_SYNTAXE. */
    @Deprecated public static final String AUTHORIZATION_HEADER_VALUE_SYNTAXE = HEADER_AUTHORIZATION_VALUE_SYNTAXE;

    /** The Constant AUTHORIZATION_HEADER_NWB_VALUE_PATTERN. */
    public static final Pattern HEADER_AUTHORIZATION_NWB_VALUE_PATTERN = Pattern.compile("NWB token=\"(.*?)\"");

    /** @deprecated The Constant AUTHORIZATION_HEADER_NWB_VALUE_PATTERN. */
    @Deprecated public static final Pattern AUTHORIZATION_HEADER_NWB_VALUE_PATTERN = HEADER_AUTHORIZATION_NWB_VALUE_PATTERN;

    // SDCANDTACT-4439: Let's remember the last couple of expired tokens in case long running
    // operations that used them are still lingering around in background threads
    /** The Constant MAX_EXPIRED_ACCESS_TOKEN_COUNT. */
    private static final int MAX_EXPIRED_ACCESS_TOKEN_COUNT = 5;

    /** The m preference manager. */
    private final PreferenceManager mPreferenceManager;

    /** The m short lived token. */
    private String mShortLivedToken;

    /** The m context token. */
    private String mContextToken;

    /** The m dv user uid. */
    private String mDvUserUid;

    /** The m email. */
    private String mEmail;

    /** The m mAccountName. */
    private String mAccountName;

    /** The m mDeviceAdr. */
    private String mDeviceAdr;

    /** The m is dv account deactivated. */
    private boolean mIsDvAccountDeactivated;

    /** The Constant LOG_TAG. */
    private static final String LOG_TAG = "AuthenticationStorage";

    /** The m token expires in. */
    private long mTokenExpiresIn = 0;

    /** The m token requested in. */
    private long mTokenRequestedIn = 0;

    /** The m log. */
    private Log mLog;

    /** The m expired access tokens. */
    private final List<String> mExpiredAccessTokens = new ArrayList<String>();

    /** The m is user end point running. */
    private volatile boolean mIsUserEndPointRunning = false;

    /** The m ExternalIds. */
    private Map<String,String> mAdditionalInfos = new HashMap<String,String>();


    /**
     * Instantiates a new authentication storage.
     *
     * @param context the context
     */
    public AuthenticationStorage(final Context context) {
        mPreferenceManager = new PreferenceManager(mLog
                , context);

        loadFromPreferences();
    }

    /**
     * Load from preferences.
     */
    private void loadFromPreferences() {
        mShortLivedToken = mPreferenceManager.readAccessToken();
        mContextToken = mPreferenceManager.readContextToken();
        mDvUserUid = mPreferenceManager.readUserID();
        mEmail = mPreferenceManager.readEmail();
        mAccountName = mPreferenceManager.readAccountName();
        mIsDvAccountDeactivated = mPreferenceManager.readDvAccountDeactivated();
        mDeviceAdr = mPreferenceManager.readDeviceAdr();

    }

    /**
     * Gets the context token.
     * @return the context token
     */
    public String getContextToken() {
        return mContextToken;
    }

    /**
     * Sets the context token.
     * @param contextToken the new context token
     */
    public void setContextToken(final String contextToken) {
        mLog.d(LOG_TAG, "setContextToken was: " + mContextToken + " will be: " + contextToken);
        mContextToken = contextToken;
        // save context token to internal memory:
        mPreferenceManager.saveContextToken(mContextToken);

    }

    /**
     * Gets the dv user uid.
     * @return the dv user uid
     */
    public String getDvUserUid() {
        return mDvUserUid;
    }

    /**
     * Sets the dv user uid.
     * @param userUid the new dv user uid
     */
    public void setDvUserUid(final String userUid) {
        mLog.d(LOG_TAG, "setDvUserUid was: " + mDvUserUid + " will be: " + userUid);
        this.mDvUserUid = userUid;
        // save userID
        mPreferenceManager.saveUserID(mDvUserUid);
    }

    /**
     * Save the AccountName.
     * @param accountName the AccountName
     */
    public void setAccountName(final String accountName) {
        mAccountName = accountName;
        mPreferenceManager.saveAccountName(accountName);
    }

    /**
     * Gets the AccountName.
     * @return the AccountName
     */
    public String getAccountName() {
        return mAccountName;
    }

    /**
     * Save the DeviceAdr.
     * @param deviceAdr the DeviceAdr
     */
    public void setDeviceAdr(final String deviceAdr) {
        mDeviceAdr = deviceAdr;
        mPreferenceManager.saveDeviceAdr(deviceAdr);
    }

    /**
     * Gets the DeviceAdr.
     * @return the DeviceAdr
     */
    public String getDeviceAdr() {
        return mDeviceAdr;
    }

    /**
     * Save login status.
     * @param loginStatus the login status
     */
    public void saveLoginStatus(final boolean loginStatus) {
        mPreferenceManager.saveUserLoginStatus(loginStatus);
    }

    /**
     * Gets the short lived token.
     * @return the short lived token
     */
    public String getShortLivedToken() {
        return mShortLivedToken;
    }

    /**
     * Sets the short lived token.
     * @param shortLivedToken the new short lived token
     */
    public void setShortLivedToken(final String shortLivedToken) {
        mLog.d(LOG_TAG, "setShortLivedToken was: " + mShortLivedToken + " will be: " + shortLivedToken);
        mShortLivedToken = shortLivedToken;
        mPreferenceManager.saveAccessToken(mShortLivedToken);
    }

    /**
     * Clear.
     */
    public void clear() {
        // Legacy clear code:

        setContextToken("");
        setDvUserUid("");
        setShortLivedToken("");
        setExpirationTime(0, 0);
        saveEmail(null);

        // clear persisted data
        setAccountName(null);
    }

    /**
     * Sets the expiration time.
     * @param expiresIn the expires in
     * @param requestedIn the requested in
     */
    public void setExpirationTime(final long expiresIn, final long requestedIn) {
        this.mTokenExpiresIn = expiresIn;
        this.mTokenRequestedIn = requestedIn;
    }

    /**
     * Gets the expiration time.
     * @return the expiration time
     */
    public long getExpirationTime() {
        return this.mTokenExpiresIn;
    }

    /**
     * Sets the expiration time.
     * @param expiresIn the new expiration time
     */
    public void setExpirationTime(final String expiresIn) {
        try {
            setExpirationTime(Long.parseLong(expiresIn), System.currentTimeMillis());
        } catch (final Exception e) {
            mLog.e(LOG_TAG, "setExpirationTime Exception", e);
            setExpirationTime(0, 0);
        }
    }

    /**
     * Checks if is token expired.
     * @param divider the divider
     * @return true, if is token expired
     */
    public boolean isTokenExpired(int divider) {
        if (divider == 0){
            return (System.currentTimeMillis() > mTokenRequestedIn + mTokenExpiresIn);
        }

        return (System.currentTimeMillis() > mTokenRequestedIn + (mTokenExpiresIn / divider));
    }

    // SDCANDTACT-4274
    /**
     * Sets the dv account deactivated.
     * @param isDeactivated the new dv account deactivated
     */
    public void setDvAccountDeactivated(final boolean isDeactivated) {
        mIsDvAccountDeactivated = isDeactivated;
        mPreferenceManager.saveDvAccountDeactivated(isDeactivated);
    }

    // SDCANDTACT-4274
    /**
     * Checks if is dv account deactivated.
     * @return true, if is dv account deactivated
     */
    public boolean isDvAccountDeactivated() {
        return mIsDvAccountDeactivated;
    }

    // SDCANDTACT-4439
    /**
     * Stores the access token as expired access token for the lifetime of the process
     * <p class="note">
     * This call is used by classes that directly execute requests against the backend (adding the access token used in
     * requests that return 401/403 HTTP Status Code).
     * @param accessToken The access token that is known to be expired
     * @see #isAccessTokenKnownToBeExpired(String)
     */
    public void addExpiredAccessToken(final String accessToken) {
        synchronized (mExpiredAccessTokens) {
            if (!mExpiredAccessTokens.contains(accessToken)) {
                mExpiredAccessTokens.add(accessToken);
                mLog.d(LOG_TAG, "addExpiredAccessToken: added" + accessToken);
            } else {
                mLog.d(LOG_TAG, "addExpiredAccessToken: is on the list already " + accessToken);
            }

            while (mExpiredAccessTokens.size() > MAX_EXPIRED_ACCESS_TOKEN_COUNT) {
                mLog.d(LOG_TAG, "addExpiredAccessToken: List is too large. Removing old item: " +
                        mExpiredAccessTokens.get(0));
                mExpiredAccessTokens.remove(0);
            }
        }
    }

    // SDCANDTACT-4439
    /**
     * Is this access token on the memory list we built using calls to {@link #addExpiredAccessToken(String)}?
     * <p class="note">
     * This call is used by the authentication flow to optimize authentication attempts (see SDCANDTACT-4439).
     * @param accessToken The access token to look up
     * @return {@code true} if the access token is on the list of known expired access tokens or {@code false} otherwise
     * @see #addExpiredAccessToken(String)
     */
    public boolean isAccessTokenKnownToBeExpired(final String accessToken) {
        synchronized (mExpiredAccessTokens) {
            final boolean result = mExpiredAccessTokens.contains(accessToken);
            mLog.d(LOG_TAG, "isAccessTokenKnownToBeExpired: returning " + accessToken + result);
            return result;
        }
    }

    /**
     * Sets the user end point running.
     * @param isRunning the new user end point running
     */
    public void setUserEndPointRunning(final boolean isRunning) {
        mIsUserEndPointRunning = isRunning;
    }

    /**
     * Checks if is user end point running.
     * @return true, if is user end point running
     */
    public boolean isUserEndPointRunning() {
        return mIsUserEndPointRunning;
    }

    /**
     * Save email.
     * @param email the email
     */
    public void saveEmail(final String email) {
        mEmail = email;
        mPreferenceManager.saveEmail(email);
    }

    /**
     * Gets the email.
     * @return the email
     */
    public String getEmail() {
        return mEmail;
    }

    /**
     * Checks if is provisioned.
     * @return true, if is provisioned
     */
    public boolean isProvisioned() {
        boolean result = false;

        result = mPreferenceManager.readUserLoginStatus();
        mLog.d(LOG_TAG, "isProvisioned: result=" + result);

        return result;
    }

    /**
     * Gets the AdditionalInfos.
     * @return the mAdditionalInfos map
     */
    public Map<String,String> getAdditionalInfos() {
        return mAdditionalInfos;
    }

    /**
     * Sets the migration Info.
     * @param additionalInfos the migration info
     */
    public void setAdditionalInfos(final Map<String,String> additionalInfos) {
        mLog.d(LOG_TAG, "setAdditionalInfos ");
        this.mAdditionalInfos = additionalInfos;

    }

    /**
     * Reads user id from GENERAL_PREF.
     * @return the string
     */
    public String readUserID() {
        return mPreferenceManager.readUserID();
    }

    /**
     * Read if user authenticated once from GENERAL_PREF.
     * @return true, if is user authenticated once
     */
    public boolean isUserAuthenticatedOnce() {
        return mPreferenceManager.isUserAuthenticatedOnce();
    }

    /**
     * Sets the user authenticated once.
     */
    public void setUserAuthenticatedOnce() {
        mPreferenceManager.setUserAuthenticatedOnce();
    }

    /**
     * Read user login status.
     * @return true, if successful
     */
    public boolean readUserLoginStatus() {
        return mPreferenceManager.readUserLoginStatus();
    }
}

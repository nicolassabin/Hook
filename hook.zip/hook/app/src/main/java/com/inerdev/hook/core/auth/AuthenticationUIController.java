/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.R;
import com.inerdev.hook.core.config.ConfigHelper;


/**
 * The Class AuthenticationUIController.
 */
public class AuthenticationUIController {

    /** The Constant TAG. */
    private static final String TAG = "AuthUIController";

    /** The intent action auth. */
    public static final String INTENT_ACTION_AUTH = ".intent.action.AUTH";

    /** The is in app native registration. */
    public static final String IS_IN_APP_NATIVE_REGISTRATION = "isInAppNativeRegistration";

    /** The intent action welcome. */
    private static final String INTENT_ACTION_WELCOME = ".intent.action.WELCOME";

    /** The intent action wizard. */
    private static final String INTENT_ACTION_WIZARD = ".intent.action.WIZARD";

    /** The intent action wizard get started. */
    private static final String INTENT_ACTION_WIZARD_GET_STARTED = ".intent.action.WIZARD_GET_STARTED";

    /** The m log. */
    private Log mLog;

    /** The m context. */
    private final Context mContext;

    /** The m Configurations. */
    private final ConfigHelper mConfigHelper;

    /** The m authentication storage. */
    private final AuthenticationStorage mAuthenticationStorage;

    /** The m is wizard flow enabled. */
    private final boolean mIsWizardFlowEnabled;

    /** The m mIsStraightToWizard. */
    private final boolean mIsStraightToWizard;

    /**
     * Instantiates a new authentication ui controller impl.
     * @param context the context
     * @param configHelper the configurations
     * @param authenticationStorage the authentication storage
     */
    public AuthenticationUIController(final Context context,
                                      final ConfigHelper configHelper,
                                      final AuthenticationStorage authenticationStorage) {
        mContext = context;
        mConfigHelper = configHelper;
        mAuthenticationStorage = authenticationStorage;
        mIsWizardFlowEnabled = true;
        mIsStraightToWizard = false;

    }




    /**
     * Do interactive auth.
     * @param redirectToAuthActivity the redirect to auth activity
     */
    public void doInteractiveAuth(final boolean redirectToAuthActivity) {
        mLog.d(TAG, "doAuth interactively");

        if (mConfigHelper.getConfig() != null)
        {
            // Get the details of the last opco returned by the last successful auth (if any)
            final boolean hasDvUserId = !TextUtils.isEmpty(mAuthenticationStorage.getDvUserUid());

            boolean dontShowWelcomeScreen = true;
            Intent intent;
            if (dontShowWelcomeScreen) {
                if (mIsWizardFlowEnabled && !redirectToAuthActivity && !mAuthenticationStorage.isUserAuthenticatedOnce()) {
                    intent = new Intent(getIntentAction(mIsStraightToWizard ? INTENT_ACTION_WIZARD : INTENT_ACTION_WIZARD_GET_STARTED));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                } else {
                    intent = new Intent(getIntentAction(INTENT_ACTION_AUTH));
                }
            } else {
                intent = new Intent(getIntentAction(INTENT_ACTION_WELCOME));
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            intent.setPackage(mContext.getPackageName());
            mContext.startActivity(intent);
        }

    }

    /**
     * Gets the package specific action for action suffix
     * @param actionSuffix
     * @return
     */
    private String getIntentAction(String actionSuffix) {
        return String.format("%s%s", mContext.getPackageName(), actionSuffix);
    }

}

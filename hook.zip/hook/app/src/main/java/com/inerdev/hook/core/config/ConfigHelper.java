package com.inerdev.hook.core.config;

import android.content.Context;
import android.util.Log;

/**
 * Created by nsab0001 on 15/05/2017.
 */

public class ConfigHelper implements Config {

    private static final String LOG_TAG = "ConfigHelper";

    private ConfigInfoImpl mConfigInfoImpl;

    public ConfigHelper(Context context){

        mConfigInfoImpl = new ConfigInfoImpl(context);
    }
    /**
     * Retrieves the global configuration from the end point.
     *
     * @param endPointUri
     * @return true to indicate retrieve is well passed
     */
    @Override
    public boolean retrieveConfig(String endPointUri) {
        Log.d(LOG_TAG, "retrieveConfig");
        return true;
    }

    /**
     * Retrieves the default configuration without connecting to the end point.
     *
     * @return : IConfigInfo The details of the default configuration
     */
    @Override
    public ConfigInfo getConfig() {
        return mConfigInfoImpl;
    }
}

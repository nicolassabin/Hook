package com.inerdev.hook.core.messages;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.provider.AppContract;
import com.inerdev.hook.ui.utils.MySharePreferences;

import java.util.ArrayList;
import java.util.List;

import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_ACCEPTED;
import static com.inerdev.hook.provider.AppContract.Devices.DEVICE_PENDING;
import static com.inerdev.hook.ui.Constants.MESSAGES_ETAG;

/**
 * Created by nsab0001 on 31/05/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public class MessagesService extends JobService {

    public static final String		SERVICE_NAME									= ".MessagesService";

    /** The ACTION_START_SCANNING */
    public static final String		ACTION_START_SCANNING							= "ACTION_START_SCANNING";
    /** The ACTION_STOP_SCANNING. */
    public static final String		ACTION_STOP_SCANNING							= "ACTION_STOP_SCANNING";
    /** The ACTION_CLEAR_CACHE */
    public static final String		ACTION_CLEAR_CACHE								= "ACTION_CLEAR_CACHE";
    /** The PARAM_ACTION */
    public static final String		PARAM_ACTION							        = "PARAM_ACTION";

    private static final String LOG_TAG = "MessagesService";

    /** The m log. */
    private Log mLog;

    /** The m Messages. */
    private AppContract.Messages mMessages;

    /** The m Devices. */
    private AppContract.Devices mDevices;

    /** The m MessagesBackendHelper. */
    private MessagesBackendHelper mMessagesBackendHelper;

    /** The m mStartMessagesScanning. */
    private boolean mStartMessagesScanning = false;

    /** The m mEtag. */
    private String mEtag = null;

    /** The m mMySharePreferences. */
    private MySharePreferences mMySharePreferences;

    /** The m mAuthenticationManager. */
    private AuthenticationManager mAuthenticationManager;


    /**
     */
    @Override
    public void onCreate() {
        super.onCreate();

        mLog.d(LOG_TAG, "Service created");
        mMessagesBackendHelper = new MessagesBackendHelper(getApplicationContext());
        mMessages = new AppContract.Messages(((HookApplication) getApplication()).getAppContract());
        mDevices = new AppContract.Devices(((HookApplication)getApplication()).getAppContract());
        mMySharePreferences = ((HookApplication)getApplication()).getMySharePreferences();
        mAuthenticationManager = ((HookApplication)getApplication()).getAuthenticationManagerHelper();
        mEtag = mMySharePreferences.getStringPreference(MESSAGES_ETAG);
        mLog.d(LOG_TAG, "Service created mEtag " + mEtag);

    }

    /**
     * On destroy.
     */
    @Override
    /**
     * Logging-only destructor.
     */
    public void onDestroy() {
        super.onDestroy();
        mLog.d(LOG_TAG, "Service destroyed");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent !=null){
            String action = intent.getStringExtra(PARAM_ACTION);
            mLog.d(LOG_TAG, "onStartCommand action " + action);
            if (ACTION_START_SCANNING.equalsIgnoreCase(action)) {
                mLog.d(LOG_TAG, "onStartCommand ACTION_START_SCANNING");
                startMessagesScanning(false);

            } else if (ACTION_STOP_SCANNING.equalsIgnoreCase(action)){
                mLog.d(LOG_TAG, "onStartCommand ACTION_STOP_SCANNING");
                stopMessagesScanning();

            } else if (ACTION_CLEAR_CACHE.equalsIgnoreCase(action)){
                mLog.d(LOG_TAG, "onStartCommand ACTION_CLEAR_CACHE");

            }
        }

        return START_STICKY;
    }


    /**
     * Override this method with the callback logic for your job. Any such logic needs to be
     * performed on a separate thread, as this function is executed on your application's main
     * thread.
     *
     * @param params Parameters specifying info about this job, including the extras bundle you
     *               optionally provided at job-creation time.
     * @return True if your service needs to process the work (on a separate thread). False if
     * there's no more work to be done for this job.
     */
    @Override
    public boolean onStartJob(final JobParameters params) {
        mLog.d(LOG_TAG, "onStartJob ");
        if (mStartMessagesScanning){
            mLog.d(LOG_TAG, "onStartJob already in progress");
            jobFinished(params, true);
        } else {
            // Uses a handler to delay the execution of jobFinished().
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mLog.d(LOG_TAG, "onStartJob startMessagesScanning");
                    startMessagesScanning(getResources().getBoolean(R.bool.enable_messages_notification));
                    mLog.d(LOG_TAG, "onStartJob jobFinished");
                    jobFinished(params, true);
                }
            }, 500);
        }
        return true;
    }

    /**
     * This method is called if the system has determined that you must stop execution of your job
     * even before you've had a chance to call {@link #jobFinished(JobParameters, boolean)}.
     * <p>
     * <p>This will happen if the requirements specified at schedule time are no longer met. For
     * example you may have requested WiFi with
     * {@link JobInfo.Builder#setRequiredNetworkType(int)}, yet while your
     * job was executing the user toggled WiFi. Another example is if you had specified
     * {@link JobInfo.Builder#setRequiresDeviceIdle(boolean)}, and the phone left its
     * idle maintenance window. You are solely responsible for the behaviour of your application
     * upon receipt of this message; your app will likely start to misbehave if you ignore it. One
     * immediate repercussion is that the system will cease holding a wakelock for you.</p>
     *
     * @param params Parameters specifying info about this job.
     * @return True to indicate to the JobManager whether you'd like to reschedule this job based
     * on the retry criteria provided at job creation-time. False to drop the job. Regardless of
     * the value returned, your job must stop executing.
     */
    @Override
    public boolean onStopJob(JobParameters params) {
        mLog.d(LOG_TAG, "onStopJob ");
        stopMessagesScanning();
        return true;
    }

    /**
     * This method start the retrive new messages from the server</p>
     *
     * @param bNotify
     */
    private void startMessagesScanning(final boolean bNotify) {
        Thread thread = new Thread(new Runnable(){
            public void run() {
                if (mAuthenticationManager.isAuthenticated() && !mStartMessagesScanning) {
                    mLog.d(LOG_TAG, "startMessagesScanning bNotify " + bNotify + " etag " + mEtag);
                    mStartMessagesScanning = true;
                    Intent intentResult = new Intent(MessagesManager.INTENT_ACTION_MESSAGES_SCANNING_STARTED);
                    intentResult.setPackage(getApplicationContext().getPackageName());
                    sendBroadcast(intentResult);
                    // TODO will be remove later when etag will be managed ny the server
                    getContentResolver().delete(mMessages.getContentUri(),
                            AppContract.Messages.COLUMN_ITEM_TYPE + "=?", new String[]{String.valueOf(AppContract.Messages.MSG_RECEIVED)});

                    if (!mStartMessagesScanning) {
                        mLog.d(LOG_TAG, "startMessagesScanning break!");
                        return;
                    }

                    String previousEtag = mEtag;
                    if (getResources().getBoolean(R.bool.enable_all_messages)) {
                        mEtag = mMessagesBackendHelper.getAllMessages(mEtag);
                    } else {
                        mEtag = mMessagesBackendHelper.getMessages(getUserList(), mEtag);
                    }

                    mLog.d(LOG_TAG, "startMessagesScanning ended mEtag " + mEtag);
                    if (TextUtils.isEmpty(mEtag)) {
                        intentResult = new Intent(MessagesManager.INTENT_ACTION_MESSAGES_SCANNING_FAILED);
                        intentResult.putExtra(MessagesManager.INTENT_MESSAGES_SCANNING_ERROR, -1);
                        intentResult.setPackage(getApplicationContext().getPackageName());
                        sendBroadcast(intentResult);
                    } else {
                        intentResult = new Intent(MessagesManager.INTENT_ACTION_MESSAGES_SCANNING_SUCCEED);
                        intentResult.setPackage(getApplicationContext().getPackageName());
                        sendBroadcast(intentResult);
                    }
                    // save etag into pref
                    mMySharePreferences.saveStringPreference(MESSAGES_ETAG, mEtag);
                    mStartMessagesScanning = false;

                    // check if new messages has arrived
                    if (bNotify && !previousEtag.equalsIgnoreCase(mEtag)){
                        mLog.d(LOG_TAG, "startMessagesScanning new messages has arrived, showMessageNotification ");
                        ((HookApplication)getApplication()).showMessageNotification(
                                HookApplication.MESSAGES_NOTIFICATION_ID, getString(R.string.new_message));
                    }
                } else {
                    mLog.i(LOG_TAG, "startMessagesScanning user not authenticated, no ignore ");
                }
            }
        });
        thread.start();


    }

    private void stopMessagesScanning() {
        mLog.d(LOG_TAG, "stopMessagesScanning");
        mStartMessagesScanning = false;
    }

    private List<String> getUserList(){
        Cursor cursor = null;
        List<String> listUserId = null;
        try{
            cursor = getContentResolver().query(mDevices.getContentUri(),
                    null, AppContract.Devices.COLUMN_STATUS + "=? OR " + AppContract.Devices.COLUMN_STATUS + "=?"
                    , new String[]{String.valueOf(DEVICE_ACCEPTED),String.valueOf(DEVICE_PENDING)},
                    AppContract.Devices.COLUMN_DATE_CREATION + " DESC");
            if (cursor.moveToFirst()) {
                listUserId = new ArrayList<>();
                do {
                    String adr = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_ADDRESS));
                    String userId = cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Devices.COLUMN_USER_ID));
                    mLog.d(LOG_TAG, "getUserList adr " + adr + " userId " + userId);
                    if (TextUtils.isEmpty(userId)){
                        mLog.i(LOG_TAG, "getUserList retrieve user id from the server ");

                    } else {
                        Intent intentResult = new Intent(MessagesManager.INTENT_ACTION_MESSAGES_SCANNING_PROGRESS);
                        intentResult.setPackage(getApplicationContext().getPackageName());
                        intentResult.putExtra(MessagesManager.INTENT_MESSAGES_SCANNING_USER_MESSAGES, userId);
                        sendBroadcast(intentResult);
                        listUserId.add(userId);
                    }


                } while (cursor.moveToNext());
            } else {
                mLog.i(LOG_TAG, "getUserList moveToFirst empty cursor ");
            }
        } catch (Exception e){
            mLog.e(LOG_TAG, "getUserList Exception ", e);
        } finally {
            if (cursor !=null){
                cursor.close();
            }
        }

        return listUserId;

    }


}

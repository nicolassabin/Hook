/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.core.devices.DeviceInfo;

import static android.os.Build.VERSION_CODES.JELLY_BEAN_MR2;

/**
 * The Class WifiBtStatusProvider.
 */
public class WifiBtStatusProvider {

    /** The Constant LOG_TAG. */
    private static final String LOG_TAG = "WifiBtStatusProvider";

    /** The Constant NETWORK_TYPE_MOBILE. */
    public static final String NETWORK_TYPE_MOBILE = "MOBILE";

    /** The Constant NETWORK_TYPE_WIFI. */
    public static final String NETWORK_TYPE_WIFI = "WIFI";

    /** The Constant WAIT_TIMEOUT. */
    private static final int WAIT_TIMEOUT = 20000;


    /** The m wifi manager. */
    private final WifiManager mWifiManager;

    /** The m connectivity manager. */
    private final ConnectivityManager mConnectivityManager;

    /** The m telephony manager. */
    private final TelephonyManager mTelephonyManager;

    /** The m log. */
    private Log mLog;

    /** The m Context. */
    private Context mContext;

    /** The m content resolver. */
    private final ContentResolver mContentResolver;


    /** The m BluetoothAdapter. */
    private BluetoothAdapter mBluetoothAdapter;

    /** The m btDeviceInfo. */
    private DeviceInfo mBtDeviceInfo = null;

    /** The m Object. */
    private Object mLock = new Object();


    /**
     * Instantiates a new wifi status provider.
     * @param context the context
     */
    public WifiBtStatusProvider(final Context context) {
        mLog.d(LOG_TAG, "WifiBtStatusProvider()");
        mContext = context;
        mWifiManager = (WifiManager) mContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mConnectivityManager = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        mTelephonyManager = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
        mContentResolver = mContext.getContentResolver();
        if (Build.VERSION.SDK_INT >= JELLY_BEAN_MR2){
            BluetoothManager bluetoothManager = (BluetoothManager) mContext.getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager != null){
                mBluetoothAdapter = bluetoothManager.getAdapter();
            }
        } else {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        }


    }

    /**
     * Checks if is wifi connected.
     * @return true, if is wifi connected
     */
    public boolean isWifiConnected() {
        boolean ret = false;
        final WifiInfo info = mWifiManager.getConnectionInfo();
        // JB returns empty string for info.getSSID()
        // Add a fix for VZCUAT-682 the galaxy S4 is returning ssid : 0x when wifi is not connected (the IP would be
        // 0.0.0.0)
        // see link for http://compnetworking.about.com/od/workingwithipaddresses/g/0_0_0_0_ip-address.htm
        if (mWifiManager.isWifiEnabled() && info != null && info.getSSID() != null && !info.getSSID().equals("")) {
            final int addr = info.getIpAddress();
            ret = (addr != 0);
            mLog.d(LOG_TAG, "isWifiConnected(): " + ret);
        } else {
            mLog.d(LOG_TAG, "isWifiConnected(): false, IP=0.0.0.0");
        }

        return ret;

    }

    /**
     * return WifiDeviceInfo
     * @return DeviceInfo, null if not connected to the wifi
     */
    public DeviceInfo getWifiDeviceInfo() {
        DeviceInfo wifiDeviceInfo = null;
        if (isWifiConnected()){
            wifiDeviceInfo = new DeviceInfo(mWifiManager.getConnectionInfo().getBSSID(),
                    mWifiManager.getConnectionInfo().getBSSID(),
                    mWifiManager.getConnectionInfo().getSSID(), mWifiManager.getConnectionInfo().getSSID(), null /* no need userID here*/);
            mLog.d(LOG_TAG, "getWifiDeviceInfo name " + wifiDeviceInfo.getName()
                    + " address" + wifiDeviceInfo.getAdr());
        }

        return wifiDeviceInfo;
    }

    /**
     * return BtDeviceInfo
     * @return DeviceInfo, null if not connected to the wifi
     */
    public DeviceInfo getBtDeviceInfo() {

        mBtDeviceInfo = null;
        if (mBluetoothAdapter != null){
            /*BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            Object bluetoothManagerService = new Mirror().on(bluetoothAdapter).get().field("mService");
            if (bluetoothManagerService == null) {
                mLog.w(LOG_TAG, "getBtDeviceInfo couldn't find bluetoothManagerService");
                return null;
            }
            Object address = new Mirror().on(bluetoothManagerService).invoke().method("getAddress").withoutArgs();
            if (address != null && address instanceof String) {
                mLog.w(LOG_TAG, "getBtDeviceInfo using reflection to get the BT MAC address: " + address);
                mBtDeviceInfo = new DeviceInfo((String) address,
                        (String) address, mBluetoothAdapter.getName(), mBluetoothAdapter.getName(), null);
                mLog.d(LOG_TAG, "getBtDeviceInfo name " + mBtDeviceInfo.getName()
                        + " address " + mBtDeviceInfo.getAdr());
                return mBtDeviceInfo;
            } else {
                return null;
            }*/

            if (!mBluetoothAdapter.isEnabled()){
                mLock = new Object();
                IntentFilter i = new IntentFilter();
                i.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
                mContext.registerReceiver(new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        String action = intent.getAction();
                        mLog.d(LOG_TAG, "onReceive action " + action);
                        if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)){
                            int status = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
                            mLog.d(LOG_TAG, "onReceive status " + status);
                            if (status == BluetoothAdapter.STATE_ON) {
                                mBtDeviceInfo = new DeviceInfo(mBluetoothAdapter.getAddress(),
                                        mBluetoothAdapter.getAddress(), mBluetoothAdapter.getName(), mBluetoothAdapter.getName(), null);
                                mLog.d(LOG_TAG, "getBtDeviceInfo name " + mBtDeviceInfo.getName()
                                        + " address " + mBtDeviceInfo.getAdr());

                                synchronized (mLock) {
                                    mLock.notifyAll();
                                }
                                mContext.unregisterReceiver(this);
                            }
                        }

                    }
                }, i);
                mBluetoothAdapter.enable();
                try {
                    synchronized (mLock) {
                        mLock.wait(WAIT_TIMEOUT);
                    }
                } catch (InterruptedException e) {
                    mLog.e(LOG_TAG, "getBtDeviceInfo InterruptedException", e);
                }
            } else {
                String macBtAddress = android.provider.Settings.Secure.getString(mContext.getContentResolver(), "bluetooth_address");
                mLog.d(LOG_TAG, "getBtDeviceInfo macBtAddress " + macBtAddress);
                if (!TextUtils.isEmpty(macBtAddress) && !macBtAddress.equalsIgnoreCase(mBluetoothAdapter.getAddress())){
                    mBtDeviceInfo = new DeviceInfo(macBtAddress,
                            macBtAddress, mBluetoothAdapter.getName(), mBluetoothAdapter.getName(), null);
                }else {
                  mBtDeviceInfo = new DeviceInfo(mBluetoothAdapter.getAddress(),
                                  mBluetoothAdapter.getAddress(), mBluetoothAdapter.getName(), mBluetoothAdapter.getName(), null);
                          mLog.d(LOG_TAG, "getBtDeviceInfo macBtAddress " + macBtAddress);
                }
                mLog.d(LOG_TAG, "getBtDeviceInfo mBtDeviceInfo.getAdr " + mBtDeviceInfo.getAdr());
             }

        } else {
            mLog.e(LOG_TAG, "getBtDeviceInfo invalid mBluetoothAdapter");
        }

        return mBtDeviceInfo;
    }

    /**
     * Checks if is any network available.
     * @return true, if is any network available
     */
    public boolean isAnyNetworkAvailable() {
        NetworkInfo ni = null;
        if (mConnectivityManager != null) {
            ni = mConnectivityManager.getActiveNetworkInfo();
        }

        return ni != null && ni.isConnected();
    }

    /**
     * Gets the network connection type.
     * @return the network connection type
     */
    public int getNetworkConnectionType() {
        NetworkInfo ni = null;
        if (mConnectivityManager != null) {
            ni = mConnectivityManager.getActiveNetworkInfo();
        }

        if (ni != null && ni.isConnected()) {
            return ni.getType();
        }
        return -1;
    }

    /**
     * Checks if is mobile available.
     * @return true, if is mobile available
     */
    public boolean isMobileAvailable() {
        final NetworkInfo mobileNetworkInfo = mConnectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return mobileNetworkInfo != null && mobileNetworkInfo.isConnected();
    }

    /**
     * Check data connection established.
     * @return true, if successful
     */
    public boolean checkDataConnectionEstablished() {
        final NetworkInfo[] nets = getAllNetworkInfo();
        if(nets != null) {
            for (final NetworkInfo net : nets) {
                if (NETWORK_TYPE_MOBILE.equalsIgnoreCase(net.getTypeName()) && net.isConnected()) {
                    return true;
                }
                if (NETWORK_TYPE_WIFI.equalsIgnoreCase(net.getTypeName()) && net.isConnected()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks if is wifi connected.
     * @return true, if is wifi connected
     */
    public boolean checkWiFiConnectionEstablished() {
        final NetworkInfo[] nets = getAllNetworkInfo();
        if(nets != null) {
            for (final NetworkInfo net : nets) {
                if (NETWORK_TYPE_WIFI.equalsIgnoreCase(net.getTypeName()) && net.isConnected()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Check mobile connection established.
     * @return true, if successful
     */
    public boolean checkMobileConnectionEstablished() {
        final NetworkInfo[] nets = getAllNetworkInfo();
        if(nets != null) {
            for (final NetworkInfo net : nets) {
                // @bug using "equals" will miss other mobile network types
                // what are other network types? didn't see other types
                if (NETWORK_TYPE_MOBILE.equalsIgnoreCase(net.getTypeName()) && (net.isConnected() || net.isAvailable())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets the wifi sleep policy.
     * @return the wifi sleep policy
     */
    public int getWifiSleepPolicy() {
        return Settings.System.getInt(mContentResolver, Settings.System.WIFI_SLEEP_POLICY,
                Settings.System.WIFI_SLEEP_POLICY_DEFAULT);
    }

    /**
     * Gets the wifi sleep policy name.
     * @return the wifi sleep policy name
     */
    public String getWifiSleepPolicyName() {
        switch (getWifiSleepPolicy()) {
            case Settings.System.WIFI_SLEEP_POLICY_DEFAULT:
                return "WIFI_SLEEP_POLICY_DEFAULT";
            case Settings.System.WIFI_SLEEP_POLICY_NEVER_WHILE_PLUGGED:
                return "WIFI_SLEEP_POLICY_NEVER_WHILE_PLUGGED";
            case Settings.System.WIFI_SLEEP_POLICY_NEVER:
                return "WIFI_SLEEP_POLICY_NEVER";
            default:
                return "";
        }
    }

    /**
     * Return NetworkInfo
     * @return
     */
    private NetworkInfo[] getAllNetworkInfo() {
        try {
            return mConnectivityManager.getAllNetworkInfo();
        } catch(Exception e) {
            mLog.e(LOG_TAG, "Can't get getAllNetworkInfo(), ", e);
        }
        return null;
    }
}

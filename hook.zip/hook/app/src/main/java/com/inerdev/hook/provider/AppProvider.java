/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.provider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.Build;
import android.provider.BaseColumns;
import android.text.TextUtils;
import android.util.Log;

import com.inerdev.hook.HookApplication;


/**
 * The Class AppProvider.
 */
public class AppProvider extends ContentProvider {

    /** The m database helper. */
    AppDatabase mDatabaseHelper;

    /** The m uri matcher. */
    UriMatcher mUriMatcher;

    Context mContext;

    /** The m content resolver. */
    ContentResolver mContentResolver;

    /** The m mSelectionBuilder. */
    SelectionBuilder mSelectionBuilder = new SelectionBuilder();;

    // The constants below represent individual URI routes, as IDs. Every URI pattern recognized by
    // this ContentProvider is defined using mUriMatcher.addURI(), and associated with one of these
    // IDs.
    //
    // When a incoming URI is run through mUriMatcher, it will be tested against the defined
    // URI patterns, and the corresponding route ID will be returned.

    /** The Constant ROUTE_MESSAGES. */
    public static final int ROUTE_MESSAGES = 1;

    /** The Constant ROUTE_MESSAGES_ID. */
    public static final int ROUTE_MESSAGES_ID = 2;

    /** The Constant ROUTE_DEVICES. */
    public static final int ROUTE_DEVICES = 3;

    /** The Constant ROUTE_DEVICES_ID. */
    public static final int ROUTE_DEVICES_ID = 4;

    /** The m initialized. */
    private boolean mInitialized;

    /** The Constant TAG. */
    private static final String TAG = "AppProvider";

    /** The m log. */
    private Log mLog;

    /**
     * Inits the uri matcher.
     * @param authority the authority
     */
    private void initUriMatcher(final String authority) {
        mUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        mUriMatcher.addURI(authority, "messages", ROUTE_MESSAGES);
        mUriMatcher.addURI(authority, "messages/*", ROUTE_MESSAGES_ID);
        mUriMatcher.addURI(authority, "devices", ROUTE_DEVICES);
        mUriMatcher.addURI(authority, "devices/*", ROUTE_DEVICES_ID);
    }

    /**
     * On create.
     * @return true, if successful
     */
    @Override
    public boolean onCreate() {
        mContext = getContext();
        mDatabaseHelper = new AppDatabase(mContext, mLog);
        mContentResolver = mContext.getContentResolver();
        return true;
    }

    /**
     * Inits the if necessary.
     */
    public void initIfNecessary() {
        if (!mInitialized) {
            initUriMatcher(mContext.getPackageName() + AppContract.AUTHORITHY_SUFFIX);
            mInitialized = true;
        }
    }

    /**
     * Gets the type.
     * @param uri the uri
     * @return the type
     */
    @Override
    public String getType(final Uri uri) {
        initIfNecessary();
        final int match = mUriMatcher.match(uri);
        switch (match) {
            case ROUTE_MESSAGES:
                return AppContract.Messages.CONTENT_TYPE;
            case ROUTE_MESSAGES_ID:
                return AppContract.Messages.CONTENT_ITEM_TYPE;
            case ROUTE_DEVICES:
                return AppContract.Devices.CONTENT_TYPE;
            case ROUTE_DEVICES_ID:
                return AppContract.Devices.CONTENT_ITEM_TYPE;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
    }

    /**
     * Query.
     * @param uri the uri
     * @param projection the projection
     * @param selection the selection
     * @param selectionArgs the selection args
     * @param sortOrder the sort order
     * @return the cursor
     */
    @Override
    public Cursor query(final Uri uri, final String[] projection, final String selection, final String[] selectionArgs, final String sortOrder) {
        initIfNecessary();

        final SQLiteDatabase db = mDatabaseHelper.getReadableDatabase();
        final int uriMatch = mUriMatcher.match(uri);
        mSelectionBuilder.reset();
        switch (uriMatch) {
            case ROUTE_MESSAGES_ID:
                // Return a single repository, by ID.
                String id = uri.getLastPathSegment();
                mSelectionBuilder.where(BaseColumns._ID + "=?", id);
            case ROUTE_MESSAGES:
                // Return all known files.
                mSelectionBuilder.table(AppContract.Messages.TABLE_NAME).where(selection, selectionArgs);
                Cursor c = mSelectionBuilder.query(db, projection, sortOrder);
                // Note: Notification URI must be manually set here for loaders to correctly
                // register ContentObservers.
                c.setNotificationUri(mContentResolver, uri);
                return c;
            case ROUTE_DEVICES_ID:
                // Return a single file, by ID.
                id = uri.getLastPathSegment();
                mSelectionBuilder.where(BaseColumns._ID + "=?", id);
            case ROUTE_DEVICES:
                // Return all known files.
                mSelectionBuilder.table(AppContract.Devices.TABLE_NAME).where(selection, selectionArgs);
                c = mSelectionBuilder.query(db, projection, sortOrder);
                // Note: Notification URI must be manually set here for loaders to correctly
                // register ContentObservers.
                c.setNotificationUri(mContentResolver, uri);
                return c;
            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }

    }

    /**
     * Insert.
     * @param uri the uri
     * @param values the values
     * @return the uri
     */
    @Override
    public Uri insert(final Uri uri, final ContentValues values) {
        long rowId = -1;
        initIfNecessary();
        SQLiteDatabase db = mDatabaseHelper.getWritableDatabase();
        final int uriMatch = mUriMatcher.match(uri);
        switch (uriMatch)
        {
            case ROUTE_MESSAGES:
                rowId = db.insert(AppContract.Messages.TABLE_NAME, null, values);
                break;
            case ROUTE_DEVICES:
                rowId = db.insert(AppContract.Devices.TABLE_NAME, null, values);
                break;
            default:
                throw new IllegalArgumentException("insert() Unknown URL " + uri);
        }

        if (rowId > -1){
            return Uri.withAppendedPath(uri, String.valueOf(rowId));
        }

        return uri;
    }

    /**
     * Delete.
     * @param uri the uri
     * @param selection the selection
     * @param selectionArgs the selection args
     * @return the int
     */
    @Override
    public int delete(final Uri uri, final String selection, final String[] selectionArgs) {
        int count;
        initIfNecessary();
        SQLiteDatabase db = mDatabaseHelper.getWritableDatabase();
        String segment;
        final int uriMatch = mUriMatcher.match(uri);
        switch (uriMatch) {
            case ROUTE_MESSAGES:
                count = db.delete(AppContract.Messages.TABLE_NAME, selection, selectionArgs);
                break;
            case ROUTE_MESSAGES_ID:
                segment = uri.getLastPathSegment();
                count = db.delete(AppContract.Messages.TABLE_NAME,
                        getWhereClause(segment, selection), selectionArgs);
                break;
            case ROUTE_DEVICES:
                count = db.delete(AppContract.Devices.TABLE_NAME, selection, selectionArgs);
                break;
            case ROUTE_DEVICES_ID:
                segment = uri.getLastPathSegment();
                count = db.delete(AppContract.Devices.TABLE_NAME, getWhereClause(segment, selection), selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("delete() Unknown URL " + uri);
        }

        return count;
    }

    /**
     * Update a MESSAGES/DEVICES in the database by URI.
     * @param uri the uri
     * @param values the values
     * @param selection the selection
     * @param selectionArgs the selection args
     * @return the int
     */
    @Override
    public int update(final Uri uri, final ContentValues values, final String selection, final String[] selectionArgs) {
        String segment = null;

        int count = 0;
        initIfNecessary();
        SQLiteDatabase db = mDatabaseHelper.getWritableDatabase();

        final int uriMatch = mUriMatcher.match(uri);
        switch (uriMatch) {
            case ROUTE_MESSAGES_ID:
                segment = uri.getLastPathSegment();
                count = db.update(AppContract.Messages.TABLE_NAME, values, getWhereClause(segment, selection), selectionArgs);
                break;
            case ROUTE_MESSAGES:
                count = db.update(AppContract.Messages.TABLE_NAME, values, selection, selectionArgs);
                break;
            case ROUTE_DEVICES:
                count = db.update(AppContract.Devices.TABLE_NAME, values, selection, selectionArgs);
                break;
            case ROUTE_DEVICES_ID:
                segment = uri.getLastPathSegment();
                count = db.update(AppContract.Devices.TABLE_NAME, values, getWhereClause(segment, selection), selectionArgs);
                break;
        }

        if(count > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return count;
    }

    /**
     * Get where clause from id and selection
     * @param segment
     * @param selection
     * @return String
     */
    protected String getWhereClause(final String segment, final String selection) {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(BaseColumns._ID).append("=").append(segment);
        if(!TextUtils.isEmpty(selection)) {
            stringBuilder.append(" AND (").append(selection).append(")");
        }
        return stringBuilder.toString();
    }

}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;


import com.inerdev.hook.R;

import java.lang.ref.WeakReference;

/**
 * The Class SwiperControl.
 */
public class SwiperControl extends LinearLayout implements ViewPager.OnPageChangeListener, View.OnTouchListener {

    /** The default auto scroll time in milliseconds */
    public static final int AUTO_SCROLL_DEFAULT_INTERVAL = 1500;
    public static final int AUTO_SCROLL_LEFT = 0;
    public static final int AUTO_SCROLL_RIGHT = 1;


    /** The context. */
    private final Context mContext;

    /** The ViewPager. */
    private ViewPager mViewPager;

    /** The mCurrentItem. */
    private final int mCurrentItem = 1;

    /** The prev position. */
    private final int mPrevPosition = -1;

    /** The page change listner. */
    private SwipePageListener mPageChangeListner;

    /** The circle page indicator. */
    private CirclePageIndicator mCirclePageIndicator;

    /** The auto scroll time in milliseconds, default is {@link #AUTO_SCROLL_DEFAULT_INTERVAL} **/
    private long mAutoScrollInterval = AUTO_SCROLL_DEFAULT_INTERVAL;

    /** The auto scroll direction, default is {@link #AUTO_SCROLL_RIGHT} **/
    private int mAutoScrollDirection = AUTO_SCROLL_RIGHT;

    /** Whether automatic cycle when auto scroll reaching the last or first item, default is true **/
    private boolean mIsAutoScrollCycle = true;

    /** Whether stop auto scroll when touching, default is true **/
    private boolean mStopScrollWhenTouch = true;

    /** Auto scroll stopped by touch */
    private boolean mIsStoppedByTouch = false;

    /** Auto scroll handler */
    private final Handler mAutoScrollHandler = new AutoScrollHandler(this);

    /** If true viewpager doing auto scroll*/
    private boolean mIsAutoScroll = false;

    public static final int SCROLL_WHAT = 0x4651;

    /**
     * Instantiates a new swiper control.
     * @param context the context
     * @param attrs the attrs
     */
    public SwiperControl(final Context context, final AttributeSet attrs) {
        super(context, attrs);
        mContext = context;

        initView();

        final TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.UIWidgetsSwiperControl);
        if(a != null) {
            mIsAutoScroll = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScroll, mIsAutoScroll);
            mIsAutoScrollCycle = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScrollCycle, mIsAutoScrollCycle);
            mIsStoppedByTouch = a.getBoolean(R.styleable.UIWidgetsSwiperControl_autoScrollStoppedByTouch, mIsStoppedByTouch);
            mAutoScrollDirection = a.getInteger(R.styleable.UIWidgetsSwiperControl_autoScrollDirection, mAutoScrollDirection);
            mAutoScrollInterval = a.getInteger(R.styleable.UIWidgetsSwiperControl_autoScrollInterval, (int) mAutoScrollInterval);
            if (mIsAutoScroll) {
                startAutoScroll();
            }
            a.recycle();
        }
    }

    /**
     * Inits the view.
     */
    private synchronized void initView() {
        final LayoutInflater vi = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        vi.inflate(R.layout.uiwidgets_swiper_control, this, true);
        // initialize the inner controls
        mViewPager = (ViewPager) findViewById(R.id.swipe_flipper);
        mViewPager.setClickable(false);
        mViewPager.setOnTouchListener(this);
    }

    /**
     * Sets the adapter.
     * @param adapter the new adapter
     */
    public void setAdapter(final PagerAdapter adapter) {
        mViewPager.setAdapter(adapter);
        mCirclePageIndicator = (CirclePageIndicator) findViewById(R.id.indicator);
        final CirclePager indicator = mCirclePageIndicator;
        indicator.setViewPager(mViewPager);
        indicator.setOnPageChangeListener(this);

        if (adapter.getCount() < 2) {
            ((CirclePageIndicator) indicator).setVisibility(View.GONE);
        }
    }

    /**
     * Gets the circle page indicator.
     * @return the indicator
     */
    public CirclePageIndicator getCirclePageIndicator() {
        return mCirclePageIndicator;
    }

    /**
     * Gets the num views.
     * @return the num views
     */
    public int getNumViews() {
        return mViewPager.getAdapter().getCount();
    }

    /**
     * Sets the page change listner.
     * @param pageChangeListner the new page change listner
     */
    public void setPageChangeListner(final SwipePageListener pageChangeListner) {
        this.mPageChangeListner = pageChangeListner;
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener#onPageScrolled(int, float, int)
     */
    @Override
    public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {
        if (mPageChangeListner != null) {
            mPageChangeListner.onPageScrolled(position, positionOffset, positionOffsetPixels);
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener#onPageSelected(int)
     */
    @Override
    public void onPageSelected(final int position) {
        if (mPageChangeListner != null) {
            mPageChangeListner.onPageSelected(position);
        }
    }

    /**
     * @see android.support.v4.view.ViewPager.OnPageChangeListener#onPageScrollStateChanged(int)
     */
    @Override
    public void onPageScrollStateChanged(final int state) {
        if (mPageChangeListner != null) {
            mPageChangeListner.onPageScrollStateChanged(state);
        }
    }

    /**
     * Start auto scroll
     */
    public void startAutoScroll() {
        mIsAutoScroll = true;
        sendScrollMessage(mAutoScrollInterval);
    }

    /**
     * Start auto scroll
     *
     * @param delayTimeInMills first scroll delay time
     */
    public void startAutoScroll(int delayTimeInMills) {
        mIsAutoScroll = true;
        mAutoScrollInterval = delayTimeInMills;
        sendScrollMessage(mAutoScrollInterval);
    }

    /**
     * Stop auto scroll
     */
    public void stopAutoScroll() {
        mIsAutoScroll = false;
        mAutoScrollHandler.removeMessages(SCROLL_WHAT);
    }

    /**
     * Send delayed message for scrolling to the next page
     * @param delayTimeInMills
     */
    private void sendScrollMessage(long delayTimeInMills) {
        /** remove messages before, keeps one message is running at most **/
        mAutoScrollHandler.removeMessages(SCROLL_WHAT);
        mAutoScrollHandler.sendEmptyMessageDelayed(SCROLL_WHAT, delayTimeInMills);
    }

    /**
     * Scroll only once
     * @return true if view scrolled, false if not
     */
    public boolean scrollOnce() {
        final PagerAdapter adapter = mViewPager.getAdapter();
        int currentItem = mViewPager.getCurrentItem();
        int totalCount;
        if (adapter == null || (totalCount = adapter.getCount()) <= 1) {
            return false;
        }

        int nextItem = (mAutoScrollDirection == AUTO_SCROLL_LEFT) ? --currentItem : ++currentItem;
        if (nextItem < 0) {
            if (mIsAutoScrollCycle) {
                mViewPager.setCurrentItem(totalCount - 1, true);
                return true;
            }
        } else if (nextItem == totalCount) {
            if (mIsAutoScrollCycle) {
                mViewPager.setCurrentItem(0, true);
                return true;
            }
        } else {
            mViewPager.setCurrentItem(nextItem, true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        final int action = MotionEventCompat.getActionMasked(motionEvent);
        if (mStopScrollWhenTouch) {
            if (action == MotionEvent.ACTION_DOWN) {
                if (mIsAutoScroll) {
                    mIsStoppedByTouch = true;
                    stopAutoScroll();
                }
                else
                if (mIsStoppedByTouch) {
                    mIsStoppedByTouch = false;
                    startAutoScroll();
                }
            }
        }

        return false;
    }

    private static class AutoScrollHandler extends Handler {

        private final WeakReference<SwiperControl> mSwiperControlWeakReference;

        public AutoScrollHandler(SwiperControl autoScrollViewPager) {
            this.mSwiperControlWeakReference = new WeakReference<SwiperControl>(autoScrollViewPager);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case SCROLL_WHAT:
                    SwiperControl pager = mSwiperControlWeakReference.get();
                    if (pager != null) {
                        pager.scrollOnce();
                        pager.sendScrollMessage(pager.mAutoScrollInterval);
                    }
                default:
                    break;
            }
        }
    }
}

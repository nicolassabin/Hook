package com.inerdev.hook.ui.messages;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.core.messages.MessagesBackendHelper;
import com.inerdev.hook.provider.AppContract;
import com.inerdev.hook.ui.AbstractFragment;
import com.inerdev.hook.ui.MainActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


public abstract class BMsgFragment extends AbstractFragment implements MainActivity.IActionFragment, AbstractFragment.ActionMenu {

    private static final String TAG = "BMsgFragment - ";
    protected AsyncTask<Void, Void, Void> mAsyncTask = null;
    protected Cursor mCursor = null;
    protected AppContract.Messages mMessage;
    protected MessagesCursorAdapter mAdapter = null;
    protected int mMsgType;
    protected boolean mSelectionEnable = false;
    protected MessagesBackendHelper mMessagesBackendHelper;
    protected AuthenticationManager mAuthenticationManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        mMessage = new AppContract.Messages(((HookApplication)getActivity().getApplication()).getAppContract());
        mAuthenticationManager = ((HookApplication)getActivity().getApplication()).getAuthenticationManagerHelper();
        super.onCreate(savedInstanceState);
        mMessagesBackendHelper = new MessagesBackendHelper(getActivity());


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                mSelectionEnable = true;
                refreshData();
                return false;
            }
        });
        return rootView;
    }

    /**
     * Called when the Fragment is visible to the user.  This is generally
     * tied to {@link Activity#onStart() Activity.onStart} of the containing
     * Activity's lifecycle.
     */
    @Override
    public void onStart() {
        super.onStart();
        refreshAsync();
    }

    @Override
    public void onItemClick(int position, long id) {
        mLog.d(TAG, "onItemClick position " + position + " id " + id);
        if (!mSelectionEnable) {
            if (position != -1) {
                Intent intent = new Intent(getActivity(), ViewMessageActivity.class);
                intent.putExtra(ViewMessageActivity.ITEM_ID, id);
                startActivity(intent);
            } else {
                mLog.e(TAG, "onItemClick invalid position");
            }
        }

    }

    @Override
    public void delete() {
        mLog.d(TAG, "delete selection");
        if (!mAdapter.mSelectedItemId.isEmpty()){
            for (final Map.Entry<Long, String> e : mAdapter.mSelectedItemId.entrySet()) {
                    mLog.d(TAG, "delete deleting message from server " + e.getValue());
                    if (mMessagesBackendHelper.removeMessage(e.getValue())){
                        mLog.d(TAG, "delete deleting id " + e.getKey());
                        if (getContext().getContentResolver().delete(mMessage.getContentUri(),
                                AppContract.Messages._ID + "=?",
                                new String[]{String.valueOf(e.getKey())}) == 0){
                            mLog.e(TAG, "delete failed id " + e.getKey());
                        }
                    } else {
                        mLog.e(TAG, "delete deleting message from server failed " + e.getValue());
                    }

            }

        } else {
            mLog.i(TAG, "delete no selection");
        }

    }

    @Override
    public void deleteAll() {
        mLog.d(TAG, "deleteAll");
        // TODO delete all from server
        getContext().getContentResolver().delete(mMessage.getContentUri(),
                AppContract.Messages.COLUMN_ITEM_TYPE + "=?", new String[]{String.valueOf(mMsgType)});
    }

    @Override
    public void refresh() {
        refreshCursor();
    }

    @Override
    public void refreshData() {
        mLog.d(TAG, "refreshData");
        if (mAsyncTask == null || mAsyncTask.getStatus() == AsyncTask.Status.FINISHED){
            mAsyncTask = new AsyncTask<Void, Void, Void>() {
                final ProgressDialog uploadProgressDialog = new ProgressDialog(getActivity());

                @Override
                protected void onPreExecute() {
                    // display details of the current the groupspace
                    mLog.d(TAG, "refreshData onPreExecute");
                    uploadProgressDialog.setIndeterminate(true);
                    uploadProgressDialog.setMessage(getString(R.string.refreshing));
                    uploadProgressDialog.setCancelable(false);
                    uploadProgressDialog.show();

                }

                /**
                 * Override this method to perform a computation on a background thread. The
                 * specified parameters are the parameters passed to {@link #execute}
                 * by the caller of this task.
                 * <p>
                 * This method can call {@link #publishProgress} to publish updates
                 * on the UI thread.
                 *
                 * @param params The parameters of the task.
                 * @return A result, defined by the subclass of this task.
                 * @see #onPreExecute()
                 * @see #onPostExecute
                 * @see #publishProgress
                 */
                @Override
                protected Void doInBackground(Void... params) {
                    mLog.d(TAG, "refreshData doInBackground mMsgType " + mMsgType);
                    refreshCursor();
                    return null;
                }

                @Override
                protected void onPostExecute(Void result) {
                    mLog.d(TAG, "refreshData onPostExecute");
                    uploadProgressDialog.dismiss();
                    if (mAdapter == null) {
                        mAdapter = new MessagesCursorAdapter(getActivity(), mCursor);
                    } else {
                        mAdapter.changeCursor(mCursor);
                    }
                    mListView.setAdapter(mAdapter);

                }

            };
            mAsyncTask.execute((Void[]) null);
        }


    }

    private void refreshCursor() {
        if (getActivity() != null){
            mCursor = getActivity().getContentResolver().query(mMessage.getContentUri(),
                null, AppContract.Messages.COLUMN_ITEM_TYPE + "=?", new String[]{String.valueOf(mMsgType)}
                , AppContract.Messages.COLUMN_DATE_CREATION + " DESC");
        }

    }

    @Override
    public boolean onKeyBackDown() {
        if (mSelectionEnable)
        {
            mSelectionEnable = false;
            refreshData();
            return true;
        }
        return false;
    }


    public class MessagesCursorAdapter extends CursorAdapter {
        public MessagesCursorAdapter(Context context, Cursor cursor) {
            super(context, cursor, 0);
        }

        public Map<Long, String> mSelectedItemId = new HashMap<>();

        private class ViewHolder {
            TextView msgFrom;
            TextView msgSubject;
            TextView msgDate;
            CheckBox checked;
        }

        private class MsgInfo {
            public Long msgId;
            public String msgServerId;

            public MsgInfo(Long id, String serverId){
                msgId = id;
                msgServerId = serverId;
            }
        }

        // The newView method is used to inflate a new view and return it,
        // you don't bind any data to the view at this point.
        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return LayoutInflater.from(context).inflate(R.layout.message_item_view, parent, false);
        }

        // The bindView method is used to bind all data to a given view
        // such as setting the text on a TextView.
        @Override
        public void bindView(View view, Context context, final Cursor cursor) {
            ViewHolder viewHolder = (ViewHolder) view.getTag();

            if (viewHolder == null) {
                viewHolder = new ViewHolder();
                // Find fields to populate in inflated template
                viewHolder.msgFrom = (TextView) view.findViewById(R.id.msgFrom);
                viewHolder.msgSubject = (TextView) view.findViewById(R.id.msgSubject);
                viewHolder.msgDate = (TextView) view.findViewById(R.id.msgDate);
                viewHolder.checked = (CheckBox) view.findViewById(R.id.checkBox);

                viewHolder.checked.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        MsgInfo msgInfo = (MsgInfo) cb.getTag();
                        if (cb.isChecked()){
                            mSelectedItemId.put(msgInfo.msgId, msgInfo.msgServerId);
                        } else {
                            mSelectedItemId.remove(msgInfo.msgId);
                        }
                    }
                });
            }

            if (mSelectionEnable){
                viewHolder.checked.setVisibility(View.VISIBLE);
            } else {
                viewHolder.checked.setVisibility(View.GONE);
            }

            // Extract properties from cursor
            String from = getString(R.string.msg_view_from) + ":" + cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SENDER_NAME));
            String subject = getString(R.string.msg_view_subject) + ":" + cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SUBJECT));
            String date = getString(R.string.msg_view_date_creation) + ":" + (String)DateFormat.format("dd/MM/yyyy hh:mm", cursor.getLong(cursor.getColumnIndexOrThrow(AppContract.Messages.COLUMN_DATE_CREATION)));


            // Populate fields with extracted properties
            viewHolder.msgFrom.setText(from);
            if (subject.length() > 25){
                subject = subject.substring(25);
            }
            subject = subject.replaceAll("\r", "");
            subject = subject.replaceAll("\n", "");

            viewHolder.msgSubject.setText(subject);
            viewHolder.msgDate.setText(date);
            viewHolder.checked.setChecked(mSelectedItemId.containsKey(cursor.getLong(cursor.getColumnIndexOrThrow(AppContract.Messages._ID))));
            viewHolder.checked.setTag(new MsgInfo(
                    cursor.getLong(cursor.getColumnIndexOrThrow(AppContract.Messages._ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SERVER_ID))));
            view.setTag(viewHolder);

        }
    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.core.CoreException;
import com.inerdev.hook.core.ErrorCode;
import com.inerdev.hook.core.auth.AuthenticationException;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.core.config.ConfigHelper;


/**
 * The Class UserConnectToServer.
 */
public class UserConnectToServer {

    /** The Constant TAG. */
    private static final String TAG = "UserConnectToServer";
    // This variable will be used in future


    /** The m task. */
    private AsyncTask<Void, String, Void> mTask = null;

    /** The m context. */
    private final Context mContext;


    /** The m config helper. */
    private ConfigHelper mConfigHelper;

    /** The m log. */
    private Log mLog;

    /** The m preferences end point. */
    private final MySharePreferences mMySharePreferences;

    /** The m AuthenticationManager. */
    private final AuthenticationManager mAuthenticationManager;


    /**
     * Instantiates a new user end point impl.
     * @param context the context
     * @param app the app
     */
    public UserConnectToServer(final Context context, HookApplication app) {
        mContext = context;
        mAuthenticationManager = app.getAuthenticationManagerHelper();
        mMySharePreferences = app.getMySharePreferences();
        mConfigHelper = app.getConfigHelper();
    }


    /**
     *
     *
     */
    public void connectServer(final GuiCallback<String> callback) {
        if (mTask != null) {
            if (mTask.getStatus() != AsyncTask.Status.FINISHED) {
                final boolean cancelled = mTask.cancel(true);
                mLog.d(TAG, "cancelled=" + cancelled);
            }
            mTask = null;
        }

        mTask = new AsyncTask<Void, String, Void>() {

            private static final String LOG_TAG = "UserEndPointImpl.task";

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                callback.taskCancel(this);
            }

            @Override
            protected Void doInBackground(final Void... params) {
                mLog.d(LOG_TAG, "> doInBackground()");
                try {
                    doAuth(callback);
                } catch (CoreException e) {
                    mLog.e(LOG_TAG, "< doInBackground() CoreException", e);
                }
                mLog.d(LOG_TAG, "< doInBackground()");
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
            }

            @Override
            protected void onProgressUpdate(String... values) {

            }

            private void doAuth(final GuiCallback<String> callback) throws  CoreException{
                mLog.d(LOG_TAG, "> doAuth()");
                try {

                    if (mConfigHelper.getConfig() == null) {
                        if (mConfigHelper.retrieveConfig(null) == false) {
                            throw new CoreException(ErrorCode.OTHER_EXCEPTION,"No config downloading");
                        }
                    }

                    String token = null;
                    if (!isCancelled()) {
                        try {
                            mLog.d(LOG_TAG, "refreshToken if needed");
                            token = mAuthenticationManager.refreshAuthTokenIfNeeded();
                            mLog.d(LOG_TAG, "After refreshAccessToken");

                        } catch (final AuthenticationException e) {
                            throw new CoreException(e.getErrorCode(), e.getMessage());
                        } catch (final Exception e) {
                            throw new CoreException(ErrorCode.OTHER_EXCEPTION, e.getMessage());
                        }
                    } else {
                        mLog.d(LOG_TAG, "auth, task get canceled, just return");
                        return;
                    }


                    // if token is null, it means that nab activity was started, and we shouldn't go further (to
                    // main
                    // screen) by calling
                    // "onSuccess"
                    // After introducing VzW SSO in the VMM Client, we may also get
                    // null because of SSO (we won't continue for now and we'll be
                    // restarted by the observer service at a later time)
                    if (token != null) {
                        if (!isCancelled()) {
                            callback.onSuccess(token);
                        } else {
                            mLog.d(LOG_TAG, "task already canceled, ingore call back, token: " + token);
                        }
                    } else {
                        // null error means "pending"
                        if (!isCancelled()) {
                            callback.onError(null);
                        } else {
                            mLog.d(LOG_TAG, "token is null, and task get canceled");
                        }
                    }
                } catch (final AuthenticationException e) {
                    if (!isCancelled()) {
                        callback.onError(e);
                    } else {
                        mLog.e(LOG_TAG, "task is canceled, exception: " + e.getMessage());
                    }
                }
                mLog.d(LOG_TAG, "< doAuth()");
            }
        };
        mTask.execute();
    }

}

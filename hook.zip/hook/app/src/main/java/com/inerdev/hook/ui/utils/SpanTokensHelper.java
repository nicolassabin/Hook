/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.text.style.CharacterStyle;
import android.widget.TextView;


/**
 * The Class SpanTokensHelper.
 */
public class SpanTokensHelper {

    /**
     * Instantiates a new span tokens helper.
     */
    public SpanTokensHelper() {
    }

    /**
     * Sets the link movement method.
     * @param textView the new link movement method
     */
    public void setLinkMovementMethod(final TextView textView) {
        if (textView != null) {
            final MovementMethod movementMethod = textView.getMovementMethod();
            if ((movementMethod == null) || !(movementMethod instanceof LinkMovementMethod)) {
                textView.setMovementMethod(LinkMovementMethod.getInstance());
            }
        }
    }

    /**
     * Delete span tokens.
     * @param text the text
     * @param token the token
     * @return the char sequence
     */
    public CharSequence deleteSpanTokens(CharSequence text, final String token) {
        final int tokenLen = token.length();
        final int start = text.toString().indexOf(token) + tokenLen;
        final int end = text.toString().indexOf(token, start);

        if (start > -1 && end > -1) {
            // Copy the spannable string to a mutable spannable string
            final SpannableStringBuilder ssb = new SpannableStringBuilder(text);
            // Delete the tokens before and after the span
            ssb.delete(end, end + tokenLen);
            ssb.delete(start - tokenLen, start);

            text = ssb;
        }
        return text;

    }

    /**
     * Sets the span between tokens.
     * @param text the text
     * @param token the token
     * @param cs the cs
     * @return the char sequence
     */
    public CharSequence setSpanBetweenTokens(CharSequence text, final String token, final CharacterStyle... cs) {
        // Start and end refer to the points where the span will apply
        final int tokenLen = token.length();
        final int start = text.toString().indexOf(token) + tokenLen;
        final int end = text.toString().indexOf(token, start);

        if (start > -1 && end > -1) {
            // Copy the spannable string to a mutable spannable string
            final SpannableStringBuilder ssb = new SpannableStringBuilder(text);
            for (final CharacterStyle c : cs)
                ssb.setSpan(c, start, end, 0);

            // Delete the tokens before and after the span
            ssb.delete(end, end + tokenLen);
            ssb.delete(start - tokenLen, start);

            text = ssb;
        }
        return text;
    }

    /**
     * Gets the text between tokens.
     * @param text the text
     * @param token the token
     * @return the text between tokens
     */
    public CharSequence getTextBetweenTokens(final CharSequence text, final String token) {
        // Start and end refer to the points where the span will apply
        final int tokenLen = token.length();
        final int start = text.toString().indexOf(token) + tokenLen;
        final int end = text.toString().indexOf(token, start);
        if (start > -1 && end > -1) {
            return text.subSequence(start, end);
        }
        return null;
    }
}

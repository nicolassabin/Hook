package com.inerdev.hook.ui.utils;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.inerdev.hook.R;

/**
 * Created by nsab0001 on 02/06/2017.
 */

public class PermissionManager {

    /** The MY_ALL_PERMISSIONS_REQUEST. */
    public static final int MY_ALL_PERMISSIONS_REQUEST = 1;

    /**
     * Permissions required to BT
     */
    private static String[] PERMISSIONS_BT = {Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN};

    /**
     * Permissions required to Network
     */
    private static String[] PERMISSIONS_NETWORK = {Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE, Manifest.permission.ACCESS_NETWORK_STATE};

    private static final String TAG = "PermissionManager";

    /** The m log. */
    private Log mLog;


    /**
     * check all Permission.
     */
    public void checkAllPermission(Activity activity){
        checkPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION, PERMISSIONS_BT);
        checkPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION, PERMISSIONS_BT);
        checkPermission(activity, Manifest.permission.BLUETOOTH, PERMISSIONS_BT);
        checkPermission(activity, Manifest.permission.BLUETOOTH_ADMIN, PERMISSIONS_BT);
        checkPermission(activity, Manifest.permission.ACCESS_WIFI_STATE , PERMISSIONS_NETWORK);
        checkPermission(activity, Manifest.permission.CHANGE_WIFI_STATE, PERMISSIONS_NETWORK);
        checkPermission(activity, Manifest.permission.ACCESS_NETWORK_STATE, PERMISSIONS_NETWORK);
    }


    /**
     * check one Permission.
     */
    private void checkPermission(Activity activity,  String permission, String[] permissions){
        // Here, thisActivity is the current activity
        mLog.d(TAG, "checkPermission " + permission);
        if (ContextCompat.checkSelfPermission(activity,
                permission)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    permission)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                mLog.d(TAG, "checkPermission Show an explanation ");
                Toast.makeText (activity,
                        R.string.permissions_needed,
                        Toast.LENGTH_LONG).show ();


            } else {

                // No explanation needed, we can request the permission.
                mLog.d(TAG, "checkPermission No explanation needed, we can request the permission.");
                ActivityCompat.requestPermissions(activity,
                        permissions,
                        MY_ALL_PERMISSIONS_REQUEST);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.


            }
        }
    }


}

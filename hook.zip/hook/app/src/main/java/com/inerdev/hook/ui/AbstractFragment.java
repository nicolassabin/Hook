package com.inerdev.hook.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.CursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.inerdev.hook.R;


public abstract class AbstractFragment extends Fragment implements MainActivity.IActionFragment
{
    private static final String TAG = "AbstractFragment - ";

    protected int mId;
    protected ActionMenu mActionMenu;
    protected ListView mListView;

    /** The m log. */
    protected Log mLog;

    public interface ActionMenu {
        public void onItemClick(int position, long id);
        public void delete();
        public void deleteAll();
        public void refresh();

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onPause ()
    {
        super.onPause();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list_view_frag, container, false);
        rootView.setTag(TAG);

        // BEGIN_INCLUDE(initializeRecyclerView)
        mListView = (ListView) rootView.findViewById(R.id.mylistView);
        // BEGIN_INCLUDE(initializeRecyclerView)
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mActionMenu.onItemClick(position, id);
            }
        });
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        ((MainActivity) activity).onSectionAttached(mId);
    }


    @Override
    public boolean onKeyBackDown() {
        return false;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_delete) {

            AsyncTask<String, Void, Void> asyncTask = new AsyncTask<String, Void, Void>()
            {
                final ProgressDialog progressDialog = new ProgressDialog(getActivity());

                @Override
                protected void onPreExecute() {
                    progressDialog.setIndeterminate(true);
                    progressDialog.setMessage(getString(R.string.deleting));
                    progressDialog.setCancelable(false);
                    progressDialog.show();

                }

                @Override
                protected Void doInBackground(String... params) {
                    mActionMenu.delete();
                    return null;
                }

                @Override
                protected void onPostExecute(Void result) {
                    progressDialog.dismiss();
                    refreshData();
                }
            };
            asyncTask.execute();

            return true;
        } else if (id == R.id.action_delete_all) {
            // display details of the current the groupspace

                AsyncTask<String, Void, Void> asyncTask = new AsyncTask<String, Void, Void>()
                {
                    final ProgressDialog progressDialog = new ProgressDialog(getActivity());

                    @Override
                    protected void onPreExecute() {
                        progressDialog.setIndeterminate(true);
                        progressDialog.setMessage(getString(R.string.deleting_all));
                        progressDialog.setCancelable(false);
                        progressDialog.show();

                    }

                    @Override
                    protected Void doInBackground(String... params) {
                        mActionMenu.deleteAll();
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void result) {
                        progressDialog.dismiss();
                        refreshData();
                    }
                };
                asyncTask.execute();


                return true;
        } else if (id == R.id.action_refresh) {
            // display details of the current the groupspace
            refreshAsync();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }

    }

    protected abstract void refreshData();

    protected void refreshAsync(){
        AsyncTask<String, Void, Void> asyncTask = new AsyncTask<String, Void, Void>()
        {

            final ProgressDialog progressDialog = new ProgressDialog(getActivity());

            @Override
            protected void onPreExecute() {
                progressDialog.setIndeterminate(true);
                progressDialog.setMessage(getString(R.string.refreshing));
                progressDialog.setCancelable(false);
                progressDialog.show();

            }

            @Override
            protected Void doInBackground(String... params) {
                mLog.d(TAG, "refreshAsync doInBackground ");
                mActionMenu.refresh();
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                progressDialog.dismiss();
                mLog.d(TAG, "refreshAsync onPostExecute ");
                refreshData();
            }
        };
        asyncTask.execute();
    }


}

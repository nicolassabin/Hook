package com.inerdev.hook.core.retrofit;


import com.inerdev.hook.core.auth.AuthenticationStorage;
import com.inerdev.hook.core.retrofit.model.Message;
import com.inerdev.hook.core.retrofit.model.Messages;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by nicolas on 02/12/2016.
 */

public interface MessagesApi {

    /** The header accept atp json. */
    String APPLICATION_JSON = "application/json";

    /** The header accept devices json. */
    String HEADER_ACCEPT_DEVICES_JSON = "Accept: " + APPLICATION_JSON;

    /**
     * The header content type devices xml.
     */
    String HEADER_CONTENT_TYPE_DEVICES_JSON = "Content-Type: application/x-www-form-urlencoded";

    /**
     * get message list.
     *
     * @return - messages
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @GET("{userId}/message")
    Messages getMessages(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                         @Path("userId") String userId,
                         @Field("fromId") List<String> fromIds,
                         @Field("deviceId") List<String> deviceIds);

    /**
     * create/update message.
     *
     * @return - message
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @POST("{userId}/message")
    Message createMessage(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                        @Path("userId") String userId,
                         @Field("from") String from,
                         @Field("dateExpiration") String dateExpiration,
                         @Field("subject") String subject,
                         @Field("text") String text,
                         @Field("data1") String data1,
                         @Field("deviceId") String deviceId,
                         @Field("type") String type,
                         @Field("status") int status);

    /**
     * create/update message.
     *
     * @return - message
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @FormUrlEncoded
    @POST("{userId}/message")
    Message createMessage(@Header(AuthenticationStorage.HEADER_AUTHORIZATION) String authorizationHeaderValue,
                         @Path("userId") String userId,
                         @Body Message message);

    /**
     * delete Message.
     *
     */
    @Headers({ HEADER_ACCEPT_DEVICES_JSON, HEADER_CONTENT_TYPE_DEVICES_JSON })
    @DELETE("{userId}/message")
    Call<ResponseBody> removeMessage(@Path("userUid") String userId, @Path("Id") String messageId);

}

package com.inerdev.hook.ui.messages;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.inerdev.hook.R;
import com.inerdev.hook.provider.AppContract;


public class MyMsgPostFragment extends BMsgFragment implements NewPostDialog.IRefreshData{

    private static final String TAG = "MyMsgPostFragment - ";

    private static final int REQUEST_POST_MESSAGE = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        mId = 2;
        mActionMenu = this;
        mMsgType = AppContract.Messages.MSG_POSTED;
        super.onCreate(savedInstanceState);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_create_post) {

            Intent intent = new Intent(getActivity(), PostMessageActivity.class);
            startActivityForResult(intent, REQUEST_POST_MESSAGE);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_POST_MESSAGE) {
            if (resultCode == Activity.RESULT_OK) {
                refreshData();
            }
        }
    }

    @Override
    public void refreshDataAfterOperation() {
        mLog.d(TAG, "refreshDataAfterOperation");
        refreshData();
    }
}

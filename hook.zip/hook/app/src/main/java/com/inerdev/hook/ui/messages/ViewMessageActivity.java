package com.inerdev.hook.ui.messages;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.inerdev.hook.HookApplication;
import com.inerdev.hook.R;
import com.inerdev.hook.provider.AppContract;


public class ViewMessageActivity extends AppCompatActivity {

    private static final String TAG = "ViewMessageActivity";

    public static final String ITEM_ID = "ITEM_ID";

    // UI references.
    private HookApplication mHookApplication;
    private View mProgressView;

    /** The m log. */
    private Log mLog;

    /** The m Cursor. */
    private Cursor mCursor;

    /** The m Context. */
    private Context mContext;

    /** The m id. */
    private long mId;

    /** The m msgFrom. */
    private TextView mMsgFrom;

    /** The m msgSubject. */
    private TextView mMsgSubject;

    /** The m msgText. */
    private TextView mMsgText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHookApplication = (HookApplication) getApplication();
        setContentView(R.layout.view_message);

        mMsgFrom = (TextView) findViewById(R.id.msgFrom);
        mMsgSubject = (TextView) findViewById(R.id.msgSubject);
        mMsgText = (TextView) findViewById(R.id.msgText);

        mProgressView = findViewById(R.id.load_progress);
        mContext = this;
        mId = getIntent().getLongExtra(ITEM_ID, -1);

        AsyncTask<Integer, Cursor, Cursor> asyncTask = new AsyncTask<Integer, Cursor, Cursor>()
        {

            @Override
            protected void onPreExecute() {
                showProgress(true);
            }

            @Override
            protected Cursor doInBackground(Integer... params) {
                mCursor = null;
                if (mId != -1){
                    AppContract.Messages message = new AppContract.Messages(mHookApplication.getAppContract());
                    mCursor = mContext.getContentResolver().query(message.getContentUri(),
                            null, AppContract.Messages._ID + "=?", new String[]{String.valueOf(mId)},
                            null);

                }

                return mCursor;

            }

            @Override
            protected void onPostExecute(Cursor result) {
                // display the result
                if (result != null && result.moveToFirst()){
                    // Extract properties from cursor
                    String from = result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SENDER_NAME));
                    String subject = result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SUBJECT));
                    StringBuilder text = new StringBuilder();
                    text.append(mContext.getResources().getString(R.string.msg_view_date_creation) + DateFormat.format("dd/MM/yyyy hh:mm", result.getLong(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_DATE_CREATION))));
                    text.append("\r\n");
                    text.append(mContext.getResources().getString(R.string.msg_view_date_expiration)
                            + DateFormat.format("dd/MM/yyyy hh:mm", result.getLong(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_DATE_EXPIRATION))));
                    text.append("\r\n");

                    text.append(mContext.getResources().getString(R.string.msg_view_category_type) +
                            result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_ITEM_CATEGORY_TYPE)));
                    text.append("\r\n");
                    text.append(mContext.getResources().getString(R.string.msg_view_sender_adr) + result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SENDER_ADR)));
                    text.append("\r\n");
                    text.append("\r\n");
                    text.append(mContext.getResources().getString(R.string.msg_view_sender_display_name) + result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_SENDER_NAME_DEVICE_DISPLAY_NAME)));
                    text.append("\r\n");
                    text.append("\r\n");
                    switch(result.getInt(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_STATUS))){
                        case AppContract.Messages.STATUS_PENDING:
                            text.append(mContext.getResources().getString(R.string.item_status_pending));
                            break;
                        case AppContract.Messages.STATUS_SENDING:
                            text.append(mContext.getResources().getString(R.string.item_status_sending));
                            break;
                        case AppContract.Messages.STATUS_COMPLETE:
                            text.append(mContext.getResources().getString(R.string.item_status_complete));
                            break;
                        case AppContract.Messages.STATUS_DELETING:
                            text.append(mContext.getResources().getString(R.string.item_status_deleting));
                            break;
                        case AppContract.Messages.STATUS_DELETED:
                            text.append(mContext.getResources().getString(R.string.item_status_deleted));
                            break;
                    }
                    text.append("\r\n");
                    text.append("\r\n");
                    text.append(mContext.getResources().getString(R.string.msg_view_text));
                    text.append("\r\n");
                    text.append(result.getString(result.getColumnIndexOrThrow(AppContract.Messages.COLUMN_TEXT)));


                    StringBuilder fromV = new StringBuilder();
                    fromV.append(mContext.getResources().getString(R.string.msg_view_from) + from);
                    mMsgFrom.setText(fromV);
                    StringBuilder subjectV = new StringBuilder();
                    subjectV.append(mContext.getResources().getString(R.string.msg_view_subject) + subject);
                    mMsgSubject.setText(subjectV);
                    mMsgText.setText(text);
                } else{
                    mLog.e(TAG, "onPostExecute failed invalid item");
                }
                showProgress(false);
            }
        };
        asyncTask.execute();

    }


    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

        mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
        mProgressView.animate().setDuration(shortAnimTime).alpha(
                show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            }
        });
    }
}


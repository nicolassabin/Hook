
package com.inerdev.hook.core.devices;


/**
 * The Interface ScanCallBackOperation.
 */
public interface ScanCallBackOperation {

    /**
     * on onScanResult
     * @param deviceInfo
     */
    public void onScanResult(DeviceInfo deviceInfo);

    /**
     * on onEnd
     */
    public void onEnd();

    /**
     * on onError
     * @param error
     */
    public void onError(int error);

}
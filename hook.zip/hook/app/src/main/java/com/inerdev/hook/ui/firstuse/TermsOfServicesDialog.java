/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.ui.utils.DialogFactory;
import com.inerdev.hook.ui.widgets.DialogButtons;

@Deprecated
public class TermsOfServicesDialog extends AppCompatActivity implements View.OnClickListener, DialogInterface.OnCancelListener {

    private static final String TAG = "TermsOfServicesDialog";


    private WebView mWebView;
    private View mAgreeButton;
    private TextView mPrivacyLink = null;
    protected ProgressDialog mProgressDialog = null;
    /** The m log. */
    private Log mLog;
    /** The progress splash. */


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.terms_for_service);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setControls();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if(mWebView != null) {
                if(mWebView.canGoBack()) {
                    mWebView.goBack();
                    return true;
                }
            }
        }
        return super.onKeyDown(keyCode, event);
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
//        if (mLinksNavigationRequested) {
//            Intent intent = new Intent(AtpAuthActivity.ACTION_AUTH_DIALOG_RESUMED);
//            intent.putExtra(ACTIVITY_FORCE_CLOSED, true);
//            sendBroadcast(intent);
//        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private class WebClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return false;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            setSupportProgressBarIndeterminateVisibility(false);
            dismissProgressDialog();
        }

    }

    protected void setControls(){
        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.setWebViewClient(new WebClient());
        setupTermsOfServicesView();

        mAgreeButton = findViewById(R.id.agreeButton);
        if (mAgreeButton != null) {
            mAgreeButton.setOnClickListener(this);
        }

        mPrivacyLink = (TextView) findViewById(R.id.terms_dialog_privacy_link);
        updatePrivacyUrl();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.agreeButton) {
            launchAuth();
        }
        else
        {
            dismissProgressDialog();
        }
        finish();
    }

    private void updatePrivacyUrl() {
        mPrivacyLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(getResources().getString(R.string.eula_url)));
                intent.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                startActivity(intent);
            }
        });
    }

    /**
     * Set up Web View
     */
    private void setupTermsOfServicesView() {
        mLog.d(TAG, "setupTermsOfServicesView");
        String eulaUrl = getString(R.string.eula_url);

        deActivateGui();
        mWebView.loadUrl(eulaUrl);
    }


    private void deActivateGui() {
        showProgressDialog(true);
    }

    private void showProgressDialog(boolean visible) {
        showProgressDialog(getText(R.string.splashscreen_info), visible);
    }

    private void showProgressDialog(CharSequence text, boolean visible) {
        dismissProgressDialog();
        if (visible) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setIndeterminate(true);
            mProgressDialog.setMessage(text);
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.setCancelable(true);
            mProgressDialog.setOnCancelListener(this);
            mProgressDialog.setOwnerActivity(this);
            DialogFactory.showDialog(mLog, this, mProgressDialog);
        }
    }

    public void dismissProgressDialog() {
        final ProgressDialog d = mProgressDialog;
        if (d!=null) {
            try {
                d.dismiss();
            } catch (Exception e) {
                mLog.d(TAG, "dismissProgressDialog threw an exception, handled");
            }
        }
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        dismissProgressDialog();
        finish();
    }

    void launchAuth() {
        Intent intent = new Intent(getIntentAction(AuthenticationManager.INTENT_ACTION_AUTH));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_SINGLE_TOP );
        startActivity(intent);
    }

    /**
     * Gets the package specific action for action suffix
     * @param actionSuffix
     * @return
     */
    private String getIntentAction(String actionSuffix) {
        return String.format("%s%s", getPackageName(), actionSuffix);
    }
}
/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.firstuse;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.inerdev.hook.R;
import com.inerdev.hook.core.auth.AuthenticationManager;
import com.inerdev.hook.ui.utils.SpanTokensHelper;
import com.inerdev.hook.ui.widgets.SwipePageListener;
import com.inerdev.hook.ui.widgets.SwiperControl;


/**
 * Activity displays Wizard Flow for application
 * To enable this activity please set up flag "wizard_flow" in booleans.xml into true value
 * Quantity of screens controlled through "R.array.wizard_strings"
 * If no wizard please leave this array empty.
 * Image assets will be loaded by name using this pattern: String.format("wizard_image_%d", number)
 * Image should be drawable (png or multilayer xml)
 * If there are  no corresponding image - screen will be empty
 * Strings from array supports two styles: WizardText and WizardHeaderText
 * To apply WizardHeaderText style please use tokens ## around your substring.
 * If you would like to use titles - put your strings into R.array.wizard_titles_strings
 * If you need different colors per titles - use R.array.wizard_titles_colors
 * Please note the lengths of arrays should be the same for: wizard_strings, wizard_titles_strings and wizard_titles_colors
 * @author vvdovenko
 */
public class WizardActivity extends AppCompatActivity implements OnClickListener, SwipePageListener {


    private static final String LOG_TAG = "WizardActivity";

    /** The SwiperControl. */
    private SwiperControl mSwiperControl;

    /** The m span tokens helper. */
    protected SpanTokensHelper mSpanTokensHelper = new SpanTokensHelper();

    /** The m log. */
    private Log mLog;


    /**
     *
     */
    @Override
    protected void onCreate(final Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        finishOnStartedTooEarly();
        overridePendingTransition(0, 0);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        setContentView(R.layout.wizard_activity);
        setControls();
    }

    /**
     * Finishes the activity if app hasn't got past SplashLogoActivity.
     */
    private void finishOnStartedTooEarly() {
        Activity parentActivity = getParent();
        if (parentActivity != null && parentActivity instanceof SplashLogoActivity) {
            finish();
        }
    }

    public void setControls() {
        mSwiperControl = (SwiperControl) findViewById(R.id.swiper_control);
        if (mSwiperControl != null) {
            final Resources res = getResources();
            mSwiperControl.setAdapter(new WizardAdapter(res.getTextArray(R.array.wizard_titles_strings),
                    res.getIntArray(R.array.wizard_titles_colors),
                    res.getTextArray(R.array.wizard_strings)));

            if (findViewById(R.id.wizard_next) != null) {
                mSwiperControl.setPageChangeListner(this);
            }
            mSwiperControl.startAutoScroll(5000);
            final Context context = getBaseContext();
            if (context != null && mSwiperControl.getCirclePageIndicator() != null) {
                mSwiperControl.getCirclePageIndicator().setStrokeColor(
                        ContextCompat.getColor(context, R.color.circle_page_indicator_stroke));
            }
        }

        View button = findViewById(R.id.skip_wizard_activity);
        if (button != null) {
            button.setOnClickListener(this);
            button.setVisibility(View.VISIBLE);
        }

        button = findViewById(R.id.wizard_next);
        if (button != null) {
            button.setOnClickListener(this);
            button.setVisibility(View.VISIBLE);
        }
    }

    /**
     *
     */
    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onOptionsItemSelected(final MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * On click.
     * @param v the v
     */
    @Override
    public void onClick(final View v) {
        if (v.getId() == R.id.skip_wizard_activity) {
            launchNextStep();
            finish();
        } else if (v.getId() == R.id.wizard_next && launchNextStepWhenNotScrolling()) {
            finish();
        }
    }

    /**
     * Launches the next step
     */
    private void launchNextStep() {
        if(getResources().getBoolean(R.bool.enable_eula_screen)) {
            mLog.d(LOG_TAG, "launchNextStep -> EULA");
            termsOfServices();
        } else {
            mLog.d(LOG_TAG, "launchNextStep -> AUTH");
            launchAuth();
        }
    }

    /**
     * Launch auth when not scrolling.
     */
    private boolean launchNextStepWhenNotScrolling() {
        if (!mSwiperControl.scrollOnce()) {
            launchNextStep();
            return true;
        }
        return false;
    }

    /**
     * Launch auth flow
     */
    private void launchAuth() {
        final Intent intent = new Intent(AuthenticationManager.INTENT_ACTION_AUTH);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }

    /**
     * Handle on page scrolled - do nothing.
     * @param position the position
     * @param positionOffset the position offset
     * @param positionOffsetPixels the position offset pixels
     */
    @Override
    public void onPageScrolled(final int position, final float positionOffset, final int positionOffsetPixels) {
        // do nothing.
    }

    /**
     * Handle on page selected.
     * @param position the position
     */
    @Override
    public void onPageSelected(final int position) {
        final TextView view = (TextView) findViewById(R.id.wizard_next);
        final TextView skipView = (TextView) findViewById(R.id.skip_wizard_activity);
        if (view != null) {
            if (position == mSwiperControl.getNumViews() - 1) {
                view.setText(R.string.wizard_login);
                setSkipButtonVisibility(false, skipView);
            } else {
                view.setText(R.string.wizard_next);
                setSkipButtonVisibility(true, skipView);
            }
        }
    }

    /**
     * The on page scroll state changed handler.
     * @param state the state
     */
    @Override
    public void onPageScrollStateChanged(int state) {
        // do nothing.
    }

    /**
     * The Class WizardAdapter.
     */
    protected class WizardAdapter extends PagerAdapter {

        private final CharSequence mWizardTitles[];
        private final int mWizardTitlesColors[];

        /** The wizard strings. */
        private final CharSequence mWizardStrings[];

        /**
         * Instantiates a new wizard adapter.
         * @param wizardTitles
         * @param wizardTitlesColors
         * @param wizardStrings
         */
        public WizardAdapter(CharSequence wizardTitles[], int wizardTitlesColors[], CharSequence wizardStrings[]) {
            mWizardTitles = wizardTitles;
            mWizardTitlesColors = wizardTitlesColors;
            mWizardStrings = wizardStrings;
        }

        /**
         * Gets the count.
         * @return the count
         */
        @Override
        public int getCount() {
            return mWizardStrings.length;
        }

        /**
         * Destroy item.
         * @param container the container
         * @param position the position
         * @param object the object
         */
        @Override
        public void destroyItem(final ViewGroup container, final int position, final Object object) {
            container.removeView((View) object);
        }

        /**
         * Instantiate item.
         * @param container the container
         * @param position the position
         * @return the object
         */
        @Override
        public Object instantiateItem(final ViewGroup container, final int position) {
            final WizardView view = new WizardView(getApplicationContext(), mWizardTitles[position], mWizardTitlesColors[position], mWizardStrings[position], position);
            if (view.getParent() == null) {
                container.addView(view);
            }
            return view;
        }

        /**
         * Checks if is view from object.
         * @param view the view
         * @param object the object
         * @return true, if is view from object
         */
        @Override
        public boolean isViewFromObject(final View view, final Object object) {
            return view == object;
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    /**
     * The Class WizardView.
     */
    protected class WizardView extends LinearLayout {

        /**
         * Instantiates a new wizard view.
         * @param context the context
         */
        public WizardView(final Context context) {
            super(context);
        }

        /**
         * Instantiates a new wizard view.
         * @param context the context
         * @param text the text
         * @param number the number
         */
        public WizardView(final Context context, final CharSequence title, final int wizardTitleColor, final CharSequence text, final int number) {
            this(context);

            final LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            vi.inflate(R.layout.wizard_view, this, true);
            final TextView wizard_title = (TextView) findViewById(R.id.wizard_title);
            final TextView wizard_text = (TextView) findViewById(R.id.wizard_text);
            final ImageView wizard_image = (ImageView) findViewById(R.id.wizard_image);

            if (wizard_title != null) {
                wizard_title.setText(title);
                wizard_title.setTextColor(wizardTitleColor);
            }

            if (wizard_text != null) {
                CharSequence styledText = mSpanTokensHelper.setSpanBetweenTokens(text, "##", new TextAppearanceSpan(getContext(), R.style.OnBordingHeaderText));
                wizard_text.setText(styledText);
            }

            if (wizard_image != null) {
                int imageResource = getImageResourceByNumber(number);
                if (imageResource != -1) {
                    try {
                        wizard_image.setImageResource(imageResource);
                    }
                    catch(OutOfMemoryError e) {
                        mLog.e(LOG_TAG, "OutOfMemoryError in WizardView()", e);
                    }
                }
            }
        }

        /**
         * Gets the image resource by number.
         * @param number the number
         * @return the image resource by number
         */
        protected int getImageResourceByNumber(int number) {
            return getResources().getIdentifier(String.format("wizard_image_%d", number), "drawable", getPackageName());
        }
    }

    /**
     *
     * java.lang.String[], int[])
     */
    @Override
    public void onRequestPermissionsResult(final int requestCode, final String[] permissions, final int[] grantResults) {
        boolean notGrantedAllPermissions = false;
        for (final int grant : grantResults) {
            if (grant != PackageManager.PERMISSION_GRANTED) {
                notGrantedAllPermissions = true;
                break;
            }
        }
        if (!notGrantedAllPermissions) {
            final Intent intent = new Intent(AuthenticationManager.INTENT_ACTION_AUTH);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        }
    }

    /**
     * @param skipButtonVisibility
     * @param skipTextView
     */
    private void setSkipButtonVisibility(boolean skipButtonVisibility, TextView skipTextView) {
        if (skipTextView != null) {
            skipTextView.setVisibility(skipButtonVisibility ? View.VISIBLE : View.GONE);
        }
    }

    void termsOfServices() {
        Intent intent = new Intent(this, TermsOfService.class);
        intent.putExtra(TermsOfService.INTENT_PARAM_ACCEPT_BUTTON, true);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }
}

package com.inerdev.hook.ui.utils;

import android.app.Activity;
import android.app.Dialog;
import android.util.Log;

/**
 * Created by nsab0001 on 17/05/2017.
 */

public class DialogFactory {

    private static final String LOG_TAG = "DialogFactory";

    /**
     * Show dialog.
     * @param activity the activity
     * @param dialog the dialog
     */
    public static void showDialog(final Log log, final Activity activity, final Dialog dialog) {
        if (activity == null || dialog == null)
            return;

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (dialog.getOwnerActivity() == null || dialog.getOwnerActivity().isFinishing()) {
                    log.d(LOG_TAG, "showDialog ignored");
                } else if (!dialog.isShowing()) {
                    try {
                        dialog.show();
                    } catch (final Exception ignored) {
                        log.d(LOG_TAG, "showDialog, exc: %s", ignored);
                    }
                }
            }
        });
    }
}

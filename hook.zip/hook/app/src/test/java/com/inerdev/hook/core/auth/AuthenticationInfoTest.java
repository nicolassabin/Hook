/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class AuthenticationInfoTest {

    /** The AuthenticationImpl. */
    AuthenticationInfo authenticationInfo;


    /**
     * Setup.
     */
    @Before
    public void setup() throws Exception {
        authenticationInfo = new AuthenticationInfo("userID", "token", "refreshtoken", "email@email.com",
                new Date(), "0x:01");

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        assertNotNull(authenticationInfo);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException {
        assertEquals("userID", authenticationInfo.getUserid());
        assertEquals("refreshtoken", authenticationInfo.getRefreshToken());
        assertEquals("email@email.com", authenticationInfo.getAccountName());
        assertEquals("token", authenticationInfo.getAccessToken());
        assertNotNull(authenticationInfo.getAccessTokenExpirationDate());

        authenticationInfo.setInfo("userID2", "token2", "refreshtoken2", "email@email.com2",
                new Date(), "0x:01");
        assertEquals("userID2", authenticationInfo.getUserid());
        assertEquals("refreshtoken2", authenticationInfo.getRefreshToken());
        assertEquals("email@email.com2", authenticationInfo.getAccountName());
        assertEquals("token2", authenticationInfo.getAccessToken());
        assertEquals("0x:01", authenticationInfo.getDeviceAdr());
        assertNotNull(authenticationInfo.getAccessTokenExpirationDate());


    }



}

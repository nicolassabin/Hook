/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.ui.utils;

import android.content.Context;
import android.content.SharedPreferences;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * The Class MySharePreferencesTest.
 */
public class MySharePreferencesTest {

    /** The MySharePreferences. */
    private MySharePreferences mySharePreferences;

    /** The mock context. */
    private Context mockContext;

    /**
     * Setup.
     */
    @Before
    public void setup() {
        mockContext = mock(Context.class);
        when(mockContext.getSharedPreferences(anyString(), anyInt())).thenReturn(new SharedPreferences() {

            private final Map<String, Object> values = new HashMap<String, Object>();

            private final Editor editor = new Editor() {

                @Override
                public Editor putString(final String key, final String value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor putStringSet(final String key, final Set<String> value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor putInt(final String key, final int value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor putLong(final String key, final long value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor putFloat(final String key, final float value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor putBoolean(final String key, final boolean value) {
                    values.put(key, value);
                    return this;
                }

                @Override
                public Editor remove(final String key) {
                    values.remove(key);
                    return this;
                }

                @Override
                public Editor clear() {
                    values.clear();
                    return this;
                }

                @Override
                public boolean commit() {
                    return true;
                }

                @Override
                public void apply() {
                    // do nothing.
                }

            };

            @Override
            public Map<String, ?> getAll() {
                return values;
            }

            @Override
            public String getString(final String key, final String defValue) {
                if (values.get(key) != null) {
                    return (String) values.get(key);
                }
                return defValue;
            }

            @Override
            public Set<String> getStringSet(final String key, final Set<String> defValues) {
                if (values.get(key) != null) {
                    return (Set<String>) values.get(key);
                }
                return defValues;
            }

            @Override
            public int getInt(final String key, final int defValue) {
                if (values.get(key) != null) {
                    return (Integer) values.get(key);
                }
                return defValue;
            }

            @Override
            public long getLong(final String key, final long defValue) {
                if (values.get(key) != null) {
                    return (Long) values.get(key);
                }
                return defValue;
            }

            @Override
            public float getFloat(final String key, final float defValue) {
                if (values.get(key) != null) {
                    return (Float) values.get(key);
                }
                return defValue;
            }

            @Override
            public boolean getBoolean(final String key, final boolean defValue) {
                if (values.get(key) != null) {
                    return (Boolean) values.get(key);
                }
                return defValue;
            }

            @Override
            public boolean contains(final String key) {
                return values.containsKey(key);
            }

            @Override
            public Editor edit() {
                return editor;
            }

            @Override
            public void registerOnSharedPreferenceChangeListener(final OnSharedPreferenceChangeListener listener) {
                // do nothing.
            }

            @Override
            public void unregisterOnSharedPreferenceChangeListener(final OnSharedPreferenceChangeListener listener) {
                // do nothing.
            }
        });
        mySharePreferences = new MySharePreferences(mockContext, "Cloud");
    }

    /**
     * Test save and get string.
     */
    @Test
    public void testSaveAndGetString() {
        mySharePreferences.saveStringPreference("test1", "value1");
        assertEquals("value1", mySharePreferences.getStringPreference("test1"));
        assertNotNull(mySharePreferences);
    }

    /**
     * Test save and get boolean.
     */
    @Test
    public void testSaveAndGetBoolean() {
        mySharePreferences.saveBooleanPreference("test2", true);
        assertEquals(true, mySharePreferences.getBooleanPreference("test2"));
        mySharePreferences.saveBooleanPreference("test3", false);
        assertEquals(false, mySharePreferences.getBooleanPreference("test3"));
        assertNotNull(mySharePreferences);
    }

    /**
     * Test save and get int.
     */
    @Test
    public void testSaveAndGetInt() {
        mySharePreferences.saveIntPreference("test4", 10);
        assertEquals(10, mySharePreferences.getIntPreference("test4"));
        mySharePreferences.saveIntPreference("test5", 99999999);
        assertEquals(99999999, mySharePreferences.getIntPreference("test5"));
        mySharePreferences.saveIntPreference("test6", -10);
        assertEquals(-10, mySharePreferences.getIntPreference("test6"));
        mySharePreferences.saveIntPreference("test7", 0);
        assertEquals(0, mySharePreferences.getIntPreference("test7"));
        assertNotNull(mySharePreferences);
    }

    /**
     * Test save and get long.
     */
    @Test
    public void testSaveAndGetLong() {
        mySharePreferences.saveLongPreference("test8", 50000);
        assertEquals(50000, mySharePreferences.getLongPreference("test8", 10000));
        assertNotNull(mySharePreferences);
    }

    /**
     * Test get invalid keys.
     */
    @Test
    public void testGetInvalidKeys() {
        assertEquals("validValue", mySharePreferences.getStringPreference("invalidKey", "validValue"));
        assertEquals(1337, mySharePreferences.getIntPreference("invalidKey", 1337));
        assertEquals(20000, mySharePreferences.getLongPreference("invalidkey", 20000));
        assertNotNull(mySharePreferences);
    }

    /**
     * Test remove each.
     */
    @Test
    public void testRemoveEach() {
        mySharePreferences.saveStringPreference("test1", "value1");
        assertEquals("value1", mySharePreferences.getStringPreference("test1"));
        mySharePreferences.removePreference("test1");
        assertNotEquals("value1", mySharePreferences.getStringPreference("test1"));
        assertEquals("", mySharePreferences.getStringPreference("test1"));

        mySharePreferences.saveBooleanPreference("test2", true);
        assertEquals(true, mySharePreferences.getBooleanPreference("test2"));
        mySharePreferences.removePreference("test2");
        assertNotEquals(true, mySharePreferences.getBooleanPreference("test2"));
        assertEquals("", mySharePreferences.getStringPreference("test2"));

        mySharePreferences.saveIntPreference("test3", 10);
        assertEquals(10, mySharePreferences.getIntPreference("test3"));
        mySharePreferences.removePreference("test3");
        assertNotEquals(10, mySharePreferences.getIntPreference("test3"));
        assertEquals(0, mySharePreferences.getIntPreference("test3"));

        mySharePreferences.saveLongPreference("test4", 100000);
        assertEquals(100000, mySharePreferences.getLongPreference("test4", 20000));
        mySharePreferences.removePreference("test4");
        assertEquals(20000, mySharePreferences.getLongPreference("test4", 20000));

        assertNotNull(mySharePreferences);
    }

    /**
     * Test clear all.
     */
    @Test
    public void testClearAll() {
        mySharePreferences.saveStringPreference("test1", "value1");
        assertEquals("value1", mySharePreferences.getStringPreference("test1"));
        mySharePreferences.saveBooleanPreference("test2", true);
        assertEquals(true, mySharePreferences.getBooleanPreference("test2"));
        mySharePreferences.saveBooleanPreference("test3", false);
        assertEquals(false, mySharePreferences.getBooleanPreference("test3"));
        mySharePreferences.saveIntPreference("test4", 10);
        assertEquals(10, mySharePreferences.getIntPreference("test4"));
        mySharePreferences.saveIntPreference("test5", 99999999);
        assertEquals(99999999, mySharePreferences.getIntPreference("test5"));
        mySharePreferences.saveIntPreference("test6", -10);
        assertEquals(-10, mySharePreferences.getIntPreference("test6"));
        mySharePreferences.saveIntPreference("test7", 0);
        assertEquals(0, mySharePreferences.getIntPreference("test7"));
        mySharePreferences.saveLongPreference("test8", 50000);
        assertEquals(50000, mySharePreferences.getLongPreference("test8", 10000));

        mySharePreferences.clearAll();
        final SharedPreferences prefs = mySharePreferences.getSharedPreferences();
        final Map<String, ?> map = prefs.getAll();
        assertTrue(map.isEmpty());
        assertNotNull(mySharePreferences);
    }
}

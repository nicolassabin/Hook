/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.devices;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class DevicesInfoTest {

    /** The DeviceInfo. */
    DeviceInfo deviceInfo;


    /**
     * Setup.
     */
    @Before
    public void setup() throws Exception {
        deviceInfo = new DeviceInfo("ID", "adr", "name", "displayName", "userId");

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        assertNotNull(deviceInfo);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException {
        assertEquals("ID", deviceInfo.getId());
        assertEquals("adr", deviceInfo.getAdr());
        assertEquals("name", deviceInfo.getName());
        assertEquals("displayName", deviceInfo.getDisplayName());
        assertEquals("userId", deviceInfo.getUserId());

        deviceInfo.setInfo("ID2", "adr2", "name2", "displayName2", "userId2");
        assertEquals("ID2", deviceInfo.getId());
        assertEquals("adr2", deviceInfo.getAdr());
        assertEquals("name2", deviceInfo.getName());
        assertEquals("displayName2", deviceInfo.getDisplayName());
        assertEquals("userId2", deviceInfo.getUserId());

    }



}

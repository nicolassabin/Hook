package com.inerdev.hook.provider;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.support.v4.BuildConfig;
import android.util.Log;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class, sdk = Build.VERSION_CODES.LOLLIPOP)
public class AppContractTest {

    AppContract appContract;
    private Context mockContext = mock(Context.class);

    @Before
    public void setup() {
        when(mockContext.getPackageName()).thenReturn("com.example");
        appContract = new AppContract(mockContext);
    }

    @Test
    public void testCreate() {
        assertNotNull(appContract);
    }

    @Test
    public void testGetContentAuthority() {
        String contentAuthority = appContract.getContentAuthority();
        assertEquals("com.example.hook.data", contentAuthority);
    }

    @Test
    public void testGetBaseContentUri() {
        Uri baseContentUri = appContract.getBaseContentUri();
        assertEquals("content://com.example.hook.data", baseContentUri.toString());
    }

}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.mockito.PowerMockito.whenNew;

/**
 * Created by ns on 15/05/2017.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthenticationStorage.class, Log.class})
public class AuthenticationStorageTest {

    /** The authentication storage. */
    private AuthenticationStorage authenticationStorage;

    /** The mock context. */
    private final Context mockContext = mock(Context.class);

    /** The mock auth pref manager. */
    private final PreferenceManager mockAuthPrefManager = mock(PreferenceManager.class);

    /** The Mock Resources. */
    private Resources mockResources = Mockito.mock(Resources.class);

    /**
     * Sets the up.
     */
    @Before
    public void setUp() {
        try {
            PowerMockito.mockStatic(Log.class);
            whenNew(PreferenceManager.class).withArguments(any(Context.class), any(Log.class))
                    .thenReturn(mockAuthPrefManager);
            when(mockAuthPrefManager.readAccessToken()).thenReturn("readAccessToken");
            when(mockAuthPrefManager.readContextToken()).thenReturn("readContextToken");
            when(mockAuthPrefManager.readUserID()).thenReturn("userID");
            when(mockAuthPrefManager.readEmail()).thenReturn("someId@email.com");
            when(mockAuthPrefManager.readDvAccountDeactivated()).thenReturn(false);
            when(mockAuthPrefManager.readUserLoginStatus()).thenReturn(true);
            when(mockAuthPrefManager.isUserAuthenticatedOnce()).thenReturn(true);

            authenticationStorage = new AuthenticationStorage(mockContext);
        } catch (final Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Test create.
     */
    @Test
    public void testCreate() {
        assertNotNull(authenticationStorage);
    }

    /**
     * Test testGettersSetters.
     */
    @Test
    public void testGettersSetters() {
        Mockito.when(mockResources.getBoolean(anyInt())).thenReturn(true);
        when(mockAuthPrefManager.readUserLoginStatus()).thenReturn(false);
        authenticationStorage.setContextToken("newContextToken");
        assertEquals("newContextToken", authenticationStorage.getContextToken());

        authenticationStorage.setAccountName("test@test.com");
        assertEquals("test@test.com", authenticationStorage.getAccountName());

        authenticationStorage.setDeviceAdr("0x0:01");
        assertEquals("0x0:01", authenticationStorage.getDeviceAdr());

        authenticationStorage.setDvUserUid("userID");
        assertEquals("userID", authenticationStorage.getDvUserUid());

        authenticationStorage.setShortLivedToken("shortLivedToken");
        assertEquals("shortLivedToken", authenticationStorage.getShortLivedToken());

        authenticationStorage.setExpirationTime(1, 2);
        assertEquals(1, authenticationStorage.getExpirationTime());
        authenticationStorage.setExpirationTime("12");
        assertEquals(12, authenticationStorage.getExpirationTime());

        try {
            authenticationStorage.setExpirationTime("not a  time");
        } catch (Exception e) {
            assertEquals("", e.getMessage());
        }

        assertTrue(authenticationStorage.isTokenExpired(0));

        assertFalse(authenticationStorage.isDvAccountDeactivated());
        authenticationStorage.setDvAccountDeactivated(true);
        assertTrue(authenticationStorage.isDvAccountDeactivated());


        authenticationStorage.addExpiredAccessToken("expiredToken");
        authenticationStorage.addExpiredAccessToken("expiredToken");
        authenticationStorage.addExpiredAccessToken("expiredToken1");
        authenticationStorage.isAccessTokenKnownToBeExpired("ex");
        authenticationStorage.isAccessTokenKnownToBeExpired("expiredToken");

        authenticationStorage.setUserEndPointRunning(true);
        assertTrue(authenticationStorage.isUserEndPointRunning());

        assertFalse(authenticationStorage.isProvisioned());

        /*authenticationStorage.setMigrationLastLegacyUpload("legacyUpload");
        assertEquals("legacyUpload", authenticationStorage.getMigrationLastLegacyUpload());

        authenticationStorage.setMigrationMinsUntilCompletion("1");
        assertEquals("1", authenticationStorage.getMigrationMinsUntilCompletion());
        authenticationStorage.setMigrationMinsUntilCompletion(null);
        assertNull(authenticationStorage.getMigrationMinsUntilCompletion());

        authenticationStorage.setMigrationStatus(null);
        assertNull(authenticationStorage.getMigrationStatus());
        authenticationStorage.setMigrationStatus("migrating");
        assertEquals("migrating", authenticationStorage.getMigrationStatus());*/

        authenticationStorage.clear();
        assertEquals("", authenticationStorage.getContextToken());
        assertEquals("", authenticationStorage.getDvUserUid());
        assertEquals("", authenticationStorage.getShortLivedToken());
        assertEquals(0, authenticationStorage.getExpirationTime());
    }

    /**
     * Test methods.
     */
    @Test
    public void testMethods() {

        authenticationStorage.setContextToken("contextToken");
        assertEquals("contextToken", authenticationStorage.getContextToken());

        authenticationStorage.setDvUserUid("DVUserID");
        assertEquals("DVUserID", authenticationStorage.getDvUserUid());

        authenticationStorage.saveEmail("someId@email.com");
        assertEquals("someId@email.com", authenticationStorage.getEmail());

        authenticationStorage.saveLoginStatus(true);

        authenticationStorage.setShortLivedToken("shortLivedToken");
        assertEquals("shortLivedToken", authenticationStorage.getShortLivedToken());

        authenticationStorage.setExpirationTime("300");

        assertFalse(authenticationStorage.isTokenExpired(10));

        authenticationStorage.setDvAccountDeactivated(false);
        assertFalse(authenticationStorage.isDvAccountDeactivated());

        for (int i = 0; i < 7; i++) {
            authenticationStorage.addExpiredAccessToken("expiredToken_" + i);
        }
        assertTrue(authenticationStorage.isAccessTokenKnownToBeExpired("expiredToken_2"));

        authenticationStorage.setUserEndPointRunning(true);
        assertTrue(authenticationStorage.isUserEndPointRunning());

        assertEquals("userID", authenticationStorage.readUserID());

        assertTrue(authenticationStorage.isUserAuthenticatedOnce());

        authenticationStorage.setUserAuthenticatedOnce();

        assertTrue(authenticationStorage.readUserLoginStatus());

        authenticationStorage.clear();
        assertNull(authenticationStorage.getEmail());
    }


}

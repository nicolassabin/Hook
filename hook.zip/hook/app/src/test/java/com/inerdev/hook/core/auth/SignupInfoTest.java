package com.inerdev.hook.core.auth;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by ns on 04/05/2017.
 */
public class SignupInfoTest {

    static final String AB = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ @_-/\\^$*~&\"'()!:;.,?<>";
    static Random rnd = new Random();

    private String randomString(int len)
    {
        StringBuilder sb = new StringBuilder(len);
        for( int i = 0; i < len; i++ )
            sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
        return sb.toString();
    }

    private final String NAME = randomString(20);
    private final String EMAIL = randomString(20);
    private final String PHONE= randomString(20);
    private final String UID = randomString(20);
    private final String PASSWORD = randomString(20);
    private final String Q1 = randomString(20);
    private final String R1 = randomString(20);
    private final String Q2 = randomString(20);
    private final String R2 = randomString(20);
    private final String Q3 = randomString(20);
    private final String R3 = randomString(20);

    Map<String,String> _questionAnswerList;
    SignupInfo _pi;

    @Before
    public void setUp() throws Exception {
        _questionAnswerList = new HashMap<String,String>();
        _pi = new SignupInfo(NAME, EMAIL, PHONE, UID, PASSWORD,  _questionAnswerList);
        _questionAnswerList.put(Q1, R1);
        _questionAnswerList.put(Q2, R2);
        _questionAnswerList.put(Q3, R3);
    }

    @Test
    public void testGetUsername() throws Exception {
        Assert.assertEquals(NAME, _pi.getUsername());
        _pi.setUsername("One");
        Assert.assertEquals("One", _pi.getUsername());
    }

    @Test
    public void testGetAccountPassword() throws Exception {
        Assert.assertEquals(PASSWORD, _pi.getAccountPassword());
        _pi.setAccountPassword("two");
        Assert.assertEquals("two", _pi.getAccountPassword());
    }

    @Test
    public void testGetUniqueId() throws Exception {
        Assert.assertEquals(UID, _pi.getUniqueId());
        _pi.setUniqueId("3");
        Assert.assertEquals("3", _pi.getUniqueId());
    }

    @Test
    public void testGetEmail() throws Exception {
        Assert.assertEquals(EMAIL, _pi.getEmail());
        _pi.setEmail("For");
        Assert.assertEquals("For", _pi.getEmail());
    }

    @Test
    public void testGetPhoneNumber() throws Exception {
        Assert.assertEquals(PHONE, _pi.getPhoneNumber());
        _pi.setPhoneNumber("5");
        Assert.assertEquals("5", _pi.getPhoneNumber());
    }

    @Test
    public void testGetQuestions() throws Exception {
        Map<String,String> q = _pi.getQuestions();
        Assert.assertEquals(R1, q.get(Q1));
        Assert.assertEquals(R2, q.get(Q2));
        Assert.assertEquals(R3, q.get(Q3));
        q.clear();
        q.put(Q1, R1);
        _pi.setQuestions(q);
        q = _pi.getQuestions();
        Assert.assertEquals(R1, q.get(Q1));
        Assert.assertEquals(null, q.get(Q2));
    }
}
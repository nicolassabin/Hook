/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;


public class MessageTest {

    /** The Message. */
    Message message;

    /**
     * Setup.
     */
    @Before
    public void setup() throws IOException, JSONException {
        message = new Message();

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        Assert.assertNotNull(message);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException, JSONException {
        Assert.assertNull(message.getId());
        Assert.assertNull(message.getType());
        Assert.assertNull(message.getDateCreation());
        Assert.assertNull(message.getCategory());
        Assert.assertNull(message.getData1());
        Assert.assertNull(message.getDateExpiration());
        Assert.assertNull(message.getDeviceId());
        Assert.assertNull(message.getFrom());
        Assert.assertNull(message.getSubject());
        Assert.assertNull(message.getText());
        Assert.assertEquals(0, message.getStatus());

    }


}

package com.inerdev.hook.core.auth;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Log.class)
public class PreferenceManagerTest {

    /**
     * The PreferenceManager. (To be tested)
     */
    private PreferenceManager preferenceManager;

    /**
     * The Log.
     */
    private Log mockLog = mock(Log.class);

    /**
     * The Context.
     */
    private Context mockContext = mock(Context.class);

    /**
     * The SharedPreferences.
     */
    private SharedPreferences mockSharedPreferences = mock(SharedPreferences.class);

    /**
     * The Editor.
     */
    private SharedPreferences.Editor mockEditor = mock(SharedPreferences.Editor.class);

    @Before
    public void setup() throws PackageManager.NameNotFoundException {
        PowerMockito.mockStatic(Log.class);
        when(mockContext.getSharedPreferences(anyString(), anyInt())).thenReturn(mockSharedPreferences);
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("testEmail");
        when(mockSharedPreferences.edit()).thenReturn(mockEditor);
        when(mockEditor.putString(anyString(), anyString())).thenReturn(mockEditor);
        when(mockEditor.commit()).thenReturn(true);
        PackageManager mockPackageManager = mock(PackageManager.class);
        PackageInfo mockPackageInfo = mock(PackageInfo.class);
        when(mockContext.getPackageManager()).thenReturn(mockPackageManager);
        when(mockPackageManager.getPackageInfo(anyString(), anyInt())).thenReturn(mockPackageInfo);
        mockPackageInfo.versionCode = 1;
        preferenceManager = new PreferenceManager(mockLog, mockContext);
    }

    @Test
    public void testSaveSNCCLientVersion() {
        preferenceManager.saveSNCClientVersion(10);
    }

    @Test
    public void testSaveSNCGlobalVersion() {
        preferenceManager.saveSNCGlobalVersion(1337);
    }

    @Test
    public void testReadEmail() {
        assertEquals("testEmail", preferenceManager.readAccountName());
    }

    @Test
    public void testSaveEmail() {
        preferenceManager.saveAccountName("testEmail");
    }

    @Test
    public void testUserLoginStatus() {
        preferenceManager.saveUserLoginStatus(true);
    }

    @Test
    public void testSaveNabAuthStatus() {
        preferenceManager.saveNabAuthStatus(true);
    }

    @Test
    public void testReadSncClientVersion() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("10");
        assertEquals(10, preferenceManager.readSNCClientVersion());
    }

    @Test
    public void testReadSncGlobalVersion() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("1337");
        assertEquals(1337, preferenceManager.readSNCGlobalVersion());
    }

    @Test
    public void testUserLogin() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("true");
        assertTrue(preferenceManager.readUserLoginStatus());
    }

    @Test
    public void testReadPreviewImageVersion() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("27");
        assertEquals(27, preferenceManager.readPreviewImagesVersion());
    }

    @Test
    public void testReadNabAuthStatus() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("true");
        assertTrue(preferenceManager.readNabAuthStatus());
    }

    @Test
    public void testSaveUserId() {
        preferenceManager.saveUserID("userId");
    }

    @Test
    public void testReadUserId() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("userId");
        assertEquals("userId", preferenceManager.readUserID());
    }

    @Test
    public void testSaveContextToken() {
        preferenceManager.saveContextToken("contextToken");
    }

    @Test
    public void testReadContextToken() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("testContextToken");
        assertEquals("testContextToken", preferenceManager.readContextToken());
    }

    @Test
    public void testSaveAccessToken() {
        preferenceManager.saveAccessToken("accessToken");
    }

    @Test
    public void testReadAccessToken() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("AccessToken");
        assertEquals("AccessToken", preferenceManager.readAccessToken());
    }

    @Test
    public void testSaveIsAccountBlocked() {
        preferenceManager.saveIsAccountBlocked(true);
    }

    @Test
    public void testReadIsAccountBlocked() {
        when(mockSharedPreferences.getBoolean(anyString(), anyBoolean())).thenReturn(true);
        assertTrue(preferenceManager.readIsAccountBlocked());
    }

    @Test
    public void testSaveLastUploadDate() {
        preferenceManager.saveLastUploadDate("someDate");
    }

    @Test
    public void testSaveLastUploadFileCount() {
        preferenceManager.saveLastUploadedFileCount(100);
    }

    @Test
    public void testSaveQuickActionCheckBoxStatus() {
        preferenceManager.saveQuickActionCheckBoxStatus(true);
    }

    @Test
    public void testSaveInitialSyncStatus(){
        preferenceManager.saveInitialSyncStatus(true);
    }

    @Test
    public void testSaveLastDownloadDate(){
        preferenceManager.saveLastDownloadDate("someDate");
    }

    @Test
    public void testReadQuickActionCheckBoxStatus(){
        when(mockSharedPreferences.getBoolean(anyString(), anyBoolean())).thenReturn(true);
        assertTrue(preferenceManager.readQuickActionCheckBoxStatus());
    }

    @Test
    public void testReadInitialSyncStatus() {
        when(mockSharedPreferences.getBoolean(anyString(), anyBoolean())).thenReturn(true);
        assertTrue(preferenceManager.readInitialSyncStatus());
    }

    @Test
    public void testReadLastUploadFileCount() {
        when(mockSharedPreferences.getInt(anyString(),anyInt())).thenReturn(10);
        assertEquals(10, preferenceManager.readLastUploadFileCount());
    }

    @Test
    public void testReadLastDownloadDate() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("someDate");
        assertEquals("someDate", preferenceManager.readLastDownloadDate());
    }

    @Test
    public void testReadLastUploadDate() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("someDate");
        assertEquals("someDate", preferenceManager.readLastUploadDate());
    }

    @Test
    public void testReadClientConfigAppVersion() {
        when(mockSharedPreferences.getString(anyString(), anyString())).thenReturn("1337");
        assertEquals(1337, preferenceManager.readClientConfigAppVersion());
    }

    @Test
    public void testSaveCientConfigAppVersion() {
        preferenceManager.saveClientConfigAppVersion();
    }

    @Test
    public void testSavePreviewImages() {
        preferenceManager.savePreviewImagesVersion(10);
    }

    @Test
    public void testReadDvAccountDeactivated() {
        when(mockSharedPreferences.getBoolean(anyString(), anyBoolean())).thenReturn(true);
        assertTrue(preferenceManager.readDvAccountDeactivated());
    }

    @Test
    public void testSaceDvAccountDeactivated() {
        preferenceManager.saveDvAccountDeactivated(true);
    }

    @Test
    public void testGetAppVersion() throws PackageManager.NameNotFoundException {
        assertEquals(1, preferenceManager.getAppVersion());
    }
}

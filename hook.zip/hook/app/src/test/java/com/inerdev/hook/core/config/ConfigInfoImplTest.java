package com.inerdev.hook.core.config;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import com.inerdev.hook.core.auth.PreferenceManager;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Log.class)
public class ConfigInfoImplTest {

    /**
     * The ConfigInfoImpl. (To be tested)
     */
    private ConfigInfoImpl configInfo;

    /**
     * The Log.
     */
    private Log mockLog = mock(Log.class);

    /**
     * The Context.
     */
    private Context mockContext = mock(Context.class);

    @Before
    public void setup() throws PackageManager.NameNotFoundException {
        PowerMockito.mockStatic(Log.class);
        configInfo = new ConfigInfoImpl(mockContext);
    }

    @Test
    public void testUrl() {
        assertNotNull(configInfo.getServerUrl());
        assertNotNull(configInfo.getAuthUrl());
    }


}

package com.inerdev.hook.core.utils;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;


import com.inerdev.hook.core.CoreException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.lang.reflect.Field;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({Build.class, Log.class, TextUtils.class, Settings.Secure.class})
public class DeviceDetailsTest {

    /** The DeviceDetails. */
    private DeviceDetails deviceDetails;

    /** The Log. */
    private Log mockLog = mock(Log.class);

    /** The Resources. */
    private Resources mockResources = mock(Resources.class);

    /** The Configuration. */
    private Configuration mockConfiguration = mock(Configuration.class);


    /** The Context. */
    private Context mockContext = mock(Context.class);

    @Before
    public void setup() {
        PowerMockito.mockStatic(Log.class);
        PowerMockito.mockStatic(TextUtils.class);
        PowerMockito.mockStatic(Settings.Secure.class);
        deviceDetails = new DeviceDetails(mockContext, mockLog);
    }

    @After
    public void tearDown() {
        deviceDetails = null;
    }

    @Test
    public void testGetId() {
        assertEquals(null, deviceDetails.getId());
    }

    @Test
    public void testName() throws Exception {
        when(mockContext.getString(anyInt())).thenReturn("methodWorking");
        /** manufacturer mocked so contained in model. */
        Field f = Build.class.getDeclaredField("MANUFACTURER");
        f.setAccessible(true);
        f.set(deviceDetails,"Child");
        /** model mocked. */
        f = Build.class.getDeclaredField("MODEL");
        f.setAccessible(true);
        f.set(deviceDetails, "ParentContainsChild");
        assertEquals("ParentContainsChild", deviceDetails.getName());
        /** manufacturer reset. */
        f = Build.class.getDeclaredField("MANUFACTURER");
        f.setAccessible(true);
        f.set(deviceDetails, "NotTheChild");
        assertEquals("NotTheChild ParentContainsChild", deviceDetails.getName());
    }

    @Test
    public void testGetMcc() {
        TelephonyManager mockTelephonyManager = mock(TelephonyManager.class);
        when(mockContext.getSystemService(Context.TELEPHONY_SERVICE)).thenReturn(mockTelephonyManager);
        when(mockTelephonyManager.getSimOperator()).thenReturn("1337Operator");
        assertEquals(133, deviceDetails.getMcc());
        assertEquals(133,deviceDetails.getMcc());
    }

    @Test
    public void testAcceptLanguageHeaderValue() throws CoreException {
        //assertEquals("en-US",deviceDetails.getAcceptLanguageHeaderValue());

        String lang = deviceDetails.getAcceptLanguageHeaderValue();
        assertTrue(lang != null && lang.length() > 0);
    }

    @Test
    public void testGetDeviceIdentifier() {
        TelephonyManager mockTelephonyManager = mock(TelephonyManager.class);
        when(mockContext.getSystemService(Context.TELEPHONY_SERVICE)).thenReturn(mockTelephonyManager);
        when(mockContext.getPackageName()).thenReturn("PackageName");
        when(mockContext.getResources()).thenReturn(mockResources);
        when(mockResources.getConfiguration()).thenReturn(mockConfiguration);
        when(mockTelephonyManager.getDeviceId()).thenReturn("mobile123");
        String device =  deviceDetails.getDeviceIdentifier();
        assertTrue(device != null && device.length() > 0);
        assertTrue(device.contains("mobile123"));
        assertTrue(device.contains("PackageName"));

    }
}

/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.auth;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;


import com.inerdev.hook.core.ErrorCode;
import com.inerdev.hook.core.config.ConfigHelper;
import com.inerdev.hook.core.config.ConfigInfo;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.fail;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({TextUtils.class, Log.class, AuthenticationStorage.class, PreferenceManager.class})
public class AuthenticationManagerHelperTest {

    /** The AuthenticationManagerHelper. */
    AuthenticationManagerHelper authenticationManagerHelper;

    /** The Log. */
    Log log;


    /** The Mock Context. */
    Context mockContext = mock(Context.class);

    /** The ConfigHelper. */
    ConfigHelper mockConfig = mock(ConfigHelper.class);

    /** The IConfigInfo. */
    ConfigInfo mockConfigInfo = mock(ConfigInfo.class);

    /** THe Mock PreferenceManager. */
    PreferenceManager mockPreferenceManager = mock(PreferenceManager.class);

    /** The Mock AuthenticationStorage. */
    AuthenticationStorage mockAuthenticationStorage = mock(AuthenticationStorage.class);

    /** The Mock IAuthenticationManagerListener. */
    AuthenticationManagerListener mockIAuthenticationManagerListener = PowerMockito.mock(AuthenticationManagerListener.class);

    /** The Mock AuthenticationUIController. */
    AuthenticationUIController mockAuthenticationUIController = mock(AuthenticationUIController.class);

    /** The Mock AuthBackendHelper. */
    AuthBackendHelper mockAuthBackendHelper = mock(AuthBackendHelper.class);

    /** The. AuthenticationManagerListener */
    AuthenticationManagerListener iAuthenticationManagerListener;

    /**
     * Setup.
     */
    @Before
    public void setup() throws Exception {
        PowerMockito.mockStatic(Log.class);

        when(mockConfig.retrieveConfig(anyString())).thenReturn(true);
        when(mockConfig.getConfig()).thenReturn(mockConfigInfo);
        when(mockConfigInfo.getServerUrl()).thenReturn("getServerUrl");
        when(mockConfigInfo.getAuthUrl()).thenReturn("getAuthUrl");

        PowerMockito.whenNew(AuthenticationUIController.class).withArguments( Matchers.any(Context.class),
                Matchers.any(ConfigHelper.class),
                Matchers.any(AuthenticationStorage.class)).thenReturn(mockAuthenticationUIController);
        PowerMockito.mockStatic(TextUtils.class);
        when(mockAuthenticationStorage.getShortLivedToken()).thenReturn("token");
        PowerMockito.when(TextUtils.isEmpty(anyString())).thenReturn(false);

        when(mockContext.getSharedPreferences(anyString(), anyInt())).thenReturn(mock(SharedPreferences.class));

        iAuthenticationManagerListener = new AuthenticationManagerListener() {
            @Override
            public void onAuthenticationSuccess() {
            }

            @Override
            public void onAuthenticationError() {
            }

            @Override
            public void onLogout() {
            }
        };

        authenticationManagerHelper = new AuthenticationManagerHelper(mockContext, mockConfig,
                mockAuthenticationStorage, mockAuthenticationUIController, mockAuthBackendHelper);
    }

    @After
    public void tearDown() {
        new File("modelCacheFolder").deleteOnExit();
        authenticationManagerHelper = null;
    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        assertNotNull(authenticationManagerHelper);
    }

    /**
     * Test testClose.
     */
    @Test
    public void testClose() {

    }


    /**
     * Test testProvision.
     */
    @Test
    public void testProvision() throws AuthenticationException {
        HashMap map = new HashMap<String,String>();
        map.put("question", "answer");
        map.put("question?", "answer:(");
        SignupInfo signupInfo = new SignupInfo("userName", "email", "phoneNo",
                "uniqueID", "password", map);

        authenticationManagerHelper.signup(signupInfo);

    }

    /**
     * Test testAuthenticate.
     */
    @Test
    public void testAuthenticate() throws AuthenticationException {
        authenticationManagerHelper.signin("keyOfAValue", "password", "deviceAdr");
    }

    /**
     * Test testRefreshAccessToken.
     */
    @Test
    public void testRefreshAccessToken() throws AuthenticationException {
        authenticationManagerHelper.refreshAuthTokenIfNeeded();

    }

    /**
     * Test testGetAuthIfNeeded.
     */
    @Test
    public void testGetAuthIfNeeded() throws Exception {
        when(TextUtils.isEmpty(anyString())).thenReturn(false);

        //conditional
//        atpAuthenticationManager.getAuthTokenIfNeeded();
        when(mockAuthenticationStorage.isAccessTokenKnownToBeExpired(anyString())).thenReturn(true);
        authenticationManagerHelper.refreshAuthTokenIfNeeded();

        when(mockAuthenticationStorage.isDvAccountDeactivated()).thenReturn(true);
        when(mockAuthenticationStorage.getShortLivedToken()).thenReturn("accessToken");
        when(TextUtils.isEmpty(anyString())).thenReturn(false);
        when(mockAuthenticationStorage.isAccessTokenKnownToBeExpired(anyString())).thenReturn(true);
        try {
            authenticationManagerHelper.refreshAuthTokenIfNeeded();
        } catch(AuthenticationException e) {
            Assert.assertEquals(ErrorCode.OPERATION_UNAUTHORIZED, e.getErrorCode());
        }

        when(mockAuthenticationStorage.isDvAccountDeactivated()).thenReturn(true);
        when(mockAuthenticationStorage.getShortLivedToken()).thenReturn("");
        when(mockAuthenticationStorage.getContextToken()).thenReturn("contextToken");
        when(TextUtils.isEmpty(anyString())).thenReturn(false, true, false);
        when(mockAuthenticationStorage.isAccessTokenKnownToBeExpired(anyString())).thenReturn(true);
        try {
            authenticationManagerHelper.refreshAuthTokenIfNeeded();
        } catch(AuthenticationException e) {
            Assert.assertEquals(ErrorCode.OPERATION_UNAUTHORIZED, e.getErrorCode());
        }

        when(mockAuthenticationStorage.isDvAccountDeactivated()).thenReturn(true);
        when(mockAuthenticationStorage.getShortLivedToken()).thenReturn("");
        when(mockAuthenticationStorage.getContextToken()).thenReturn("contextToken");
        when(TextUtils.isEmpty(anyString())).thenReturn(false, false, true, false);
        when(mockAuthenticationStorage.isAccessTokenKnownToBeExpired(anyString())).thenReturn(true);
        try {
            authenticationManagerHelper.refreshAuthTokenIfNeeded();
        } catch(AuthenticationException e) {
            Assert.assertEquals(ErrorCode.OPERATION_FAILED, e.getErrorCode());
        }

        Field f = AuthenticationManagerHelper.class.getDeclaredField("mAuthenticationInfo");
        f.setAccessible(true);
        f.set(authenticationManagerHelper, null);
        try {
            authenticationManagerHelper.refreshAuthTokenIfNeeded();
        } catch(AuthenticationException e) {
            Assert.assertEquals(ErrorCode.OPERATION_UNAUTHORIZED, e.getErrorCode());
        }

    }

    /**
     * Test testGetAuthenticationInfo.
     */
    @Test
    public void testGetAuthenticationInfo() {
        assertNotNull(authenticationManagerHelper.getAuthenticationInfo());
    }

    /**
     * Test testMyRefreshAccessToken
     */
    @Test
    public void testMyRefreshAccessToken() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, NoSuchFieldException, AuthenticationException
             {
//        Field f = AuthenticationManagerImpl.class.getDeclaredField("mAtpHelper");
//        f.setAccessible(true);
//        f.set(atpAuthenticationManager, mockAtpHelper);
//        when(TextUtils.isEmpty(anyString())).thenReturn(false);
//        when(mockAuthenticationStorage.isAccessTokenKnownToBeExpired(anyString())).thenReturn(true);
//        when(mockAuthenticationStorage.getContextToken()).thenReturn("token");
//        when(mockAuthenticationStorage.getDvUserUid()).thenReturn("DVUSERID");
//        //when(mockIPDPreferences.getRepoFolderAuto()).thenReturn(true);
//        Method m = AuthenticationManagerImpl.class.getDeclaredMethod("refreshAccessToken");
//        m.setAccessible(true);
//
//        m.invoke(atpAuthenticationManager);
//
//        try {
//            when(mockAtpHelper.doAuth(anyString(), anyString(), anyBoolean())).thenThrow(
//                    new AtpExceptions.AtpLoginUnauthorizedException(0, new Errors()));
//            m.invoke(atpAuthenticationManager);
//
//        } catch (InvocationTargetException ite) {
//            if (ite.getCause() instanceof AuthenticationException) {
//                assertEquals(AuthenticationException.ErrorCode.OPERATION_UNAUTHORIZED, ((AuthenticationException)ite.getCause()).getErrorCode());
//            } else {
//                fail();
//            }
//        }
//
    }

    /**
     * Test testOnAuthError.
     */
    @Test
    public void testcreateProvisionInfo(){
        SignupInfo iProvisioningInfo = new SignupInfo("userName", "email", "phoneNumber", "uniqueId", "accountPassword", null);
        Assert.assertEquals("userName", iProvisioningInfo.getUsername());
        Assert.assertEquals("email", iProvisioningInfo.getEmail());
        Assert.assertEquals("phoneNumber", iProvisioningInfo.getPhoneNumber());
        Assert.assertEquals("uniqueId", iProvisioningInfo.getUniqueId());
        Assert.assertEquals("accountPassword", iProvisioningInfo.getAccountPassword());
        Assert.assertEquals(null, iProvisioningInfo.getQuestions());

    }

    /**
     * Test testListeners.
     */
    @Test
    public void testListeners() throws NoSuchFieldException, IllegalAccessException {
        authenticationManagerHelper.removeListener(iAuthenticationManagerListener);
        authenticationManagerHelper.addListener(iAuthenticationManagerListener);
        authenticationManagerHelper.addListener(iAuthenticationManagerListener);
        authenticationManagerHelper.removeListener(iAuthenticationManagerListener);
        Field f = AuthenticationManagerHelper.class.getDeclaredField("mIAuthenticationManagerListeners");
        f.setAccessible(true);
        List list = (List)f.get(authenticationManagerHelper);
        assertEquals(0, list.size());
    }

    /**
     * Test testAuthentication.
     */
    @Test
    public void testAuthentication() {
        authenticationManagerHelper.addListener(iAuthenticationManagerListener);
        authenticationManagerHelper.onAuthenticationSuccess();
        authenticationManagerHelper.onAuthenticationError();
        //authenticationManagerHelper.onLogout();
    }

    /**
     * Test testAuthenticationExceptions.
     */
    @Test
    public void testAuthenticationExceptions() {
        try {
            doThrow(new Exception()).when(mockIAuthenticationManagerListener).onAuthenticationError();
            authenticationManagerHelper.onAuthenticationError();
            doThrow(new Exception()).when(mockIAuthenticationManagerListener).onAuthenticationSuccess();
            authenticationManagerHelper.onAuthenticationSuccess();
            doThrow(new Exception()).when(mockIAuthenticationManagerListener).onLogout();
            //authenticationManagerHelper.onLogout();
        } catch (Exception ex) {
            assertEquals("\nChecked exception is invalid for this method!\n" +
                    "Invalid: java.lang.Exception", ex.getMessage());
        }
    }
}

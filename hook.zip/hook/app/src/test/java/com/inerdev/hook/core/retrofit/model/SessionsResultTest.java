/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;


public class SessionsResultTest {

    /** The SessionsResult. */
    SessionsResult sessionsToken;

    /**
     * Setup.
     */
    @Before
    public void setup() throws IOException, JSONException {
        sessionsToken = new SessionsResult();

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        Assert.assertNotNull(sessionsToken);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException, JSONException {
        Assert.assertNull(sessionsToken.getId());
        Assert.assertNull(sessionsToken.getCurrentDeviceId());
        Assert.assertNull(sessionsToken.getName());
        Assert.assertNull(sessionsToken.getDisplayName());
        Assert.assertNull(sessionsToken.getDateCreation());
        Assert.assertNull(sessionsToken.getRefreshToken());
        Assert.assertNull(sessionsToken.getToken());

    }


}

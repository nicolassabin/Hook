package com.inerdev.hook.provider;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import com.inerdev.hook.BuildConfig;
import android.util.Log;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class, sdk = Build.VERSION_CODES.LOLLIPOP, manifest=Config.NONE)
public class SelectionBuilderTest {
    SelectionBuilder selectionBuilder;
    private SQLiteDatabase mockSQLiteDatabase = mock(SQLiteDatabase.class);
    private Cursor mockCursor = mock(Cursor.class);

    @Before
    public void setup() {
        selectionBuilder = new SelectionBuilder();
    }

    @Test
    public void testConstructor() {
        assertEquals("SelectionBuilder[table=null, selection=, selectionArgs=[]]", selectionBuilder.toString());
    }

    @Test
    public void testQuery() {
        when(mockSQLiteDatabase.query(eq("table"), eq(new String[] { "column1", "column2" }), eq("(selection=?)"), eq(new String[] { "arg1" }), eq((String) null), eq((String) null), eq("orderBy"), eq((String) null))).thenReturn(mockCursor);
        selectionBuilder.table("table");
        selectionBuilder.where("selection=?", "arg1");

        assertEquals("SelectionBuilder[table=table, selection=(selection=?), selectionArgs=[arg1]]", selectionBuilder.toString());

        assertSame(mockCursor, selectionBuilder.query(mockSQLiteDatabase, new String[] { "column1", "column2" }, "orderBy"));
    }

    @Test
    public void testUpdate() {
        ContentValues contentValues = new ContentValues();
        contentValues.put("key1", "value1");
        contentValues.put("key2", "value2");

        when(mockSQLiteDatabase.update(eq("table"), eq(contentValues), eq("(selection=?)"), eq(new String[] { "arg1" }))).thenReturn(1);
        selectionBuilder.table("table");
        selectionBuilder.where("selection=?", "arg1");

        assertEquals("SelectionBuilder[table=table, selection=(selection=?), selectionArgs=[arg1]]", selectionBuilder.toString());

        assertEquals(1, selectionBuilder.update(mockSQLiteDatabase, contentValues));
    }

    @Test
    public void testDelete() {
        when(mockSQLiteDatabase.delete(eq("table"), eq("(selection=?)"), eq(new String[] { "arg1" }))).thenReturn(1);
        selectionBuilder.table("table");
        selectionBuilder.where("selection=?", "arg1");

        assertEquals("SelectionBuilder[table=table, selection=(selection=?), selectionArgs=[arg1]]", selectionBuilder.toString());

        assertEquals(1, selectionBuilder.delete(mockSQLiteDatabase));
    }

    @Test
    public void testReset() {
        selectionBuilder.table("table");
        selectionBuilder.where("selection=?", "arg1");

        assertEquals("SelectionBuilder[table=table, selection=(selection=?), selectionArgs=[arg1]]", selectionBuilder.toString());

        selectionBuilder.reset();

        assertEquals("SelectionBuilder[table=null, selection=, selectionArgs=[]]", selectionBuilder.toString());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFailedWhere() {
        selectionBuilder.where("", new String[] { "" });
    }
}

package com.inerdev.hook.provider;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import com.inerdev.hook.BuildConfig;
import android.util.Log;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class, sdk = Build.VERSION_CODES.LOLLIPOP)
public class AppDatabaseTest  {
    AppDatabase appDatabase;
    private Context mockContext = mock(Context.class);
    private SQLiteDatabase mockDatabase = mock(SQLiteDatabase.class);
    private Log mockLog = mock(Log.class);

    @Before
    public void setup() {
        appDatabase = new AppDatabase(mockContext, mockLog);
    }

    @Test
    public void testOnCreate() {
        appDatabase.onCreate(mockDatabase);

        verify(mockDatabase).execSQL(AppDatabase.SQL_CREATE_MESSAGES);
        verify(mockDatabase).execSQL(AppDatabase.SQL_CREATE_DEVICES);

    }

    @Test
    public void testOnUpgrade() {
        appDatabase.onUpgrade(mockDatabase, 0, 0);

        verify(mockDatabase).execSQL(AppDatabase.SQL_DELETE_MESSAGES);
        verify(mockDatabase).execSQL(AppDatabase.SQL_DELETE_DEVICES);

        verify(mockDatabase).execSQL(AppDatabase.SQL_CREATE_MESSAGES);
        verify(mockDatabase).execSQL(AppDatabase.SQL_CREATE_DEVICES);

    }
}

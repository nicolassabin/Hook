package com.inerdev.hook.provider;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import com.inerdev.hook.BuildConfig;


import com.inerdev.hook.HookApplication;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class, sdk = 21, application = HookApplication.class, manifest=Config.NONE)
public class AppProviderTest {

    AppProvider AppProvider;
    UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    SelectionBuilder mockSelectionBuilder = mock(SelectionBuilder.class);

    ContentResolver mockContentResolver = mock(ContentResolver.class);

    AppDatabase mockAppDatabase = mock(AppDatabase.class);
    AppContract mockAppContract = mock(AppContract.class);
    Context mockContext = mock(Context.class);
    private SQLiteDatabase mockSQLiteDatabase = mock(SQLiteDatabase.class);
    private Cursor mockCursor = mock(Cursor.class);

    @Before
    public void setup() {
        when(mockAppContract.getContentAuthority()).thenReturn("com.example.App.hook.data");
        when(mockContext.getPackageName()).thenReturn("com.example.App");
        when(mockAppDatabase.getReadableDatabase()).thenReturn(mockSQLiteDatabase);
        when(mockAppDatabase.getWritableDatabase()).thenReturn(mockSQLiteDatabase);

        when(mockSelectionBuilder.table(anyString())).thenReturn(mockSelectionBuilder);
        when(mockSelectionBuilder.where(anyString(), anyString())).thenReturn(mockSelectionBuilder);
        when(mockSelectionBuilder.query(mockSQLiteDatabase, null, null)).thenReturn(mockCursor);

        AppProvider = new AppProvider();
        AppProvider.mUriMatcher = uriMatcher;
        AppProvider.mContext = mockContext;
        AppProvider.mDatabaseHelper = mockAppDatabase;
        AppProvider.mSelectionBuilder = mockSelectionBuilder;
        AppProvider.mContentResolver = mockContentResolver;
    }

    private void create(){

        assertTrue(AppProvider.onCreate());
        AppProvider.mContext = mockContext;
        AppProvider.mDatabaseHelper = mockAppDatabase;
        AppProvider.mSelectionBuilder = mockSelectionBuilder;
        AppProvider.mContentResolver = mockContentResolver;
    }

    @Test
    public void testOnCreate() {
        create();

        assertNotNull(AppProvider.mDatabaseHelper);
        assertEquals(AppProvider.mDatabaseHelper, mockAppDatabase);
        assertNotNull(mockSelectionBuilder);
    }

    @Test
    public void testGetType() {
        create();
        assertEquals("vnd.android.cursor.dir/vnd.hookadapter.messages", AppProvider.getType(Uri.parse("content://com.example.App.hook.data/messages")));
        assertEquals("vnd.android.cursor.item/vnd.hookadapter.messages", AppProvider.getType(Uri.parse("content://com.example.App.hook.data/messages/1")));
        assertEquals("vnd.android.cursor.dir/vnd.hookadapter.devices", AppProvider.getType(Uri.parse("content://com.example.App.hook.data/devices")));
        assertEquals("vnd.android.cursor.item/vnd.hookadapter.devices", AppProvider.getType(Uri.parse("content://com.example.App.hook.data/devices/1")));

        try {
            AppProvider.getType(Uri.parse("content://com.example.App.hook.data/wrong"));
            fail();
        } catch (UnsupportedOperationException ignored) {
        }
    }

    @Test
    public void testQuery() {
        create();
        assertNotNull(AppProvider.query(Uri.parse("content://com.example.App.hook.data/messages"), null, null, null, null));
        assertNotNull(AppProvider.query(Uri.parse("content://com.example.App.hook.data/messages/1"), null, null, null, null));
        assertNotNull(AppProvider.query(Uri.parse("content://com.example.App.hook.data/devices"), null, null, null, null));
        assertNotNull(AppProvider.query(Uri.parse("content://com.example.App.hook.data/devices/1"), null, null, null, null));

        try {
            AppProvider.query(Uri.parse("content://com.example.App.hook.data/wrong"), null, null, null, null);
            fail();
        } catch (UnsupportedOperationException ignored) {
        }
    }

    @Test
    public void testInsert() {
        create();
        ContentValues contentValues = new ContentValues();
        assertNotNull(AppProvider.insert(Uri.parse("content://com.example.App.hook.data/messages"), contentValues));
        assertNotNull(AppProvider.insert(Uri.parse("content://com.example.App.hook.data/devices"), contentValues));
        
        try {
            AppProvider.insert(Uri.parse("content://com.example.App.hook.data/messages/1"), contentValues);
            fail();
        } catch (IllegalArgumentException ignored) {
        }

        try {
            AppProvider.insert(Uri.parse("content://com.example.App.hook.data/devices/1"), contentValues);
            fail();
        } catch (IllegalArgumentException ignored) {
        }

        try {
            AppProvider.insert(Uri.parse("content://com.example.App.hook.data/wrong"), contentValues);
            fail();
        } catch (IllegalArgumentException ignored) {
        }
    }

    @Test
    public void testUpdate() {
        create();
        assertNotNull(AppProvider.update(Uri.parse("content://com.example.App.hook.data/messages"), null, null, null));
        assertNotNull(AppProvider.update(Uri.parse("content://com.example.App.hook.data/messages/1"), null, null, null));
        assertNotNull(AppProvider.update(Uri.parse("content://com.example.App.hook.data/devices"), null, null, null));
        assertNotNull(AppProvider.update(Uri.parse("content://com.example.App.hook.data/devices/1"), null, null, null));

    }

    @Test
    public void testDelete() {
        create();
        assertNotNull(AppProvider.delete(Uri.parse("content://com.example.App.hook.data/messages"), null, null));
        assertNotNull(AppProvider.delete(Uri.parse("content://com.example.App.hook.data/messages/1"), null, null));
        assertNotNull(AppProvider.delete(Uri.parse("content://com.example.App.hook.data/devices"), null, null));
        assertNotNull(AppProvider.delete(Uri.parse("content://com.example.App.hook.data/devices/1"), null, null));

    }

    @Test
    public void testGetWhereClause() {
        assertEquals("Test getWhereClause() on non null values", "_id=5 AND (something)", AppProvider.getWhereClause("5", "something"));
        assertEquals("Test getWhereClause() on non null values", "_id=5", AppProvider.getWhereClause("5", null));
    }
}

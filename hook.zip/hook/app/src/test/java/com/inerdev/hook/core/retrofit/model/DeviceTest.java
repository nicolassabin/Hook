/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;


public class DeviceTest {

    /** The Device. */
    Device device;

    /**
     * Setup.
     */
    @Before
    public void setup() throws IOException, JSONException {
        device = new Device();

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        Assert.assertNotNull(device);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException, JSONException {
        Assert.assertNull(device.getId());
        Assert.assertNull(device.getAddress());
        Assert.assertNull(device.getName());
        Assert.assertNull(device.getDisplayName());
        Assert.assertNull(device.getDateCreation());
        Assert.assertNull(device.getKey());
        Assert.assertNull(device.getType());
        Assert.assertEquals(0, device.getStatus());

    }


}

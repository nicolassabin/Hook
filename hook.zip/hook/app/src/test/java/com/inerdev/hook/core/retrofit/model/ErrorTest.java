/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;


import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

public class ErrorTest {

    /** The Error. */
    Error error;

    /**
     * Setup.
     */
    @Before
    public void setup() {
        error = new Error();
    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        assertNotNull(error);
    }

    /**
     * Test testGettersSetters.
     */
    @Test
    public void testGettersSetters() {
        error.setMessage(null);
        error.setMessage("message");
        assertEquals("message", error.getMessage());
        error.setStatusCode(null);
        error.setStatusCode("1");
        assertEquals(new Integer(1), Integer.valueOf(error.getStatusCode()));
        error.setCode(null);
        error.setCode("code");
        assertEquals("code", error.getCode());

    }
}

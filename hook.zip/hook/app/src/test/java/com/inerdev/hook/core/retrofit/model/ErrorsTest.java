/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;


import org.junit.Before;
import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

public class ErrorsTest {

    /** The Errors. */
    Errors errors;

    /**
     * Setup.
     */
    @Before
    public void setup() {
        errors = new Errors();
    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        assertNotNull(errors);
    }

    /**
     * Test testGettersSetters.
     */
    @Test
    public void testGettersSetters() {
        Error error = new Error();
        error.setCode("234");
        error.setMessage("err");
        Error error2 = new Error();
        error2.setCode("2342");
        error2.setMessage("err2");
        errors.getErrors().add(error);
        errors.getErrors().add(error2);
        assertEquals("234", errors.getErrors().get(0).getCode());
        assertEquals("err", errors.getErrors().get(0).getMessage());
        assertEquals("2342", errors.getErrors().get(1).getCode());
        assertEquals("err2", errors.getErrors().get(1).getMessage());
    }
}

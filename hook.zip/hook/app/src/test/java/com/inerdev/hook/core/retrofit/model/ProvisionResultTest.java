/*
 * Copyright 2014 Synchronoss Technologies, Inc.  All Rights Reserved.
 *
 * This source code is the confidential and proprietary information of
 * Synchronoss Technologies, Inc.
 *
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with Synchronoss Technologies.
 */
package com.inerdev.hook.core.retrofit.model;

import org.json.JSONException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.Map;


public class ProvisionResultTest {

    /** The ProvisionResult. */
    ProvisionResult provisionResult;

    /** The Map. */
    Map<String,String> map;

    /**
     * Setup.
     */
    @Before
    public void setup() throws IOException, JSONException {
        provisionResult = new ProvisionResult();

    }

    /**
     * Test testCreate.
     */
    @Test
    public void testCreate() {
        Assert.assertNotNull(provisionResult);
    }

    /**
     * Test testGetters.
     */
    @Test
    public void testGetters() throws NoSuchFieldException, IllegalAccessException, JSONException {
        Assert.assertNull(provisionResult.getAccountType());
        Assert.assertNull(provisionResult.getAuthorizationCode());
        Assert.assertNull(provisionResult.getDisplayName());
        Assert.assertNull(provisionResult.getId());
        Assert.assertNull(provisionResult.getName());
        Assert.assertNull(provisionResult.getNameSpace());
        Assert.assertNull(provisionResult.getPhoneNumber());
        Assert.assertNull(provisionResult.getType());
    }


}
